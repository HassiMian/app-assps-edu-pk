import{a as e}from"./rolldown-runtime-BYbx6iT9.js";import{n as t,r as n}from"./vendor-motion-DoYOP1Wm.js";import{f as r}from"./index-BEB1qTuo.js";import{a as i}from"./useAcademicStore-D-Y4rfET.js";import{n as a}from"./useStudentStore-xRf5KuT-.js";import{t as o}from"./usePaperStore-evtWEEzg.js";import{t as s}from"./vendor-scanner-kvt3ndV-.js";var c=e(n(),1),l=e(s(),1),u=t(),d=`AL SIDDIQUE SCHOLARS PUBLIC SCHOOL`;function f(e,t=`#000`,n=22){let r=(e||`GR0000`).toUpperCase().replace(/[^A-Z0-9.-]/g,``).slice(0,18),i=[],a=0,o=e=>{i.push(`<rect x="${a}" y="0" width="${e}" height="${n}" fill="${t}"/>`),a+=e},s=e=>{a+=e};o(3),s(1),o(1),s(1),o(3),s(3);for(let e of r){let t=e.charCodeAt(0);for(let e=7;e>=0;e--)o(t>>e&1?3:1),s(1);s(2)}return o(3),s(1),o(1),s(1),o(3),`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${a} ${n}" preserveAspectRatio="none" style="display:block;width:100%;height:${n}px">${i.join(``)}</svg>`}var p=[{id:`corporate`,label:`Executive Ivory`,sub:`Warm ivory + navy credential`,c1:`#FFFDF8`,c2:`#B9965A`},{id:`university`,label:`University Pro`,sub:`Reference style orange photo rail`,c1:`#13224A`,c2:`#F97316`},{id:`executive`,label:`Abstract Curve`,sub:`Curved navy/orange profile`,c1:`#0F1B3D`,c2:`#FF7A00`},{id:`school`,label:`Prestige Badge`,sub:`Clean crest layout + readable data`,c1:`#F8FAFC`,c2:`#0F1B3D`},{id:`minimal`,label:`Modern White`,sub:`Clean white with bold accents`,c1:`#FFFFFF`,c2:`#13224A`}],m=[{id:`royal`,label:`Royal Academic`,sub:`Ivory - burgundy line - antique gold`,c1:`#FFF9EF`,c2:`#B9965A`},{id:`digital`,label:`Modern Digital`,sub:`Pearl - slate - calm teal data-viz`,c1:`#F4F8FA`,c2:`#5EA8A7`},{id:`classic`,label:`Classic Formal`,sub:`Warm paper - royal blue accents`,c1:`#FAF7F0`,c2:`#527AA3`},{id:`vibrant`,label:`Vibrant Excellence`,sub:`Soft coral - mint - sunshine accents`,c1:`#FFF6F1`,c2:`#8BCFC3`}],h=[{id:`cr80`,label:`CR80 Standard`,desc:`85.6 x 54 mm`,note:`Enterprise ID card standard`,baseW:85.6,baseH:54}],g={bg:`#071e34`,card:`rgba(11,44,77,0.92)`,gold:`#C8991A`,goldL:`#e8b420`,silver:`#C0C8D8`,muted:`#8892A4`,green:`#30D158`,red:`#FF375F`,blue:`#0A84FF`,border:`rgba(148,163,184,0.18)`},_=[`#FF6B35`,`#4ECDC4`,`#F7C948`,`#FF375F`,`#2E7D32`,`#673AB7`,`#1976D2`,`#E91E63`,`#009688`,`#FF9800`];function v(e,t,n,r=`#fff`){let i=e.map(e=>Math.max(0,Number(t[e]||0))),a=i.reduce((e,t)=>e+t,0),o=e.length*n,s=o>0?Math.round(a/o*100):0;if(!a)return`<svg width="200" height="200" viewBox="0 0 200 200"><circle cx="100" cy="100" r="88" fill="#eee"/><circle cx="100" cy="100" r="52" fill="${r}"/><text x="100" y="100" text-anchor="middle" dominant-baseline="middle" font-size="16" fill="#aaa">N/A</text></svg>`;let c=-Math.PI/2,l=``;return i.forEach((e,t)=>{if(!e)return;let n=e/a*2*Math.PI,i=100+88*Math.cos(c),o=100+88*Math.sin(c),s=100+52*Math.cos(c),u=100+52*Math.sin(c);c+=n;let d=100+88*Math.cos(c),f=100+88*Math.sin(c),p=100+52*Math.cos(c),m=100+52*Math.sin(c),h=+(n>Math.PI),g=_[t%_.length];l+=`<path d="M${i.toFixed(1)},${o.toFixed(1)} A88,88 0 ${h},1 ${d.toFixed(1)},${f.toFixed(1)} L${p.toFixed(1)},${m.toFixed(1)} A52,52 0 ${h},0 ${s.toFixed(1)},${u.toFixed(1)} Z" fill="${g}" stroke="${r}" stroke-width="2"/>`}),`<svg width="200" height="200" viewBox="0 0 200 200">
 ${l}
 <circle cx="100" cy="100" r="52" fill="${r}"/>
 <text x="100" y="90" text-anchor="middle" font-size="22" font-weight="900" fill="#333" font-family="Arial">${s}%</text>
 <text x="100" y="110" text-anchor="middle" font-size="11" fill="#666" font-family="Arial">Overall</text>
 <text x="100" y="126" text-anchor="middle" font-size="10" fill="#999" font-family="Arial">${a}/${o}</text>
 </svg>`}function y(e,t,n,r=`light`){let i=`#E5EAF0`;return`<div style="height:190px;display:flex;align-items:flex-end;gap:10px;padding:16px 10px 8px;border-radius:12px;background:linear-gradient(180deg,transparent 0,transparent 24%,${i} 25%,transparent 26%,transparent 49%,${i} 50%,transparent 51%,transparent 74%,${i} 75%,transparent 76%)">
 ${e.map((e,r)=>{let i=Number(t[e]||0),a=n>0?Math.min(100,Math.round(i/n*100)):0,o=_[r%_.length];return`<div style="flex:1;min-width:0;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:6px">
 <div style="font-size:10px;font-weight:800;color:${o}">${a}%</div>
 <div style="width:70%;height:${Math.max(8,a)}%;border-radius:8px 8px 3px 3px;background:linear-gradient(180deg,${o},${o}cc);box-shadow:0 5px 14px ${o}33"></div>
 <div style="font-size:9px;font-weight:700;color:#334155;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:52px">${e}</div>
 </div>`}).join(``)}
 </div>`}function b(e){return String(e||``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function x(e){return e?typeof e==`string`?e:typeof e==`object`&&(e.url||e.src||e.path||e.preview||e.file_url||e.secure_url)||``:``}function S(e){let t=x(e).trim();if(!t)return``;if(/^(data:|blob:|https?:\/\/)/i.test(t))return t;try{return new URL(t,window.location.origin).href}catch{return t}}function C(...e){for(let t of e){let e=S(t);if(e)return e}return``}function w(e={}){var t,n,r,i,a,o,s,c,l;return typeof e==`string`?{size:e,orientation:e===`cr80p`?`portrait`:`landscape`,pageOrientation:`portrait`,template:`corporate`,cardOptions:{}}:{size:e.size||`cr80`,orientation:e.orientation||(e.size,`portrait`),pageOrientation:e.pageOrientation||`portrait`,template:e.template||`corporate`,doubleSided:!!e.doubleSided,cardOptions:{primaryColor:((t=e.cardOptions)==null?void 0:t.primaryColor)||`#0B1F3A`,secondaryColor:((n=e.cardOptions)==null?void 0:n.secondaryColor)||`#C8D2E3`,textColor:((r=e.cardOptions)==null?void 0:r.textColor)||`#FFFFFF`,borderRadius:Number((i=(a=e.cardOptions)==null?void 0:a.borderRadius)==null?4:i),photoShape:((o=e.cardOptions)==null?void 0:o.photoShape)||`rounded`,showBarcode:!0,showQr:((s=e.cardOptions)==null?void 0:s.showQr)===!0,showSignature:((c=e.cardOptions)==null?void 0:c.showSignature)!==!1,backgroundPattern:((l=e.cardOptions)==null?void 0:l.backgroundPattern)!==!1},cardsPerPage:e.cardsPerPage?Number(e.cardsPerPage):null}}function T(e){let t=w(e),n=h.find(e=>e.id===t.size)||h[0];return t.orientation===`portrait`?{w:n.baseH,h:n.baseW,label:`${n.baseH} x ${n.baseW} mm`}:{w:n.baseW,h:n.baseH,label:`${n.baseW} x ${n.baseH} mm`}}function E(e){let t=w(e),{w:n,h:r}=T(t),i=t.pageOrientation===`landscape`?297:210,a=t.pageOrientation===`landscape`?210:297,o={1:[1,1],2:[2,1],3:[3,1],4:[2,2],6:[3,2],8:[3,3],9:[3,3]},s,c,l=Number(t.cardsPerPage);if(l&&o[l]){let[e,t]=o[l];r>=n==a>=i?(s=e,c=t):(s=t,c=e)}else{let e=i-16,t=a-16;s=Math.max(1,Math.floor((e+3)/(n+3))),c=Math.max(1,Math.floor((t+3)/(r+3)))}return{pageW:i,pageH:a,margin:8,gap:3,cols:s,rows:c,perPage:s*c,cardW:n,cardH:r}}function D(e){return String(e||`ID`).split(/\s+/).filter(Boolean).slice(0,2).map(e=>e[0]).join(``).toUpperCase()||`ID`}function O(e){let t=String(e||d).toUpperCase().replace(/\s+/g,` `).trim();if(t.includes(`SCHOLARS PUBLIC SCHOOL`))return[`AL SIDDIQUE`,`SCHOLARS PUBLIC SCHOOL`];let n=t.split(` `),r=Math.max(1,Math.ceil(n.length/2));return[n.slice(0,r).join(` `),n.slice(r).join(` `)].filter(Boolean)}function k(e){let[t,n=``]=O(e);return`<span class="brand-line brand-line-main">${b(t)}</span>${n?`<span class="brand-line brand-line-sub">${b(n)}</span>`:``}`}function A(e,t,n){let r=t===`employee`,i=r?e.emp_id||`EMP-${String(e.id||``).padStart(3,`0`)}`:e.gr_number||e.gr||String(e.id||`GR-0000`);return{kindLabel:r?`STAFF ID`:`STUDENT ID`,idLabel:r?`Employee ID`:`Roll / GR No`,name:e.name||(r?`Employee Name`:`Student Name`),father:e.father_name||e.father||`Father Name`,group:r?e.department||`Department`:e.class||`Class`,groupLabel:r?`Department`:`Class`,role:r?e.designation||`Staff Member`:`Section ${e.section||`-`}`,phone:e.phone||e.parent_phone||e.contact||e.whatsapp||`-`,address:e.address||n.address||`-`,blood:e.blood_group||e.bloodGroup||`-`,session:e.session||`2026-27`,validity:e.valid_till||e.expiryDate||`31-03-2027`,issue:e.issueDate||new Date().toLocaleDateString(`en-GB`),photo:C(e.photo,e.image,e.profile_photo,e.profilePhoto,e.profileImage,e.profile_image,e.photo_url,e.photoUrl,e.image_url,e.imageUrl,e.avatar,e.avatar_url,e.picture,e.picture_url,e.employee_photo,e.employeePhoto,e.staff_photo,e.staffPhoto,e.thumbnail),id:i}}function j(e,t,n){return n.cardOptions.showQr?e?`<img class="id-qr" src="${e}" alt="QR" />`:`<div class="id-qr qr-fallback">QR</div>`:``}function M(e,t){let n=t.cardOptions.photoShape===`circle`?`photo circle`:`photo`;return e.photo?`<img class="${n}" src="${b(e.photo)}" alt="Photo" />`:`<div class="${n} photo-fallback">${b(D(e.name))}</div>`}function N(e){let t=(e.schoolName||d).toUpperCase(),n=S(e.logo);return n?`<img class="school-logo" src="${b(n)}" alt="Logo" />`:`<div class="school-logo logo-fallback">${b(t.charAt(0))}</div>`}function P(){return`<div class="smart-chip"><span></span><span></span><span></span><span></span></div>`}function F(e,t,n,r,i,a={},o=``){let s=w({...a,template:r}),c=T(s),l=A(e,t,i),u=k((i.schoolName||d).toUpperCase()),p=`--card-w:${c.w}mm;--card-h:${c.h}mm;--primary:${s.cardOptions.primaryColor};--secondary:${s.cardOptions.secondaryColor};--text:${s.cardOptions.textColor};--radius:${s.cardOptions.borderRadius}mm;`,m=`<div class="barcode-wrap">${f(l.id,`#102A4C`,20)}</div>`,h=j(o,l,s),g=S(i.principalSignature),_=s.cardOptions.showSignature?`<div class="signature">${g?`<img src="${b(g)}" alt="Principal Signature" />`:`<span></span>`}<b>Principal Signature</b></div>`:``,v=s.cardOptions.backgroundPattern?` with-pattern`:``;return n===`back`?`<div class="id-card ${s.orientation} tpl-${r} back${v}" style="${p}">
 <div class="design-arc arc-one"></div>
 <div class="design-arc arc-two"></div>
 <div class="design-ribbon"></div>
 <div class="security-strip"></div>
 <div class="back-head" style="background:#13224A; color:#fff; padding:1.8mm 2.5mm; display:flex; align-items:center; gap:2.5mm; height:18mm; flex-shrink:0;">
 ${N(i)}
 <div class="school-block" style="flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center;">
 ${k(i.name||i.schoolName||d)}
 </div>
 </div>
 <div class="terms" style="padding:4mm 5mm 0;">
 <h4 style="font-size:3mm; margin-bottom:1.5mm; color:#13224A; border-bottom:1px solid #ddd; padding-bottom:1mm;">Terms & Conditions</h4>
 <ul style="font-size:2.2mm; line-height:1.4; color:#555; padding-left:3.5mm;">
 <li>This card is school property and must be carried on campus.</li>
 <li>If found, please return it to the school office immediately.</li>
 <li>Misuse must be reported to administration.</li>
 </ul>
 </div>
 <div class="back-grid" style="margin:auto 0; padding:0 5mm;">
 <div><label>Emergency</label><strong>${b(l.phone)}</strong></div>
 <div><label>Issue Date</label><strong>${b(l.issue)}</strong></div>
 <div><label>Valid Until</label><strong>${b(l.validity)}</strong></div>
 <div><label>Blood Group</label><strong>${b(l.blood)}</strong></div>
 </div>
 <div class="back-bottom" style="margin-top:auto; padding:2mm 5mm 4mm; border-top:1px solid #eee; display:flex; align-items:flex-end; justify-content:space-between; gap:3mm; position:relative;">
 <div class="contact-lines" style="flex:1;">
 <b style="font-size:2.2mm; display:block; margin-bottom:1mm; color:#333;">${b(i.address||l.address)}</b>
 <span style="font-size:2.1mm; color:#666;">${b(i.phone||l.phone)}</span>
 </div>
 <div style="flex-shrink:0; width:15mm;">${h||m}</div>
 ${_?`<div style="position:absolute; right:5mm; bottom:14mm; transform:scale(0.8); transform-origin:bottom right;">${_}</div>`:``}
 </div>
 </div>`:`<div class="id-card ${s.orientation} tpl-${r} front${v}" style="${p}">
 <div class="design-arc arc-one"></div>
 <div class="design-arc arc-two"></div>
 <div class="design-ribbon"></div>
 <div class="hologram"></div>
 <div class="id-topline"></div>
 <header>
 ${N(i)}
 <div class="school-block"><strong>${u}</strong></div>
 </header>
 <main>
 <section class="photo-section">
 ${M(l,s)}
 <div class="grade-badge">${b(l.group)}</div>
 </section>
 <section class="data-section">
 <h3>${b(l.name)}</h3>
 <p>${b(l.role)}</p>
 <div class="field-grid">
 <div><label>${b(l.idLabel)}</label><b>${b(l.id)}</b></div>
 <div><label>${b(l.groupLabel)}</label><b>${b(l.group)}</b></div>
 <div><label>Father Name</label><b>${b(l.father)}</b></div>
 <div><label>Contact</label><b>${b(l.phone)}</b></div>
 <div><label>Session</label><b>${b(l.session)}</b></div>
 <div><label>Blood</label><b>${b(l.blood)}</b></div>
 </div>
 </section>
 </main>
 <footer>
 ${P()}
 ${m}
 ${h}
 </footer>
 </div>`}function I(e,t,n,r={},i=``){return F(e,`student`,`front`,t,n,r,i)}function L(e,t,n,r={},i=``){return F(e,`student`,`back`,t,n,r,i)}function R(e,t,n,r={},i=``){return F(e,`employee`,`front`,t,n,r,i)}function z(e,t,n,r={},i=``){return F(e,`employee`,`back`,t,n,r,i)}function B(e){let t=w(e),n=E(t);return`
 *{box-sizing:border-box;margin:0;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact;text-rendering:geometricPrecision}
 html,body{background:#eef2f7;font-family:'DM Sans',Arial,sans-serif;color:#071e34}
 @page{size:A4 ${t.pageOrientation};margin:0}
 @media print{body{background:white}.no-print{display:none!important}.print-page{break-after:page;box-shadow:none!important;margin:0!important}.print-page:last-child{break-after:auto}}
 .no-print{padding:12px 20px;background:#071e34;border-bottom:2px solid #C8991A;display:flex;gap:16px;align-items:center;position:sticky;top:0;z-index:10}
 .print-page{width:${n.pageW}mm;height:${n.pageH}mm;padding:${n.margin}mm;background:white;display:grid;grid-template-columns:repeat(${n.cols},${n.cardW}mm);grid-template-rows:repeat(${n.rows},${n.cardH}mm);gap:${n.gap}mm;align-content:center;justify-content:center;box-shadow:0 12px 34px rgba(15,23,42,.18);margin:12px auto;overflow:hidden}
 .slot{width:${n.cardW}mm;height:${n.cardH}mm;display:flex;align-items:center;justify-content:center;break-inside:avoid;page-break-inside:avoid}

 /*  BASE CARD  */
 .id-card{width:var(--card-w);height:var(--card-h);border-radius:var(--radius);overflow:hidden;position:relative;font-family:'DM Sans',Arial,sans-serif;display:flex;flex-direction:column;break-inside:avoid;background:#fff;border:.3mm solid #B8C8D8;box-shadow:0 2mm 8mm rgba(15,23,42,.28),inset 0 .25mm 0 rgba(255,255,255,.7)}
 .id-card::after{content:"";position:absolute;inset:.5mm;border-radius:calc(var(--radius) - .5mm);border:.15mm solid rgba(255,255,255,.45);pointer-events:none;z-index:8}
 .design-arc,.design-ribbon,.hologram,.id-topline,.security-strip{position:absolute;pointer-events:none}
 .id-card.front header,.id-card.front main,.id-card.front footer{position:relative;z-index:4}
 .id-card.back>*:not(.design-arc):not(.design-ribbon){position:relative;z-index:4}
 .smart-chip,.hologram{display:none}

 /*  UNIVERSAL HEADER (all templates) 
 18mm tall | navy bg | logo LEFT (fixed 12mm) | school name CENTERED in remaining space */
 .id-card.front header{
 height:18mm;flex-shrink:0;
 display:flex;align-items:center;gap:2.5mm;
 padding:1.8mm 2.5mm;
 background:#13224A;
 z-index:6;
 }
 .school-logo{
 width:12mm;height:12mm;
 flex:none;border-radius:50%;
 background:white;padding:.55mm;
 border:.35mm solid rgba(255,200,80,.7);
 object-fit:contain;
 box-shadow:0 .8mm 2mm rgba(0,0,0,.35),0 0 0 .5mm rgba(255,200,80,.25);
 flex-shrink:0;
 }
 .logo-fallback{display:flex;align-items:center;justify-content:center;font-size:5mm;font-weight:900;color:#13224A}
 .school-block{
 flex:1;min-width:0;
 display:flex;flex-direction:column;
 align-items:center;justify-content:center;
 text-align:center;
 }
 .school-block small{display:none}
 .id-card.front header em{display:none}
 .brand-line{display:block;text-transform:uppercase;font-weight:950;line-height:1.1;letter-spacing:.22mm}
 .brand-line-main{
 font-size:3.2mm;
 color:#FFCD60;
 letter-spacing:.28mm;
 text-shadow:0 .3mm .8mm rgba(0,0,0,.4);
 }
 .brand-line-sub{
 font-size:2.1mm;
 color:rgba(255,255,255,.92);
 letter-spacing:.14mm;
 margin-top:.35mm;
 font-weight:800;
 }

 /*  SHARED PHOTO  */
 .photo{object-fit:cover;background:#E8EEF8}
 .photo-fallback{display:flex;align-items:center;justify-content:center;font-weight:900;font-size:7mm;color:#13224A;background:linear-gradient(145deg,#E8EEF8,#F0F4FB)}

 /*  GRADE BADGE  */
 .grade-badge{font-size:2mm;font-weight:900;border-radius:99mm;padding:.8mm 2mm;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:30mm;background:#FF7900;color:#fff;border:.25mm solid rgba(255,255,255,.5);box-shadow:0 .6mm 1.5mm rgba(0,0,0,.25);display:inline-block;margin-top:1.2mm}

 /*  SHARED DATA SECTION  */
 .data-section h3{font-size:3.6mm;font-weight:950;line-height:1.05;margin-bottom:.5mm;color:#13224A}
 .data-section p{font-size:2.1mm;margin-bottom:1.2mm;color:#556070;font-weight:700}
 .field-grid{display:grid;gap:.9mm}
 .field-grid div{background:rgba(255,255,255,.94);border:.18mm solid #dde4ee;border-radius:1.3mm;padding:.7mm .9mm;min-width:0;box-shadow:0 .4mm 1mm rgba(15,23,42,.07)}
 .field-grid label{display:block;font-size:1.35mm;text-transform:uppercase;font-weight:900;letter-spacing:.1mm;color:#6070A0;margin-bottom:.25mm;line-height:1}
 .field-grid b{display:block;font-size:1.9mm;font-weight:900;line-height:1.1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#0F172A}

 /*  SHARED FOOTER (absolute, always at bottom)  */
 .id-card.front footer{position:absolute;left:3mm;right:3mm;bottom:2mm;height:5.5mm;display:flex;align-items:center;gap:1.5mm;padding:0;background:transparent;z-index:7;border:none}
 .barcode-wrap{display:block;flex:1;min-width:0;height:5mm;padding:.4mm .7mm;border-radius:.9mm;background:rgba(255,255,255,.96);border:.18mm solid rgba(19,34,74,.2);overflow:hidden}
 .barcode-wrap svg{height:4mm!important;width:100%!important}
 .id-qr{width:6mm;height:6mm;flex:none;object-fit:contain;background:white;border:.2mm solid #13224A;border-radius:.8mm;padding:.3mm}
 .qr-fallback{display:flex;align-items:center;justify-content:center;color:#0B1F3A;font-size:1.8mm;font-weight:900}

 /*  BACK CARD  */
 .id-card.back{background:#fff;color:#16213F}
 .security-strip{height:5mm;flex-shrink:0;background:#13224A;border-bottom:.8mm solid #FF7900}
 .back-head{display:flex;align-items:center;gap:2.5mm;padding:1.8mm 2.5mm;background:#13224A;flex-shrink:0;height:18mm}
 .back-head .school-logo{width:12mm!important;height:12mm!important;border:.35mm solid rgba(255,200,80,.7)!important;background:white!important;flex-shrink:0}
 .back-head .school-block{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center}
 .back-head .brand-line-main{color:#FFCD60;font-size:3mm}
 .back-head .brand-line-sub{color:#fff;font-size:2mm}
 .terms{padding:2mm 5mm 1mm}
 .terms h4{font-size:3.2mm;font-weight:800;color:#13224A;margin-bottom:1mm;text-transform:uppercase;letter-spacing:.3mm;border-bottom:1px solid #eee;padding-bottom:.5mm}
 .terms ul{padding-left:4mm;color:#475569;font-size:2.4mm;line-height:1.4}
 .back-grid{display:grid;grid-template-columns:1fr 1fr;gap:2.5mm;padding:0 5mm;margin:2mm 0}
 .back-grid label{display:block;font-size:1.8mm;font-weight:700;color:#94A3B8;text-transform:uppercase;margin-bottom:.3mm}
 .back-grid strong{display:block;font-size:2.4mm;color:#1E293B;font-weight:800}
 .back-bottom{margin-top:auto;display:flex;align-items:center;gap:2mm;padding:1.8mm 3.5mm}
 .contact-lines{flex:1;min-width:0}
 .contact-lines b,.contact-lines span{display:block;font-size:1.9mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
 .contact-lines span{opacity:.65;margin-top:.5mm}
 .signature{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1mm}
 .signature img{height:7.5mm;width:auto;mix-blend-mode:multiply;filter:contrast(1.2)}
 .signature b{font-size:1.8mm;color:#64748B;text-transform:uppercase;letter-spacing:.4mm}
 .signature span{height:6mm;width:15mm;border-bottom:.2mm solid #CBD5E1}

 /* ============================================================
 TPL 1: CORPORATE — Executive Ivory
 Navy header (full width) | Left orange photo rail | Right data
 ============================================================ */
 .tpl-corporate.front{background:linear-gradient(180deg,#FFFDF8,#F5EFE5);border-color:#D8C6A4}
 .tpl-corporate.front header{background:linear-gradient(135deg,#13224A,#1C3368)}
 .tpl-corporate.front .id-topline{left:0;right:0;top:0;height:1mm;background:#FF7900;z-index:9}
 .tpl-corporate.front .design-ribbon{left:0;right:0;bottom:0;height:4.5mm;background:#13224A;border-top:.6mm solid #B9965A;z-index:2}
 .tpl-corporate.front main{flex:1;display:grid;grid-template-columns:15mm 1fr;gap:0;padding:0 2.5mm 7mm 0;overflow:hidden}
 .tpl-corporate.front .photo-section{background:linear-gradient(180deg,#FF7900 0%,#E55A00 100%);display:flex;flex-direction:column;align-items:center;padding:2.5mm 1mm;gap:1.5mm}
 .tpl-corporate.front .photo{width:13mm!important;height:16mm!important;border-radius:2mm!important;border:.7mm solid rgba(255,255,255,.9)!important;box-shadow:0 1mm 2.5mm rgba(0,0,0,.3)}
 .tpl-corporate.front .photo-fallback{width:13mm!important;height:16mm!important;border-radius:2mm!important;font-size:4.5mm!important;background:#fff!important;color:#E55A00!important}
 .tpl-corporate.front .grade-badge{font-size:1.6mm!important;padding:.6mm 1.2mm!important;max-width:13mm;background:#13224A!important;border-color:rgba(255,255,255,.4)!important}
 .tpl-corporate.front .data-section{padding:2.5mm 0 0 2.5mm;display:flex;flex-direction:column}
 .tpl-corporate.front .data-section h3{font-size:3.2mm;color:#13224A;text-align:left}
 .tpl-corporate.front .data-section p{font-size:1.85mm;text-align:left;color:#556070}
 .tpl-corporate.front .field-grid{grid-template-columns:1fr;gap:.7mm;flex:1}
 .tpl-corporate.front .field-grid div{background:rgba(255,253,248,.96);border-color:#E0CCA8}
 .tpl-corporate.front footer{left:15.5mm!important;right:2.5mm!important;bottom:5.5mm!important;height:5mm!important}

 /* ============================================================
 TPL 2: UNIVERSITY — University Pro
 Navy header (full width) | Left orange rail + photo | Right data
 ============================================================ */
 .tpl-university.front{background:#FFFFFF;border-color:#C0D0E0}
 .tpl-university.front header{background:linear-gradient(135deg,#13224A,#1C3368)}
 .tpl-university.front .id-topline{left:0;right:0;top:0;height:1mm;background:#FF7900;z-index:9}
 .tpl-university.front main{flex:1;display:grid;grid-template-columns:16mm 1fr;gap:0;padding:0 2.5mm 7mm 0;overflow:hidden}
 .tpl-university.front .photo-section{background:linear-gradient(180deg,#FF7900 0%,#CC4400 100%);display:flex;flex-direction:column;align-items:center;padding:2.5mm 1mm;gap:1.5mm}
 .tpl-university.front .photo{width:14mm!important;height:17mm!important;border-radius:1.8mm!important;border:.7mm solid rgba(255,255,255,.9)!important;box-shadow:0 1mm 2.5mm rgba(0,0,0,.3)}
 .tpl-university.front .photo-fallback{width:14mm!important;height:17mm!important;border-radius:1.8mm!important;font-size:5mm!important;background:#fff!important;color:#CC4400!important}
 .tpl-university.front .grade-badge{font-size:1.6mm!important;padding:.6mm 1.2mm!important;max-width:14mm;background:#13224A!important;border-color:rgba(255,255,255,.4)!important}
 .tpl-university.front .data-section{padding:2.5mm 0 0 2.5mm;display:flex;flex-direction:column}
 .tpl-university.front .data-section h3{font-size:3.2mm;color:#13224A;text-align:left}
 .tpl-university.front .data-section p{font-size:1.85mm;text-align:left;color:#556070}
 .tpl-university.front .field-grid{grid-template-columns:1fr;gap:.7mm;flex:1}
 .tpl-university.front footer{left:17mm!important;right:2.5mm!important;bottom:1.5mm!important}
 .tpl-university.back{background:#fff;color:#13224A}

 /* ============================================================
 TPL 3: EXECUTIVE — Abstract Curve
 Navy arcs in top-left | Header full-width | Centered circle photo
 THEN name + role BELOW photo (no overlap) | compact field grid
 ============================================================ */
 .tpl-executive.front{background:#fff;border-color:#C0CDD8}
 .tpl-executive.front .arc-one{left:-22mm;top:-30mm;width:72mm;height:64mm;border-radius:50%;background:#13224A;z-index:0}
 .tpl-executive.front .arc-two{left:-12mm;top:-14mm;width:58mm;height:54mm;border-radius:50%;border:2.5mm solid #FF7900;border-right-color:transparent;border-bottom-color:transparent;transform:rotate(-18deg);z-index:1}
 .tpl-executive.front header{background:transparent;height:18mm;z-index:6;padding:1.8mm 2.5mm}
 .tpl-executive.front .school-logo{border-color:rgba(255,200,80,.9)!important;background:rgba(255,255,255,.95)!important;z-index:7}
 .tpl-executive.front .school-block{z-index:7}
 .tpl-executive.front main{
 flex:1;display:flex;flex-direction:column;align-items:center;
 padding:1.5mm 3.5mm 7.5mm;gap:0;overflow:hidden;
 }
 .tpl-executive.front .photo-section{
 display:flex;flex-direction:column;align-items:center;gap:0;
 margin-bottom:1.5mm;
 }
 .tpl-executive.front .photo{
 width:24mm!important;height:24mm!important;
 border-radius:50%!important;
 border:1.8mm solid #13224A!important;
 box-shadow:0 1.5mm 4mm rgba(15,23,42,.35);
 }
 .tpl-executive.front .photo-fallback{width:24mm!important;height:24mm!important;border-radius:50%!important;font-size:8mm!important;color:#13224A!important;background:#E8EEF8!important}
 .tpl-executive.front .grade-badge{font-size:1.8mm!important;margin-top:1mm;background:#FF7900!important;color:#fff!important}
 .tpl-executive.front .data-section{
 width:100%;
 background:rgba(255,255,255,.97);
 border:.2mm solid #dde4ee;border-radius:2mm;
 padding:1.8mm 2.5mm;
 box-shadow:0 .8mm 2.5mm rgba(15,23,42,.1);
 flex:1;display:flex;flex-direction:column;
 }
 .tpl-executive.front .data-section h3{text-align:center;color:#13224A;font-size:3.4mm}
 .tpl-executive.front .data-section p{text-align:center;color:#556070;font-size:2mm;margin-bottom:1mm}
 .tpl-executive.front .field-grid{grid-template-columns:1fr 1fr;gap:.8mm;flex:1}
 .tpl-executive.front footer{left:3mm!important;right:3mm!important;bottom:2mm!important}
 .tpl-executive.back .arc-one{right:-22mm;top:-28mm;width:68mm;height:56mm;border-radius:50%;background:#13224A}
 .tpl-executive.back .arc-two{left:-14mm;bottom:-14mm;width:58mm;height:30mm;border-radius:50% 50% 0 0;background:#FF7900}

 /* ============================================================
 TPL 4: SCHOOL — Prestige Badge
 Navy header | Centered circle photo | White data panel below
 ============================================================ */
 .tpl-school.front{background:linear-gradient(180deg,#F8FAFC,#fff);border-color:#C0CDD8}
 .tpl-school.front .arc-one{right:-15mm;top:-15mm;width:38mm;height:38mm;border-radius:50%;background:#13224A;z-index:0}
 .tpl-school.front .arc-two{left:-12mm;bottom:-14mm;width:40mm;height:40mm;border-radius:50%;border:2mm solid #B9965A;background:transparent;z-index:1}
 .tpl-school.front header{background:linear-gradient(135deg,#13224A,#1C3368);z-index:6}
 .tpl-school.front .school-logo{border-color:rgba(185,150,90,.8)!important}
 .tpl-school.front main{
 flex:1;display:flex;flex-direction:column;align-items:center;
 padding:2mm 3.5mm 7.5mm;gap:0;overflow:hidden;
 }
 .tpl-school.front .photo-section{
 display:flex;flex-direction:column;align-items:center;gap:0;
 margin-bottom:1.5mm;
 }
 .tpl-school.front .photo{
 width:24mm!important;height:24mm!important;
 border-radius:50%!important;border:.9mm solid #B9965A!important;
 box-shadow:0 1.5mm 4mm rgba(15,23,42,.28);
 }
 .tpl-school.front .photo-fallback{width:24mm!important;height:24mm!important;border-radius:50%!important;font-size:8mm!important;color:#13224A!important;background:#E8EEF8!important}
 .tpl-school.front .grade-badge{font-size:1.8mm!important;margin-top:1mm;background:#13224A!important;color:#fff!important;border-color:rgba(185,150,90,.6)!important}
 .tpl-school.front .data-section{
 width:100%;
 background:rgba(255,255,255,.97);
 border-radius:2mm;padding:1.8mm 2.5mm;
 box-shadow:0 .6mm 2mm rgba(0,0,0,.14);
 border:.18mm solid #E0E8F0;
 flex:1;display:flex;flex-direction:column;
 }
 .tpl-school.front .data-section h3{text-align:center;color:#13224A;font-size:3.4mm}
 .tpl-school.front .data-section p{text-align:center;color:#556070;font-size:2mm;margin-bottom:1mm}
 .tpl-school.front .field-grid{grid-template-columns:1fr 1fr;gap:.8mm;flex:1}
 .tpl-school.front footer{left:3mm!important;right:3mm!important;bottom:2mm!important}
 .tpl-school.back{background:#fff;color:#13224A}

 /* ============================================================
 TPL 5: MINIMAL — Modern White
 White header | Side dark accent | Photo left | Data right
 ============================================================ */
 .tpl-minimal.front{background:linear-gradient(90deg,#fff 60%,#F2F5FA 60%);border-color:#D0D8E8}
 .tpl-minimal.front::before{content:"";position:absolute;right:0;top:0;bottom:0;width:7mm;background:#13224A;z-index:0}
 .tpl-minimal.front header{
 background:#13224A;
 border-bottom:.4mm solid #FF7900;
 z-index:6;
 }
 .tpl-minimal.front .brand-line-main{color:#FFCD60}
 .tpl-minimal.front .brand-line-sub{color:rgba(255,255,255,.88)}
 .tpl-minimal.front main{
 flex:1;display:grid;grid-template-columns:22mm 1fr;gap:2.5mm;
 padding:3mm 9mm 7.5mm 3mm;overflow:hidden;
 }
 .tpl-minimal.front .photo-section{display:flex;flex-direction:column;align-items:center;gap:1.5mm}
 .tpl-minimal.front .photo{
 width:18mm!important;height:22mm!important;
 border-radius:2.5mm!important;border:.8mm solid #FF7900!important;
 box-shadow:0 1mm 2.5mm rgba(15,23,42,.2);
 }
 .tpl-minimal.front .photo-fallback{width:18mm!important;height:22mm!important;border-radius:2.5mm!important;font-size:6mm!important;color:#13224A!important;background:#E8EEF8!important}
 .tpl-minimal.front .grade-badge{font-size:1.8mm!important;max-width:18mm;background:#FF7900!important;color:#fff!important}
 .tpl-minimal.front .data-section{display:flex;flex-direction:column}
 .tpl-minimal.front .data-section h3{text-align:left;color:#13224A;font-size:3.2mm;background:rgba(255,255,255,.88);border-radius:1.2mm;padding:.5mm .9mm;display:inline-block}
 .tpl-minimal.front .data-section p{text-align:left;color:#556070;font-size:1.9mm}
 .tpl-minimal.front .field-grid{grid-template-columns:1fr;gap:.8mm}
 .tpl-minimal.front footer{left:3mm!important;right:8.5mm!important;bottom:2mm!important}
 `}function V(e,t){let n=[];for(let r=0;r<e.length;r+=t)n.push(e.slice(r,r+t));return n}function H(e,t,n,r,i,a,o={}){return`<section class="print-page ${t}">${e.map(e=>{if(!e)return`<div class="slot"></div>`;let s=e.id||e.emp_id||e.gr_number;return`<div class="slot">${t===`front`?i(e,n.template,r,n,o[s]||``):a(e,n.template,r,n,o[s]||``)}</div>`}).join(``)}</section>`}function U(e,t){let{cols:n}=t,r=[];for(let t=0;t<e.length;t+=n){let i=e.slice(t,t+n);for(;i.length<n;)i.push(null);r.push(...i.reverse())}return r}function W(e,t,n,r,i,a,o=null){let s=w(t),c=E(s),l=V(e,c.perPage).map(e=>`${H(e,`front`,s,n,r,i,s.qrUrls||{})}${s.doubleSided?H(U(e,c),`back`,s,n,r,i,s.qrUrls||{}):``}`).join(``),u=o||window.open(``,`_blank`,`width=1100,height=780`);u.document.open(),u.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><base href="${b(window.location.origin)}/"><title>${b(a)}</title><style>${B(s)}</style></head><body>
 <div class="no-print"><span style="font-size:14px;font-weight:800;color:#C8991A">${b(a)}</span><span style="font-size:12px;color:#C0C8D8">${e.length} cards · CR80 · ${s.orientation} · A4 ${s.pageOrientation} · ${c.cols}x${c.rows} per page · ${s.doubleSided?`double-sided aligned`:`single-sided`}</span><button onclick="window.print()" style="margin-left:auto;padding:8px 20px;background:linear-gradient(135deg,#C8991A,#e8b420);color:#071e34;border:none;border-radius:7px;cursor:pointer;font-weight:800;font-size:13px">Print / Save PDF</button></div>
 ${l}
 </body></html>`),u.document.close()}function G(e,t,n,r,i,a=`ID Cards`,o=null){W(e,t,n,r,i||z,a,o)}async function ee(e,t,n,r=null){let i=w(t),a={};i.cardOptions.showQr&&await Promise.all(e.map(async e=>{let t=e.gr_number||e.gr||String(e.id);try{a[e.id]=await l.toDataURL(t,{width:180,margin:0,color:{dark:`#0B1F3A`,light:`#FFFFFF`}})}catch{a[e.id]=``}})),W(e,{...i,qrUrls:a},n,I,L,`Student ID Cards`,r)}function te(e,t,n,r,i){if(!e||!n.length){alert(`Select a student and ensure marks are entered.`);return}let a=(i.schoolName||d).toUpperCase(),o=i.showUrduHeader===!1?``:i.schoolUrdu||a,s=k(a),c=i.address||`School Address`,l=i.phone||`-`,u=i.logo||``,f=n.map(e=>e.subject),p={};n.forEach(e=>{p[e.subject]=e.marks_obtained});let m=(t==null?void 0:t.total_marks)||100,h=(t==null?void 0:t.pass_marks)||33,g=n.reduce((e,t)=>e+Number(t.marks_obtained||0),0),b=n.length*m,x=b>0?Math.round(g/b*100):0,S=x>=90?`A+`:x>=80?`A`:x>=70?`B`:x>=60?`C`:x>=50?`D`:`F`,C=n.every(e=>Number(e.marks_obtained||0)>=h),w=new Date().toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`}),T=u?`<img src="${u}" style="height:60px;object-fit:contain;border-radius:6px">`:`<div style="width:60px;height:60px;border-radius:50%;background:#fff;border:1px solid #D9DEE8;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:900;color:#243041">${a.charAt(0)}</div>`,E=n.map((e,t)=>{let n=Number(e.marks_obtained||0),r=Math.round(n/m*100),i=r>=90?`A+`:r>=80?`A`:r>=70?`B`:r>=60?`C`:r>=50?`D`:`F`,a=_[t%_.length];return{i:t+1,sub:e.subject,total:m,obtained:n,pct:r,grade:i,pass:n>=h,col:a}}),D=v(f,p,m,r===`digital`?`#071e34`:r===`classic`?`#f5f0e8`:r===`vibrant`?`transparent`:`#fff`),O=y(f,p,m,`light`),A=f.map((e,t)=>`<div style="display:flex;align-items:center;gap:6px;margin-bottom:5px;font-size:11px"><div style="width:12px;height:12px;border-radius:3px;background:${_[t%_.length]};flex-shrink:0"></div><span>${e}</span><span style="margin-left:auto;font-weight:700">${p[e]||0}</span></div>`).join(``),j;if(r===`royal`){let r=E.map(e=>`
 <tr style="background:${e.i%2==0?`#fdf8f0`:`#fff`}">
 <td style="padding:8px 12px;border-bottom:1px solid #e8d9b5">${e.i}</td>
 <td style="padding:8px 12px;border-bottom:1px solid #e8d9b5;font-weight:600">${e.sub}</td>
 <td style="padding:8px 12px;border-bottom:1px solid #e8d9b5;text-align:center">${e.total}</td>
 <td style="padding:8px 12px;border-bottom:1px solid #e8d9b5;text-align:center;font-weight:800;color:${e.pass?`#2e7d32`:`#c62828`}">${e.obtained}</td>
 <td style="padding:8px 12px;border-bottom:1px solid #e8d9b5;text-align:center">${e.pct}%</td>
 <td style="padding:8px 12px;border-bottom:1px solid #e8d9b5;text-align:center">
 <span style="background:${e.col};color:white;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700">${e.grade}</span>
 </td>
 <td style="padding:8px 12px;border-bottom:1px solid #e8d9b5;text-align:center;font-weight:700;color:${e.pass?`#2e7d32`:`#c62828`}">${e.pass?`Pass`:`Fail`}</td>
 </tr>`).join(``);j=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Result Card - ${e.name}</title>
 <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Noto+Nastaliq+Urdu&display=swap" rel="stylesheet">
 <style>
 *{box-sizing:border-box;margin:0;padding:0}
 body{width:210mm;min-height:297mm;background:white;font-family:'Playfair Display',Georgia,serif;color:#1a0a00;print-color-adjust:exact;-webkit-print-color-adjust:exact}
 @page{size:A4 portrait;margin:0}
 @media print{body{margin:0}}
 .page{width:210mm;min-height:297mm;display:flex;flex-direction:column}
 </style></head><body>
 <div class="page">
 <!-- Header -->
 <div style="background:#FFF9EF;padding:20px 30px;position:relative;overflow:hidden;border-bottom:2px solid #D8C6A4">
 <div style="position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,#7B3448,#B9965A,#7B3448)"></div>
 <div style="display:flex;align-items:center;gap:16px;position:relative">
 ${T}
 <div style="flex:1;text-align:center">
 ${o?`<div style="font-family:'Noto Nastaliq Urdu',serif;font-size:22px;direction:rtl;color:#7B3448;margin-bottom:4px">${o}</div>`:``}
 <h1 style="color:#243041;font-size:22px;font-weight:900;letter-spacing:0.5px;margin:0">${s}</h1>
 <p style="color:#6B7280;font-size:12px;margin:5px 0 0">${c} - ${l}</p>
 </div>
 <div style="text-align:center;background:white;border:1.5px solid #D8C6A4;border-radius:10px;padding:10px 16px;box-shadow:0 6px 18px rgba(36,48,65,0.06)">
 <div style="color:#7B3448;font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase">Result Card</div>
 <div style="color:#243041;font-size:14px;font-weight:700;margin-top:3px">${(t==null?void 0:t.name)||``}</div>
 </div>
 </div>
 <div style="margin-top:14px;height:1px;background:linear-gradient(90deg,transparent,#B9965A,transparent)"></div>
 </div>

 <!-- Student Info -->
 <div style="padding:16px 30px;background:#fdf8f0;border-bottom:2px solid #e8d9b5">
 <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:14px">
 ${[[`Student Name`,e.name],[`Father Name`,e.father_name||`-`],[`Class`,(t==null?void 0:t.class)||`-`],[`Session`,`2026-2027`],[`GR Number`,e.gr_number||`-`],[`Date`,w],[`Total Subjects`,n.length],[`Exam Type`,(t==null?void 0:t.type)||`-`]].map(([e,t])=>`<div style="background:white;border:1px solid #e8d9b5;border-radius:8px;padding:10px 12px"><div style="font-size:9px;color:#8B6914;text-transform:uppercase;letter-spacing:0.8px;font-weight:600;margin-bottom:4px">${e}</div><div style="font-size:13px;font-weight:700;color:#1a0a00">${t}</div></div>`).join(``)}
 </div>
 </div>

 <!-- Marks Table -->
 <div style="padding:16px 30px">
 <div style="font-size:11px;color:#8B6914;text-transform:uppercase;letter-spacing:1px;font-weight:700;margin-bottom:10px;display:flex;align-items:center;gap:8px">Academic Performance</div>
 <table style="width:100%;border-collapse:collapse;box-shadow:0 2px 10px rgba(74,14,46,0.08);border-radius:10px;overflow:hidden">
 <thead>
 <tr style="background:linear-gradient(90deg,#4A0E2E,#6B1540)">
 ${[`#`,`Subject`,`Total Marks`,`Obtained`,`Percentage`,`Grade`,`Result`].map(e=>`<th style="padding:10px 12px;text-align:${e===`Subject`?`left`:`center`};color:#e8b420;font-size:11px;letter-spacing:0.5px;font-weight:700">${e}</th>`).join(``)}
 </tr>
 </thead>
 <tbody>${r}</tbody>
 <tfoot>
 <tr style="background:#4A0E2E">
 <td colspan="2" style="padding:10px 12px;color:#e8b420;font-weight:800;font-size:13px">GRAND TOTAL</td>
 <td style="padding:10px 12px;text-align:center;color:#e8b420;font-weight:700">${b}</td>
 <td style="padding:10px 12px;text-align:center;color:white;font-weight:900;font-size:14px">${g}</td>
 <td style="padding:10px 12px;text-align:center;color:white;font-weight:700">${x}%</td>
 <td style="padding:10px 12px;text-align:center"><span style="background:#C8991A;color:white;padding:3px 10px;border-radius:12px;font-weight:800">${S}</span></td>
 <td style="padding:10px 12px;text-align:center;color:${C?`#4CAF50`:`#FF375F`};font-weight:800;font-size:13px">${C?`PASS`:`FAIL`}</td>
 </tr>
 </tfoot>
 </table>
 </div>

 <!-- Charts -->
 <div style="padding:0 30px 16px;display:grid;grid-template-columns:200px 1fr;gap:20px;align-items:start">
 <div style="text-align:center">
 <div style="font-size:10px;color:#8B6914;text-transform:uppercase;letter-spacing:1px;font-weight:700;margin-bottom:8px">Performance Chart</div>
 ${D}
 <div style="margin-top:8px">${A}</div>
 </div>
 <div>
 <div style="font-size:10px;color:#8B6914;text-transform:uppercase;letter-spacing:1px;font-weight:700;margin-bottom:12px">Subject-wise Columns</div>
 ${O}
 </div>
 </div>

 <!-- Footer -->
 <div style="margin-top:auto;padding:16px 30px;background:#fdf8f0;border-top:2px solid #e8d9b5">
 <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;text-align:center">
 ${[`Class Teacher`,`Examination Controller`,`Principal`].map(e=>`<div>${e===`Principal`&&i.principalSignature?`<img src="${i.principalSignature}" style="height:34px;width:auto;display:block;margin:0 auto -10px;mix-blend-mode:multiply">`:``}<div style="border-top:1.5px solid #4A0E2E;padding-top:6px;font-size:11px;font-weight:600;color:#4A0E2E">${e}</div></div>`).join(``)}
 </div>
 <div style="text-align:center;margin-top:12px;font-size:9px;color:#8B6914">This result card is issued by ${a} - Generated: ${w}</div>
 </div>
 </div>
 <script>window.onload=()=>setTimeout(()=>window.print(),800)<\/script></body></html>`}else if(r===`digital`){let r=E.map(e=>`
 <tr style="border-bottom:1px solid rgba(0,245,255,0.08)">
 <td style="padding:9px 14px;color:#8892A4;font-size:12px">${e.i}</td>
 <td style="padding:9px 14px;color:#C0C8D8;font-weight:600">${e.sub}</td>
 <td style="padding:9px 14px;text-align:center;color:#8892A4">${e.total}</td>
 <td style="padding:9px 14px;text-align:center;color:${e.pass?`#00F5FF`:`#FF375F`};font-weight:800;font-size:14px">${e.obtained}</td>
 <td style="padding:9px 14px;text-align:center;color:#C0C8D8">${e.pct}%</td>
 <td style="padding:9px 14px;text-align:center"><span style="background:${e.col}22;color:${e.col};border:1px solid ${e.col}44;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700">${e.grade}</span></td>
 <td style="padding:9px 14px;text-align:center;color:${e.pass?`#30D158`:`#FF375F`};font-weight:700">${e.pass?`Pass`:`Fail`}</td>
 </tr>`).join(``);j=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Result Card - ${e.name}</title>
 <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;900&family=Noto+Nastaliq+Urdu&display=swap" rel="stylesheet">
 <style>
 *{box-sizing:border-box;margin:0;padding:0}
 body{width:210mm;min-height:297mm;background:#F4F8FA;font-family:'DM Sans',Arial,sans-serif;color:#243041;print-color-adjust:exact;-webkit-print-color-adjust:exact}
 @page{size:A4 portrait;margin:0}
 @media print{body{margin:0}}
 </style></head><body>
 <div style="width:210mm;min-height:297mm;display:flex;flex-direction:column;background:#F4F8FA">
 <!-- Header -->
 <div style="background:#FFFFFF;padding:22px 28px;border-bottom:2px solid #B8CFCE;position:relative;overflow:hidden">
 <div style="position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,#5EA8A7,#8B95A8,#5EA8A7)"></div>
 <div style="display:flex;align-items:center;gap:16px">
 ${T}
 <div style="flex:1">
 ${o?`<div style="font-family:'Noto Nastaliq Urdu',serif;font-size:18px;direction:rtl;color:#5EA8A7;margin-bottom:3px">${o}</div>`:``}
 <h1 style="color:#243041;font-size:20px;font-weight:900;margin:0">${s}</h1>
 <p style="color:#6B7280;font-size:11px;margin:4px 0 0">${c} - ${l}</p>
 </div>
 <div style="text-align:center;background:#F4F8FA;border:1px solid #B8CFCE;border-radius:12px;padding:12px 18px">
 <div style="color:#5EA8A7;font-size:9px;font-weight:700;letter-spacing:2px;text-transform:uppercase">Result Card</div>
 <div style="color:#243041;font-size:13px;font-weight:700;margin-top:4px">${(t==null?void 0:t.name)||``}</div>
 <div style="color:#6B7280;font-size:10px;margin-top:3px">${w}</div>
 </div>
 </div>
 </div>

 <!-- Student Info Bar -->
 <div style="background:rgba(0,245,255,0.04);border-bottom:1px solid rgba(0,245,255,0.1);padding:14px 28px">
 <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
 ${[[`Student`,e.name],[`Father`,e.father_name||`-`],[`Class`,(t==null?void 0:t.class)||`-`],[`GR No`,e.gr_number||`-`],[`Session`,`2026-2027`],[`Exam`,(t==null?void 0:t.type)||`-`],[`Subjects`,n.length],[`Date`,w]].map(([e,t])=>`<div style="background:rgba(255,255,255,0.7);border:1px solid #B8CFCE;border-radius:8px;padding:8px 12px"><div style="font-size:9px;color:#5EA8A7;letter-spacing:0.8px;text-transform:uppercase;margin-bottom:3px">${e}</div><div style="font-size:12px;font-weight:700;color:#243041">${t}</div></div>`).join(``)}
 </div>
 </div>

 <!-- Marks Table -->
 <div style="padding:16px 28px">
 <div style="font-size:10px;color:#5EA8A7;text-transform:uppercase;letter-spacing:2px;font-weight:700;margin-bottom:10px">Academic Results</div>
 <table style="width:100%;border-collapse:collapse;background:rgba(15,23,42,0.46);border-radius:10px;overflow:hidden;border:1px solid rgba(0,245,255,0.1)">
 <thead>
 <tr style="background:rgba(0,245,255,0.08);border-bottom:1px solid rgba(0,245,255,0.2)">
 ${[`#`,`Subject`,`Total`,`Obtained`,`Percentage`,`Grade`,`Result`].map(e=>`<th style="padding:10px 14px;text-align:${e===`Subject`?`left`:`center`};color:#00F5FF;font-size:10px;letter-spacing:1px;font-weight:700;text-transform:uppercase">${e}</th>`).join(``)}
 </tr>
 </thead>
 <tbody>${r}</tbody>
 <tfoot>
 <tr style="background:rgba(0,245,255,0.06);border-top:1px solid rgba(0,245,255,0.2)">
 <td colspan="2" style="padding:10px 14px;color:#00F5FF;font-weight:800">TOTAL</td>
 <td style="padding:10px 14px;text-align:center;color:#8892A4">${b}</td>
 <td style="padding:10px 14px;text-align:center;color:#00F5FF;font-weight:900;font-size:16px">${g}</td>
 <td style="padding:10px 14px;text-align:center;color:white;font-weight:700">${x}%</td>
 <td style="padding:10px 14px;text-align:center"><span style="background:rgba(200,153,26,0.2);color:#C8991A;border:1px solid rgba(200,153,26,0.4);padding:3px 12px;border-radius:20px;font-weight:800">${S}</span></td>
 <td style="padding:10px 14px;text-align:center;color:${C?`#30D158`:`#FF375F`};font-weight:800;font-size:13px">${C?`PASS`:`FAIL`}</td>
 </tr>
 </tfoot>
 </table>
 </div>

 <!-- Charts Row -->
 <div style="padding:0 28px 16px;display:grid;grid-template-columns:210px 1fr;gap:20px">
 <div style="background:rgba(11,44,77,0.92);border:1px solid rgba(0,245,255,0.1);border-radius:12px;padding:14px;text-align:center">
 <div style="font-size:9px;color:#00F5FF;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;margin-bottom:10px">Performance</div>
 ${D}
 <div style="margin-top:8px">${A}</div>
 </div>
 <div style="background:rgba(11,44,77,0.92);border:1px solid rgba(0,245,255,0.1);border-radius:12px;padding:14px">
 <div style="font-size:9px;color:#5EA8A7;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;margin-bottom:14px">Subject Columns</div>
 ${O}
 </div>
 </div>

 <!-- Footer -->
 <div style="margin-top:auto;padding:16px 28px;background:rgba(0,245,255,0.04);border-top:1px solid rgba(0,245,255,0.1)">
 <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;text-align:center">
 ${[`Class Teacher`,`Controller of Exams`,`Principal`].map(e=>`<div>${e===`Principal`&&i.principalSignature?`<img src="${i.principalSignature}" style="height:34px;width:auto;display:block;margin:0 auto -10px;mix-blend-mode:multiply">`:``}<div style="border-top:1px solid rgba(0,245,255,0.3);padding-top:6px;font-size:11px;color:#8892A4">${e}</div></div>`).join(``)}
 </div>
 <div style="text-align:center;margin-top:10px;font-size:9px;color:rgba(136,146,164,0.8)">${a} - Result Card - Generated ${w}</div>
 </div>
 </div>
 <script>window.onload=()=>setTimeout(()=>window.print(),800)<\/script></body></html>`}else if(r===`classic`){let r=E.map(e=>`
 <tr style="background:${e.i%2==0?`#eef2ff`:`#fff`}">
 <td style="padding:8px 12px;border:1px solid #c5cde8">${e.i}</td>
 <td style="padding:8px 12px;border:1px solid #c5cde8;font-weight:600">${e.sub}</td>
 <td style="padding:8px 12px;border:1px solid #c5cde8;text-align:center">${e.total}</td>
 <td style="padding:8px 12px;border:1px solid #c5cde8;text-align:center;font-weight:700;color:${e.pass?`#1565C0`:`#c62828`}">${e.obtained}</td>
 <td style="padding:8px 12px;border:1px solid #c5cde8;text-align:center">${e.pct}%</td>
 <td style="padding:8px 12px;border:1px solid #c5cde8;text-align:center"><span style="background:${e.col};color:white;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700">${e.grade}</span></td>
 <td style="padding:8px 12px;border:1px solid #c5cde8;text-align:center;color:${e.pass?`#2e7d32`:`#c62828`};font-weight:600">${e.pass?`Pass`:`Fail`}</td>
 </tr>`).join(``);j=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Result Card - ${e.name}</title>
 <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;900&family=Noto+Nastaliq+Urdu&display=swap" rel="stylesheet">
 <style>
 *{box-sizing:border-box;margin:0;padding:0}
 body{width:210mm;min-height:297mm;background:#f5f0e8;font-family:'DM Sans',Arial,sans-serif;color:#1a1a2e}
 @page{size:A4 portrait;margin:0}
 @media print{body{margin:0}}
 </style></head><body>
 <div style="width:210mm;min-height:297mm;background:#f5f0e8;display:flex;flex-direction:column">
 <!-- Header -->
 <div style="background:#FFFFFF;padding:20px 28px;text-align:center;border-bottom:2px solid #B7C7D8;position:relative">
 <div style="position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,#527AA3,#D8A047,#527AA3)"></div>
 <div style="display:flex;align-items:center;justify-content:center;gap:14px">
 ${T}
 <div>
 ${o?`<div style="font-family:'Noto Nastaliq Urdu',serif;font-size:18px;direction:rtl;color:#527AA3;margin-bottom:2px">${o}</div>`:``}
 <h1 style="color:#243041;font-size:20px;font-weight:900;margin:0">${s}</h1>
 <p style="color:#6B7280;font-size:11px;margin:4px 0 0">${c} - Tel: ${l}</p>
 </div>
 </div>
 <div style="margin-top:12px;background:#FAF7F0;border:1px solid #D8C6A4;border-radius:6px;padding:6px;display:inline-block;min-width:160px">
 <div style="color:#527AA3;font-size:14px;font-weight:700">RESULT CARD - ${(t==null?void 0:t.name)||``}</div>
 </div>
 </div>

 <!-- Student Info -->
 <div style="padding:14px 28px;background:#fff;border-bottom:2px solid #1565C0">
 <table style="width:100%;border-collapse:collapse">
 <tr>
 ${[[`Student Name`,e.name],[`Father Name`,e.father_name||`-`],[`Class/Section`,(t==null?void 0:t.class)||`-`],[`GR Number`,e.gr_number||`-`]].map(([e,t])=>`<td style="padding:6px 10px;font-size:12px"><span style="font-weight:600;color:#1565C0">${e}:</span> ${t}</td>`).join(``)}
 </tr>
 <tr>
 ${[[`Session`,`2026-2027`],[`Exam Type`,(t==null?void 0:t.type)||`-`],[`Result Date`,w],[`Total Subjects`,n.length]].map(([e,t])=>`<td style="padding:6px 10px;font-size:12px"><span style="font-weight:600;color:#1565C0">${e}:</span> ${t}</td>`).join(``)}
 </tr>
 </table>
 </div>

 <!-- Marks Table -->
 <div style="padding:14px 28px">
 <table style="width:100%;border-collapse:collapse;border:1px solid #c5cde8">
 <thead>
 <tr style="background:#1565C0">
 ${[`S.No`,`Subject`,`Total Marks`,`Obtained Marks`,`Percentage`,`Grade`,`Result`].map(e=>`<th style="padding:9px 12px;text-align:${e===`Subject`?`left`:`center`};color:white;font-size:11px;font-weight:700">${e}</th>`).join(``)}
 </tr>
 </thead>
 <tbody>${r}</tbody>
 <tfoot>
 <tr style="background:#e3f2fd;font-weight:700">
 <td colspan="2" style="padding:9px 12px;border:1px solid #c5cde8;color:#1565C0;font-weight:800">TOTAL</td>
 <td style="padding:9px 12px;border:1px solid #c5cde8;text-align:center">${b}</td>
 <td style="padding:9px 12px;border:1px solid #c5cde8;text-align:center;color:#1565C0;font-weight:900;font-size:15px">${g}</td>
 <td style="padding:9px 12px;border:1px solid #c5cde8;text-align:center">${x}%</td>
 <td style="padding:9px 12px;border:1px solid #c5cde8;text-align:center"><span style="background:#1565C0;color:white;padding:3px 10px;border-radius:4px;font-weight:800">${S}</span></td>
 <td style="padding:9px 12px;border:1px solid #c5cde8;text-align:center;color:${C?`#2e7d32`:`#c62828`};font-weight:800">${C?`PASS`:`FAIL`}</td>
 </tr>
 </tfoot>
 </table>
 </div>

 <!-- Charts -->
 <div style="padding:0 28px 14px;display:grid;grid-template-columns:210px 1fr;gap:20px">
 <div style="background:white;border:1px solid #c5cde8;border-radius:8px;padding:12px;text-align:center">
 <div style="font-size:10px;color:#1565C0;font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Result Overview</div>
 ${D}
 <div style="margin-top:8px;font-size:11px">${A}</div>
 </div>
 <div style="background:white;border:1px solid #c5cde8;border-radius:8px;padding:12px">
 <div style="font-size:10px;color:#1565C0;font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">Subject-wise Columns</div>
 ${O}
 </div>
 </div>

 <!-- Remarks & Footer -->
 <div style="margin-top:auto;padding:14px 28px;background:#fff;border-top:2px solid #1565C0">
 <div style="background:#e3f2fd;border-radius:6px;padding:10px 14px;margin-bottom:14px;font-size:12px;color:#1565C0">
 <strong>Remarks:</strong> <em>Student has shown ${x>=70?`excellent`:x>=50?`satisfactory`:`below average`} performance. ${x>=50?`Keep up the good work and strive for excellence.`:`More effort and dedication is required in studies.`}</em>
 </div>
 <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;text-align:center">
 ${[`Class Teacher`,`Examination Controller`,`Principal`].map(e=>`<div>${e===`Principal`&&i.principalSignature?`<img src="${i.principalSignature}" style="height:34px;width:auto;display:block;margin:0 auto -10px;mix-blend-mode:multiply">`:``}<div style="border-top:2px solid #1565C0;padding-top:6px;font-size:11px;font-weight:600;color:#1565C0">${e}</div></div>`).join(``)}
 </div>
 <div style="text-align:center;margin-top:10px;font-size:9px;color:#8892A4">${a} - This result card is an official document - ${w}</div>
 </div>
 </div>
 <script>window.onload=()=>setTimeout(()=>window.print(),800)<\/script></body></html>`}else{let r=E.map(e=>`
 <tr style="background:${e.col}18">
 <td style="padding:9px 12px;border-bottom:1px solid rgba(255,255,255,0.15);color:#666">${e.i}</td>
 <td style="padding:9px 12px;border-bottom:1px solid rgba(255,255,255,0.15);font-weight:700;color:#222">${e.sub}</td>
 <td style="padding:9px 12px;border-bottom:1px solid rgba(255,255,255,0.15);text-align:center;color:#555">${e.total}</td>
 <td style="padding:9px 12px;border-bottom:1px solid rgba(255,255,255,0.15);text-align:center;font-weight:900;font-size:15px;color:${e.col}">${e.obtained}</td>
 <td style="padding:9px 12px;border-bottom:1px solid rgba(255,255,255,0.15);text-align:center">${e.pct}%</td>
 <td style="padding:9px 12px;border-bottom:1px solid rgba(255,255,255,0.15);text-align:center"><span style="background:${e.col};color:white;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:800">${e.grade}</span></td>
 <td style="padding:9px 12px;border-bottom:1px solid rgba(255,255,255,0.15);text-align:center;font-weight:700;color:${e.pass?`#2e7d32`:`#c62828`}">${e.pass?`Pass`:`Fail`}</td>
 </tr>`).join(``);j=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Result Card - ${e.name}</title>
 <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;900&family=Noto+Nastaliq+Urdu&display=swap" rel="stylesheet">
 <style>
 *{box-sizing:border-box;margin:0;padding:0}
 body{width:210mm;min-height:297mm;background:white;font-family:'DM Sans',Arial,sans-serif;print-color-adjust:exact;-webkit-print-color-adjust:exact}
 @page{size:A4 portrait;margin:0}
 @media print{body{margin:0}}
 </style></head><body>
 <div style="width:210mm;min-height:297mm;background:white;display:flex;flex-direction:column">
 <!-- Header -->
 <div style="background:#FFF8F3;padding:22px 28px;position:relative;overflow:hidden;border-bottom:2px solid #F1D0C4">
 <div style="position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,#C9867D,#D8A047,#8BCFC3)"></div>
 <div style="display:flex;align-items:center;gap:16px;position:relative">
 ${T}
 <div style="flex:1;text-align:center">
 ${o?`<div style="font-family:'Noto Nastaliq Urdu',serif;font-size:18px;direction:rtl;color:#C9867D;margin-bottom:2px">${o}</div>`:``}
 <h1 style="color:#243041;font-size:22px;font-weight:900;margin:0">${s}</h1>
 <p style="color:#6B7280;font-size:11px;margin:4px 0 0">${c} - ${l}</p>
 </div>
 <div style="background:white;border-radius:14px;padding:12px 18px;text-align:center;border:1px solid #F1D0C4;box-shadow:0 6px 18px rgba(36,48,65,0.06)">
 <div style="color:#C9867D;font-size:11px;font-weight:700;letter-spacing:1px">RESULT CARD</div>
 <div style="color:#243041;font-size:14px;font-weight:900;margin-top:4px">${(t==null?void 0:t.name)||``}</div>
 <div style="background:${C?`#E8F5EE`:`#FCECEC`};color:${C?`#2e7d32`:`#c62828`};padding:3px 12px;border-radius:20px;font-size:12px;font-weight:800;margin-top:6px">${C?`PASS`:`FAIL`}</div>
 </div>
 </div>
 </div>

 <!-- Student Info Colorful Cards -->
 <div style="padding:14px 28px;background:#fafafa;border-bottom:1px solid #eee">
 <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px">
 ${[[`Student`,e.name,`#C9867D`],[`Father`,e.father_name||`-`,`#8BCFC3`],[`Class`,(t==null?void 0:t.class)||`-`,`#8EB6D8`],[`GR No`,e.gr_number||`-`,`#D8A047`],[`Session`,`2026-2027`,`#A987C6`],[`Exam`,(t==null?void 0:t.type)||`-`,`#7DA58A`],[`Subjects`,n.length,`#C9867D`],[`Date`,w,`#8EB6D8`]].map(([e,t,n])=>`<div style="background:${n}18;border-left:3px solid ${n};border-radius:8px;padding:8px 12px"><div style="font-size:10px;color:${n};font-weight:700;margin-bottom:3px">${e}</div><div style="font-size:12px;font-weight:700;color:#333">${t}</div></div>`).join(``)}
 </div>
 </div>

 <!-- Marks Table -->
 <div style="padding:14px 28px">
 <div style="font-size:11px;font-weight:800;color:#C9867D;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:10px">Academic Performance</div>
 <table style="width:100%;border-collapse:collapse;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08)">
 <thead>
 <tr style="background:linear-gradient(90deg,#FF6B35,#F7C948,#4ECDC4)">
 ${[`#`,`Subject`,`Total`,`Obtained`,`Percentage`,`Grade`,`Result`].map(e=>`<th style="padding:10px 12px;text-align:${e===`Subject`?`left`:`center`};color:white;font-size:11px;font-weight:800">${e}</th>`).join(``)}
 </tr>
 </thead>
 <tbody>${r}</tbody>
 <tfoot>
 <tr style="background:linear-gradient(90deg,#FF6B3522,#F7C94822,#4ECDC422)">
 <td colspan="2" style="padding:10px 12px;font-weight:900;color:#FF6B35;font-size:13px">GRAND TOTAL</td>
 <td style="padding:10px 12px;text-align:center;color:#666">${b}</td>
 <td style="padding:10px 12px;text-align:center;font-weight:900;font-size:16px;color:#FF6B35">${g}</td>
 <td style="padding:10px 12px;text-align:center;font-weight:700">${x}%</td>
 <td style="padding:10px 12px;text-align:center"><span style="background:linear-gradient(135deg,#FF6B35,#F7C948);color:white;padding:3px 12px;border-radius:20px;font-weight:800">${S}</span></td>
 <td style="padding:10px 12px;text-align:center;color:${C?`#2e7d32`:`#c62828`};font-weight:900;font-size:14px">${C?`PASS`:`FAIL`}</td>
 </tr>
 </tfoot>
 </table>
 </div>

 <!-- Charts -->
 <div style="padding:0 28px 14px;display:grid;grid-template-columns:210px 1fr;gap:20px">
 <div style="background:linear-gradient(135deg,#FF6B3512,#4ECDC412);border:1px solid #FF6B3530;border-radius:12px;padding:14px;text-align:center">
 <div style="font-size:10px;font-weight:800;color:#FF6B35;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Performance Chart</div>
 ${D}
 <div style="margin-top:8px">${A}</div>
 </div>
 <div style="background:linear-gradient(135deg,#4ECDC412,#45B7D112);border:1px solid #4ECDC430;border-radius:12px;padding:14px">
 <div style="font-size:10px;font-weight:800;color:#4ECDC4;text-transform:uppercase;letter-spacing:1px;margin-bottom:14px">Subject Columns</div>
 ${O}
 </div>
 </div>

 <!-- Footer -->
 <div style="margin-top:auto;padding:16px 28px;background:linear-gradient(90deg,#FF6B3510,#4ECDC410);border-top:3px solid transparent;border-image:linear-gradient(90deg,#FF6B35,#F7C948,#4ECDC4) 1">
 <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;text-align:center">
 ${[`Class Teacher`,`Examination Controller`,`Principal`].map((e,t)=>{let n=e===`Principal`&&i.principalSignature?`<img src="${i.principalSignature}" style="height:34px;width:auto;display:block;margin:0 auto -10px;mix-blend-mode:multiply">`:``,r=[`#FF6B35`,`#F7C948`,`#4ECDC4`][t];return`<div>${n}<div style="border-top:2px solid ${r};padding-top:6px;font-size:11px;font-weight:700;color:${r}">${e}</div></div>`}).join(``)}
 </div>
 <div style="text-align:center;margin-top:10px;font-size:9px;color:#999">${a} - Generated ${w}</div>
 </div>
 </div>
 <script>window.onload=()=>setTimeout(()=>window.print(),800)<\/script></body></html>`}let M=window.open(``,`_blank`,`width=960,height=760`);M.document.write(j),M.document.close()}var K=({children:e,style:t={}})=>(0,u.jsx)(`div`,{className:`cards-panel`,style:{background:g.card,backdropFilter:`blur(20px)`,border:`1px solid ${g.border}`,borderRadius:22,padding:24,boxShadow:`0 12px 32px rgba(7,30,52,0.28)`,...t},children:e}),q=({children:e})=>(0,u.jsx)(`label`,{style:{color:g.muted,fontSize:12,fontWeight:600,display:`block`,marginBottom:6,letterSpacing:`0.06em`},children:e}),J=({style:e={},...t})=>(0,u.jsx)(`input`,{...t,style:{width:`100%`,background:`rgba(11,44,77,0.6)`,border:`1px solid ${g.border}`,borderRadius:10,color:g.silver,padding:`10px 13px`,fontSize:14,outline:`none`,boxSizing:`border-box`,...e}}),Y=({children:e,style:t={},...n})=>(0,u.jsx)(`select`,{...n,style:{width:`100%`,background:`#0a1e35`,border:`1px solid ${g.border}`,borderRadius:10,color:g.silver,padding:`10px 13px`,fontSize:14,outline:`none`,cursor:`pointer`,boxSizing:`border-box`,...t},children:e});function X({t:e,selected:t,onSelect:n}){return(0,u.jsxs)(`div`,{onClick:()=>n(e.id),style:{cursor:`pointer`,border:`1.5px solid ${t?g.gold:`rgba(192,200,216,0.2)`}`,borderRadius:12,overflow:`hidden`,transition:`all 0.2s`,background:t?`rgba(255,255,255,0.08)`:`rgba(255,255,255,0.045)`,boxShadow:t?`0 8px 22px rgba(200,153,26,0.18)`:``},children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{height:66,background:`#fff`,display:`flex`,alignItems:`center`,gap:8,padding:`10px 12px`,position:`relative`,overflow:`hidden`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{position:`absolute`,top:0,left:0,right:0,height:8,background:e.c1}}),(0,u.jsx)(`div`,{className:`cards-node`,style:{position:`absolute`,bottom:0,left:0,right:0,height:6,background:e.c1}}),(0,u.jsx)(`div`,{className:`cards-node`,style:{position:`absolute`,top:0,bottom:0,left:10,width:18,background:e.c2}}),(0,u.jsx)(`div`,{className:`cards-node`,style:{position:`absolute`,right:-22,top:-22,width:76,height:76,borderRadius:`50%`,border:`8px solid ${e.c2}`,borderRightColor:`transparent`,borderBottomColor:`transparent`,transform:`rotate(-18deg)`,opacity:.9}}),(0,u.jsx)(`div`,{className:`cards-node`,style:{width:20,height:26,borderRadius:4,background:`#E8EEF8`,border:`2px solid ${e.c1}`,boxShadow:`0 2px 8px rgba(15,23,42,0.16)`,zIndex:1,marginLeft:18}}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{flex:1,zIndex:1},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{height:5,background:e.c1,borderRadius:4,marginBottom:5,width:`72%`}}),(0,u.jsx)(`div`,{className:`cards-node`,style:{height:4,background:`#A9B2C1`,borderRadius:4,width:`52%`}})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{width:22,height:22,borderRadius:3,background:`#fff`,border:`2px solid ${e.c1}`,zIndex:1}}),t&&(0,u.jsx)(`div`,{className:`cards-node`,style:{position:`absolute`,top:7,right:7,background:g.gold,borderRadius:`50%`,width:17,height:17,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:11,color:`#071e34`,fontWeight:900},children:`OK`})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{padding:`8px 12px`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:t?g.gold:g.silver,fontWeight:700,fontSize:13},children:e.label}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,marginTop:2},children:e.sub})]})]})}function Z(){return{primaryColor:`#0B1F3A`,secondaryColor:`#C8D2E3`,textColor:`#FFFFFF`,borderRadius:4,photoShape:`rounded`,showBarcode:!0,showQr:!1,showSignature:!0,backgroundPattern:!0}}function Q({orientation:e,setOrientation:t,pageOrientation:n,setPageOrientation:r,options:i,setOptions:a}){let o=(e,t)=>a(n=>({...n,[e]:t}));return(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gap:14},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:10},children:`Orientation & A4 Layout`}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:8},children:[[[`portrait`,`Portrait Card`],[`landscape`,`Landscape Card`]].map(([n,r])=>(0,u.jsx)(`button`,{onClick:()=>t(n),style:{padding:`10px 12px`,borderRadius:10,border:`1.5px solid ${e===n?g.gold:g.border}`,background:e===n?`rgba(200,153,26,0.12)`:`rgba(15,23,42,0.38)`,color:e===n?g.gold:g.silver,cursor:`pointer`,fontWeight:600},children:r},n)),[[`portrait`,`A4 Portrait`],[`landscape`,`A4 Landscape`]].map(([e,t])=>(0,u.jsx)(`button`,{onClick:()=>r(e),style:{padding:`10px 12px`,borderRadius:10,border:`1.5px solid ${n===e?g.blue:g.border}`,background:n===e?`rgba(10,132,255,0.12)`:`rgba(15,23,42,0.38)`,color:n===e?g.blue:g.silver,cursor:`pointer`,fontWeight:600},children:t},e))]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:10},children:`Template Customization`}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`repeat(3,1fr)`,gap:10},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Primary`}),(0,u.jsx)(J,{type:`color`,value:i.primaryColor,onChange:e=>o(`primaryColor`,e.target.value),style:{height:42,padding:4}})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Secondary`}),(0,u.jsx)(J,{type:`color`,value:i.secondaryColor,onChange:e=>o(`secondaryColor`,e.target.value),style:{height:42,padding:4}})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Text`}),(0,u.jsx)(J,{type:`color`,value:i.textColor,onChange:e=>o(`textColor`,e.target.value),style:{height:42,padding:4}})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Radius`}),(0,u.jsx)(J,{type:`number`,min:`0`,max:`8`,value:i.borderRadius,onChange:e=>o(`borderRadius`,Number(e.target.value))})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Photo Shape`}),(0,u.jsxs)(Y,{value:i.photoShape,onChange:e=>o(`photoShape`,e.target.value),children:[(0,u.jsx)(`option`,{value:`rounded`,children:`Rounded`}),(0,u.jsx)(`option`,{value:`circle`,children:`Circle`})]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Pattern`}),(0,u.jsxs)(Y,{value:String(i.backgroundPattern),onChange:e=>o(`backgroundPattern`,e.target.value===`true`),children:[(0,u.jsx)(`option`,{value:`true`,children:`On`}),(0,u.jsx)(`option`,{value:`false`,children:`Off`})]})]})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`flex`,flexWrap:`wrap`,gap:8,marginTop:10},children:[[`showQr`,`QR Code`],[`showSignature`,`Signature`]].map(([e,t])=>(0,u.jsxs)(`button`,{onClick:()=>o(e,!i[e]),style:{padding:`8px 12px`,borderRadius:20,border:`1px solid ${i[e]?g.green:g.border}`,background:i[e]?`rgba(48,209,88,0.12)`:`rgba(15,23,42,0.38)`,color:i[e]?g.green:g.muted,cursor:`pointer`,fontWeight:600,fontSize:12},children:[t,`: `,i[e]?`On`:`Off`]},e))})]})]})}function $(e=`Generating cards... Please wait...`){let t=window.open(``,`_blank`,`width=1100,height=780`);return t?(t.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${e}</title>
 <style>
 html,body{margin:0;height:100%;background:#071e34;color:#fff;font-family:Aptos,Segoe UI,Arial,sans-serif}
 body{display:grid;place-items:center}
 .shell{width:min(560px,92vw);padding:34px 28px;border-radius:24px;border:1px solid rgba(200,153,26,.24);background:linear-gradient(180deg,rgba(11,44,77,.98),rgba(7,30,52,.98));box-shadow:0 22px 48px rgba(0,0,0,.35);text-align:center}
 .title{font-size:28px;font-weight:600;letter-spacing:.01em;margin:0 0 10px;color:#fff}
 .sub{font-size:14px;color:rgba(192,200,216,.85);line-height:1.7}
 </style></head><body><div class="shell"><div class="title">${e}</div><div class="sub">We are preparing your cards in a live print window. This should only take a moment.</div></div></body></html>`),t.document.close(),t):null}function ne({school:e}){let{students:t}=a(),{classNames:n,sectionsForClass:r}=i(),[o,s]=(0,c.useState)(`single`),[l,d]=(0,c.useState)(`corporate`),[f,m]=(0,c.useState)(`cr80`),[_,v]=(0,c.useState)(`portrait`),[y,b]=(0,c.useState)(`portrait`),[x,S]=(0,c.useState)(!1),[C,w]=(0,c.useState)(Z),[T,E]=(0,c.useState)(``),[D,O]=(0,c.useState)(``),[k,A]=(0,c.useState)(`Starter`),[j,M]=(0,c.useState)(`All`),[N,P]=(0,c.useState)(``),F=n!=null&&n.length?n:[`Starter`],I=[`All`,...((r==null?void 0:r(k))||[]).filter(Boolean)];(0,c.useEffect)(()=>{F.includes(k)||A(F[0]||`Starter`)},[F,k]),(0,c.useEffect)(()=>{I.includes(j)||M(`All`)},[I,j]);let L=t.map(e=>({...e,name:e.name||``,gr_number:e.gr_number||e.gr||``,class:e.class||``,section:e.section||``,parent_phone:e.parent_phone||e.phone||e.whatsapp||``,father_name:e.father_name||e.father||``})),R=async()=>{let t;if(o===`single`){let e=(D||``).trim(),n=e.toLowerCase().replace(/^gr-?/i,``),r=L.find(t=>{let r=(t.gr_number||``).toLowerCase().replace(/^gr-?/i,``);return(t.gr_number||``).toLowerCase()===e.toLowerCase()||r===n||String(t.id)===e});if(!r){P(`Student not found. Check GR Number.`);return}t=[r]}else if(t=L.filter(e=>e.class===k&&(j===`All`||e.section===j)),!t.length){P(`No students found for this class/section.`);return}let n=$(`Generating cards... Please wait...`);if(!n){alert(`Popup blocked! Please allow popups for this site to generate cards.`);return}P(`Generating ${t.length} card(s)...`);try{await ee(t,{template:l,size:f,orientation:_,pageOrientation:y,doubleSided:x,cardOptions:C,cardsPerPage:T||null},e,n)}catch(e){try{n.close()}catch{}throw e}setTimeout(()=>P(``),3e3)},z=h.find(e=>e.id===f)||h[0];return(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gap:24},children:(0,u.jsxs)(K,{children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{marginBottom:18},children:[(0,u.jsx)(`h3`,{style:{color:g.gold,fontSize:17,margin:`0 0 4px`,fontFamily:`'Playfair Display',serif`},children:`Student ID Cards`}),(0,u.jsx)(`p`,{style:{color:g.muted,fontSize:13,margin:0},children:`Generate single or class-wise ID cards in multiple sizes and designs.`})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`flex`,gap:4,background:`rgba(7,30,52,0.5)`,borderRadius:14,padding:4,width:`fit-content`,marginBottom:20},children:[{id:`single`,label:`Single Student`},{id:`classwise`,label:`Class Wise`}].map(e=>(0,u.jsx)(`button`,{onClick:()=>s(e.id),style:{padding:`8px 18px`,borderRadius:12,border:`none`,cursor:`pointer`,fontWeight:600,fontSize:13,background:o===e.id?`linear-gradient(135deg,${g.gold},${g.goldL})`:`transparent`,color:o===e.id?`#071e34`:g.muted,transition:`all 0.15s`},children:e.label},e.id))}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:o===`single`?`1fr auto`:`1fr 1fr auto`,gap:14,marginBottom:22,alignItems:`flex-end`},children:[o===`single`?(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`GR Number / Student ID`}),(0,u.jsx)(J,{value:D,onChange:e=>O(e.target.value),placeholder:`Enter GR Number (e.g. GR-4005)`})]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Class`}),(0,u.jsx)(Y,{value:k,onChange:e=>A(e.target.value),children:F.map(e=>(0,u.jsx)(`option`,{style:{background:`#0a1e35`,color:g.silver},children:e},e))})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Section`}),(0,u.jsx)(Y,{value:j,onChange:e=>M(e.target.value),children:I.map(e=>(0,u.jsx)(`option`,{style:{background:`#0a1e35`,color:g.silver},children:e},e))})]})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{paddingBottom:1},children:[o===`single`&&(0,u.jsx)(q,{children:`\xA0`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:12,marginBottom:6},children:`\xA0`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`flex`,gap:8},children:(0,u.jsx)(`button`,{onClick:R,style:{padding:`10px 22px`,border:`none`,borderRadius:10,background:`linear-gradient(135deg,${g.gold},${g.goldL})`,color:`#071e34`,fontWeight:600,cursor:`pointer`,whiteSpace:`nowrap`},children:`Generate & Print`})})]})]}),N&&(0,u.jsx)(`div`,{className:`cards-node`,style:{color:N.includes(`not found`)||N.includes(`No students`)?g.red:g.green,fontWeight:600,fontSize:13,marginBottom:16},children:N}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{marginBottom:20},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:12},children:`Template Design`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit,minmax(170px,1fr))`,gap:12,position:`relative`},children:p.map(e=>(0,u.jsx)(X,{t:e,selected:l===e.id,onSelect:d},e.id))})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:16},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:10},children:`Card Size`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`1fr`,gap:8},children:h.map(e=>(0,u.jsxs)(`div`,{onClick:()=>m(e.id),style:{cursor:`pointer`,padding:`10px 14px`,borderRadius:10,border:`1.5px solid ${f===e.id?g.gold:g.border}`,background:f===e.id?`rgba(200,153,26,0.1)`:`rgba(15,23,42,0.38)`,transition:`all 0.15s`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:f===e.id?g.gold:g.silver,fontWeight:700,fontSize:13},children:e.label}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,marginTop:2},children:e.desc}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:10,marginTop:1},children:e.note})]},e.id))})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:10},children:`Print Options`}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`flex`,flexDirection:`column`,gap:10},children:[[{id:!1,label:`Single Sided`,desc:`Front side only`},{id:!0,label:`Double Sided`,desc:`Front + Back - 2 pages`}].map(e=>(0,u.jsxs)(`div`,{onClick:()=>S(e.id),style:{cursor:`pointer`,padding:`12px 16px`,borderRadius:10,border:`1.5px solid ${x===e.id?g.gold:g.border}`,background:x===e.id?`rgba(200,153,26,0.1)`:`rgba(15,23,42,0.38)`,display:`flex`,alignItems:`center`,gap:10,transition:`all 0.15s`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{width:18,height:18,borderRadius:`50%`,border:`2px solid ${x===e.id?g.gold:g.border}`,background:x===e.id?g.gold:``,display:`flex`,alignItems:`center`,justifyContent:`center`,flexShrink:0},children:x===e.id&&(0,u.jsx)(`div`,{className:`cards-node`,style:{width:8,height:8,borderRadius:`50%`,background:`#071e34`}})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:x===e.id?g.gold:g.silver,fontWeight:700,fontSize:13},children:e.label}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11},children:e.desc})]})]},String(e.id))),(0,u.jsxs)(`div`,{className:`cards-node`,style:{padding:`10px 14px`,borderRadius:10,background:`rgba(15,23,42,0.5)`,border:`1px solid ${g.border}`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,textTransform:`uppercase`,letterSpacing:`0.06em`,marginBottom:8},children:`Cards per A4 Page`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`flex`,flexWrap:`wrap`,gap:6,marginBottom:8},children:[`Auto`,`1`,`2`,`3`,`4`,`6`,`8`,`9`].map(e=>(0,u.jsx)(`button`,{onClick:()=>E(e===`Auto`?``:e),style:{padding:`6px 13px`,borderRadius:8,border:`1.5px solid ${(e===`Auto`?``:e)===T?g.gold:g.border}`,background:(e===`Auto`?``:e)===T?`rgba(200,153,26,0.16)`:`rgba(15,23,42,0.6)`,color:(e===`Auto`?``:e)===T?g.gold:g.muted,fontWeight:700,fontSize:12,cursor:`pointer`,minWidth:40,transition:`all .15s`},children:e},e))}),x&&(0,u.jsx)(`div`,{className:`cards-node`,style:{color:`#4CAF8B`,fontSize:10,fontWeight:600},children:` Double-sided: each student's front & back print on same page position.`})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{padding:`10px 14px`,borderRadius:10,background:`rgba(10,132,255,0.08)`,border:`1px solid rgba(10,132,255,0.2)`},children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{color:`#0A84FF`,fontSize:11,fontWeight:600},children:[`Current: `,z.label,` - `,z.note]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,marginTop:3},children:[`Print on A4 `,y,`. Card orientation: `,_,`. Front/back positions remain mirrored.`]})]})]})]})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{marginTop:16},children:(0,u.jsx)(Q,{orientation:_,setOrientation:v,pageOrientation:y,setPageOrientation:b,options:C,setOptions:w})})]})})}function re({school:e}){let[t,n]=(0,c.useState)([]),[i,a]=(0,c.useState)([]),[o,s]=(0,c.useState)(``),[l,d]=(0,c.useState)(``),[f,p]=(0,c.useState)(`royal`),[h,y]=(0,c.useState)(!1),b=()=>{o&&(y(!0),a([]),d(``),r.get(`/api/exams/results/${o}`).then(e=>{let t=e.data.data||[];a(t);let n=[...new Set(t.map(e=>e.student_id))];n.length&&d(String(n[0]))}).catch(()=>a([])).finally(()=>y(!1)))};(0,c.useEffect)(()=>{r.get(`/api/exams`).then(e=>{let t=e.data.data||[];n(t),t.length&&s(String(t[0].id))}).catch(()=>{})},[]);let x=[...new Map(i.map(e=>[e.student_id,{id:e.student_id,name:e.name,gr_number:e.gr_number,father_name:e.father_name}])).values()],S=i.filter(e=>String(e.student_id)===l),C=x.find(e=>String(e.id)===l),w=t.find(e=>String(e.id)===o),T=S.reduce((e,t)=>e+Number(t.marks_obtained||0),0),E=S.length*((w==null?void 0:w.total_marks)||100),D=E>0?Math.round(T/E*100):0,O=S.map(e=>e.subject),k=S.reduce((e,t)=>({...e,[t.subject]:Number(t.marks_obtained||0)}),{}),A=(w==null?void 0:w.total_marks)||100,j=S.length?v(O,k,A,`#0f172a`):``;return(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gap:24},children:(0,u.jsxs)(K,{children:[(0,u.jsx)(`h3`,{style:{color:g.gold,fontSize:17,margin:`0 0 4px`,fontFamily:`'Playfair Display',serif`},children:`Result Cards`}),(0,u.jsx)(`p`,{style:{color:g.muted,fontSize:13,margin:`0 0 20px`},children:`4 world-class templates. A4 portrait with pie chart, bar chart & signatures.`}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr auto`,gap:14,marginBottom:20,alignItems:`flex-end`},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Select Exam`}),(0,u.jsx)(Y,{value:o,onChange:e=>{s(e.target.value),a([]),d(``)},children:t.map(e=>(0,u.jsxs)(`option`,{value:e.id,style:{background:`#0a1e35`,color:g.silver},children:[e.name,` (`,e.class,`)`]},e.id))})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Select Student`}),(0,u.jsx)(Y,{value:l,onChange:e=>d(e.target.value),disabled:!x.length,children:x.length?x.map(e=>(0,u.jsxs)(`option`,{value:e.id,style:{background:`#0a1e35`,color:g.silver},children:[e.name,` (`,e.gr_number,`)`]},e.id)):(0,u.jsx)(`option`,{style:{background:`#0a1e35`,color:g.silver},children:`Click Load first`})})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`flex`,gap:8},children:[(0,u.jsx)(`button`,{onClick:b,disabled:h||!o,style:{padding:`10px 18px`,borderRadius:10,background:`rgba(10,132,255,0.2)`,border:`1px solid rgba(10,132,255,0.3)`,color:`#0A84FF`,fontWeight:600,cursor:`pointer`,whiteSpace:`nowrap`},children:h?`Loading...`:`Load`}),(0,u.jsx)(`button`,{onClick:()=>te(C,w,S,f,e),disabled:!C||!S.length,style:{padding:`10px 18px`,border:`none`,borderRadius:10,background:`linear-gradient(135deg,${g.gold},${g.goldL})`,color:`#071e34`,fontWeight:600,cursor:`pointer`,whiteSpace:`nowrap`},children:`Print`})]})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{marginBottom:20},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:12},children:`Template Design`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`repeat(4,1fr)`,gap:12},children:m.map(e=>(0,u.jsx)(X,{t:e,selected:f===e.id,onSelect:p},e.id))})]}),C&&S.length>0&&(0,u.jsxs)(`div`,{className:`cards-node`,style:{background:`rgba(15,23,42,0.46)`,borderRadius:14,padding:20,border:`1px solid ${g.border}`},children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,marginBottom:16,flexWrap:`wrap`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.gold,fontSize:16,fontWeight:800},children:C.name}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:12,marginTop:3},children:[w==null?void 0:w.name,` - `,w==null?void 0:w.class]})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`flex`,gap:12,alignItems:`center`},children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{textAlign:`center`},children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{color:D>=50?g.green:g.red,fontSize:30,fontWeight:900},children:[D,`%`]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11},children:[T,`/`,E]})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{background:D>=50?`rgba(48,209,88,0.12)`:`rgba(255,55,95,0.12)`,border:`1px solid ${D>=50?g.green:g.red}`,borderRadius:8,padding:`6px 14px`,color:D>=50?g.green:g.red,fontWeight:800},children:D>=50?`PASS`:`FAIL`})]})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`230px 1fr`,gap:16,marginBottom:16},children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{background:`rgba(255,255,255,0.045)`,border:`1px solid ${g.border}`,borderRadius:14,padding:14,textAlign:`center`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:800,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:8},children:`Pie Chart`}),(0,u.jsx)(`div`,{dangerouslySetInnerHTML:{__html:j}})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{background:`rgba(255,255,255,0.045)`,border:`1px solid ${g.border}`,borderRadius:14,padding:14},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:800,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:10},children:`Subject Columns`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{height:170,display:`flex`,alignItems:`flex-end`,gap:10,padding:`10px 4px 0`},children:S.map((e,t)=>{let n=Number(e.marks_obtained||0),r=Math.round(n/A*100),i=_[t%_.length];return(0,u.jsxs)(`div`,{className:`cards-node`,style:{flex:1,minWidth:0,height:`100%`,display:`flex`,flexDirection:`column`,alignItems:`center`,justifyContent:`flex-end`,gap:6},children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{color:i,fontSize:11,fontWeight:900},children:[r,`%`]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{width:`68%`,height:`${Math.max(10,r)}%`,borderRadius:`9px 9px 3px 3px`,background:`linear-gradient(180deg,${i},${i}cc)`,boxShadow:`0 8px 18px ${i}33`}}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.silver,fontSize:10,fontWeight:700,maxWidth:70,overflow:`hidden`,textOverflow:`ellipsis`,whiteSpace:`nowrap`},children:e.subject})]},`${e.subject}-col`)})})]})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gap:8},children:S.map((e,t)=>{let n=Number(e.marks_obtained||0),r=Math.round(n/((w==null?void 0:w.total_marks)||100)*100),i=_[t%_.length];return(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:10,padding:`8px 12px`,borderRadius:8,background:`rgba(7,30,52,0.4)`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{width:12,height:12,borderRadius:3,background:i,flexShrink:0}}),(0,u.jsx)(`span`,{style:{color:g.silver,flex:1},children:e.subject}),(0,u.jsx)(`div`,{className:`cards-node`,style:{flex:2,height:6,background:`rgba(255,255,255,0.06)`,borderRadius:3,overflow:`hidden`},children:(0,u.jsx)(`div`,{className:`cards-node`,style:{height:`100%`,width:`${r}%`,background:i,borderRadius:3}})}),(0,u.jsxs)(`span`,{style:{color:i,fontWeight:700,minWidth:50,textAlign:`right`},children:[n,`/`,(w==null?void 0:w.total_marks)||100]})]},e.subject)})})]}),!C&&!h&&(0,u.jsx)(`div`,{className:`cards-node`,style:{padding:40,textAlign:`center`,color:g.muted},children:`Select exam, click Load, then select student`})]})})}function ie({school:e}){let[t,n]=(0,c.useState)([]),[i,a]=(0,c.useState)(!1),[o,s]=(0,c.useState)(`all`),[l,d]=(0,c.useState)(``),[f,m]=(0,c.useState)(``),[_,v]=(0,c.useState)(`corporate`),[y,b]=(0,c.useState)(`cr80`),[x,S]=(0,c.useState)(`portrait`),[C,w]=(0,c.useState)(`portrait`),[T,E]=(0,c.useState)(!1),[D,O]=(0,c.useState)(Z),[k,A]=(0,c.useState)(``),[j,M]=(0,c.useState)(``);(0,c.useEffect)(()=>{a(!0),r.get(`/api/employees`).then(e=>{let t=e.data.data||e.data||[];n(t),t.length&&m(t[0].department||``)}).catch(()=>n([])).finally(()=>a(!1))},[]);let N=[...new Set(t.map(e=>e.department).filter(Boolean))],P=async()=>{let n;if(o===`single`){let e=(l||``).trim().toLowerCase(),r=t.find(t=>(t.emp_id||``).toLowerCase()===e||String(t.id)===e);if(!r){M(`Employee not found. Check Employee ID.`);return}n=[r]}else if(o===`department`){if(n=t.filter(e=>e.department===f),!n.length){M(`No employees found in this department.`);return}}else if(n=[...t],!n.length){M(`No employees found.`);return}let r=$(`Generating cards... Please wait...`);if(!r){alert(`Popup blocked! Please allow popups for this site to generate cards.`);return}M(`Generating ${n.length} card(s)...`);try{await G(n,{template:_,size:y,orientation:x,pageOrientation:C,doubleSided:T,cardOptions:D,cardsPerPage:k||null},e,R,z,`Employee ID Cards`,r)}catch(e){try{r.close()}catch{}throw e}setTimeout(()=>M(``),3e3)},F=h.find(e=>e.id===y)||h[0];return(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gap:24},children:(0,u.jsxs)(K,{children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{marginBottom:18},children:[(0,u.jsx)(`h3`,{style:{color:g.gold,fontSize:17,margin:`0 0 4px`,fontFamily:`'Playfair Display',serif`},children:`Employee ID Cards`}),(0,u.jsx)(`p`,{style:{color:g.muted,fontSize:13,margin:0},children:`Generate staff / teacher ID cards with QR codes for attendance marking.`})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`flex`,gap:4,background:`rgba(7,30,52,0.5)`,borderRadius:10,padding:4,width:`fit-content`,marginBottom:20},children:[{id:`all`,label:`All Staff`},{id:`single`,label:`Single`},{id:`department`,label:`Department`}].map(e=>(0,u.jsx)(`button`,{onClick:()=>s(e.id),style:{padding:`8px 18px`,borderRadius:8,border:`none`,cursor:`pointer`,fontWeight:600,fontSize:13,background:o===e.id?`linear-gradient(135deg,${g.gold},${g.goldL})`:`transparent`,color:o===e.id?`#071e34`:g.muted,transition:`all 0.15s`},children:e.label},e.id))}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`1fr auto`,gap:14,marginBottom:22,alignItems:`flex-end`},children:[o===`single`&&(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Employee ID`}),(0,u.jsx)(J,{value:l,onChange:e=>d(e.target.value),placeholder:`e.g. EMP-001`})]}),o===`department`&&(0,u.jsxs)(`div`,{children:[(0,u.jsx)(q,{children:`Department`}),(0,u.jsx)(Y,{value:f,onChange:e=>m(e.target.value),children:N.length?N.map(e=>(0,u.jsx)(`option`,{style:{background:`#0a1e35`,color:g.silver},children:e},e)):(0,u.jsx)(`option`,{style:{background:`#0a1e35`,color:g.silver},children:`No departments`})})]}),o===`all`&&(0,u.jsx)(`div`,{className:`cards-node`,style:{padding:`10px 14px`,borderRadius:10,background:`rgba(10,132,255,0.08)`,border:`1px solid rgba(10,132,255,0.2)`},children:(0,u.jsx)(`div`,{className:`cards-node`,style:{color:`#0A84FF`,fontSize:12,fontWeight:600},children:i?`Loading employees...`:`${t.length} employee(s) found`})}),(0,u.jsx)(`div`,{children:(0,u.jsx)(`button`,{onClick:P,disabled:i,style:{padding:`10px 22px`,border:`none`,borderRadius:10,background:`linear-gradient(135deg,${g.gold},${g.goldL})`,color:`#071e34`,fontWeight:600,cursor:`pointer`,whiteSpace:`nowrap`},children:`Generate & Print`})})]}),j&&(0,u.jsx)(`div`,{className:`cards-node`,style:{color:j.includes(`not found`)||j.includes(`No `)?g.red:g.green,fontWeight:600,fontSize:13,marginBottom:16},children:j}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{marginBottom:20},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:12},children:`Template Design`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit,minmax(170px,1fr))`,gap:12},children:p.map(e=>(0,u.jsx)(X,{t:e,selected:_===e.id,onSelect:v},e.id))})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:16},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:10},children:`Card Size`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`grid`,gridTemplateColumns:`1fr`,gap:8},children:h.map(e=>(0,u.jsxs)(`div`,{onClick:()=>b(e.id),style:{cursor:`pointer`,padding:`10px 14px`,borderRadius:12,border:`1.5px solid ${y===e.id?g.gold:g.border}`,background:y===e.id?`rgba(200,153,26,0.1)`:`rgba(15,23,42,0.38)`,transition:`all 0.15s`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:y===e.id?g.gold:g.silver,fontWeight:700,fontSize:13},children:e.label}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,marginTop:2},children:e.desc}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:10,marginTop:1},children:e.note})]},e.id))})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,letterSpacing:`0.08em`,textTransform:`uppercase`,marginBottom:10},children:`Print Options`}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{display:`flex`,flexDirection:`column`,gap:10},children:[[{id:!1,label:`Single Sided`,desc:`Front side only`},{id:!0,label:`Double Sided`,desc:`Front + Back - 2 pages`}].map(e=>(0,u.jsxs)(`div`,{onClick:()=>E(e.id),style:{cursor:`pointer`,padding:`12px 16px`,borderRadius:12,border:`1.5px solid ${T===e.id?g.gold:g.border}`,background:T===e.id?`rgba(200,153,26,0.1)`:`rgba(15,23,42,0.38)`,display:`flex`,alignItems:`center`,gap:10,transition:`all 0.15s`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{width:18,height:18,borderRadius:`50%`,border:`2px solid ${T===e.id?g.gold:g.border}`,background:T===e.id?g.gold:``,display:`flex`,alignItems:`center`,justifyContent:`center`,flexShrink:0},children:T===e.id&&(0,u.jsx)(`div`,{className:`cards-node`,style:{width:8,height:8,borderRadius:`50%`,background:`#071e34`}})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:T===e.id?g.gold:g.silver,fontWeight:700,fontSize:13},children:e.label}),(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11},children:e.desc})]})]},String(e.id))),(0,u.jsxs)(`div`,{className:`cards-node`,style:{padding:`10px 14px`,borderRadius:12,background:`rgba(15,23,42,0.5)`,border:`1px solid ${g.border}`},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,fontWeight:700,textTransform:`uppercase`,letterSpacing:`0.06em`,marginBottom:8},children:`Cards per A4 Page`}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`flex`,flexWrap:`wrap`,gap:6,marginBottom:8},children:[`Auto`,`1`,`2`,`3`,`4`,`6`,`8`,`9`].map(e=>(0,u.jsx)(`button`,{onClick:()=>A(e===`Auto`?``:e),style:{padding:`6px 13px`,borderRadius:8,border:`1.5px solid ${(e===`Auto`?``:e)===k?g.gold:g.border}`,background:(e===`Auto`?``:e)===k?`rgba(200,153,26,0.16)`:`rgba(15,23,42,0.6)`,color:(e===`Auto`?``:e)===k?g.gold:g.muted,fontWeight:700,fontSize:12,cursor:`pointer`,minWidth:40,transition:`all .15s`},children:e},e))}),T&&(0,u.jsx)(`div`,{className:`cards-node`,style:{color:`#4CAF8B`,fontSize:10,fontWeight:600},children:` Double-sided: each employee's front & back print on same page position.`})]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{padding:`10px 14px`,borderRadius:10,background:`rgba(10,132,255,0.08)`,border:`1px solid rgba(10,132,255,0.2)`},children:[(0,u.jsxs)(`div`,{className:`cards-node`,style:{color:`#0A84FF`,fontSize:11,fontWeight:600},children:[`Current: `,F.label,` - `,F.note]}),(0,u.jsxs)(`div`,{className:`cards-node`,style:{color:g.muted,fontSize:11,marginTop:3},children:[`Print on A4 `,C,`. Card orientation: `,x,`. Front/back positions remain mirrored.`]})]})]})]})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{marginTop:16},children:(0,u.jsx)(Q,{orientation:x,setOrientation:S,pageOrientation:C,setPageOrientation:w,options:D,setOptions:O})})]})})}function ae(){let[e,t]=(0,c.useState)(`student-id`),{paperSettings:n}=o(),r={schoolName:(n.schoolName||d).toUpperCase(),schoolUrdu:n.schoolUrdu||(n.schoolName||d).toUpperCase(),address:n.address||``,phone:n.phone||``,logo:n.logo||n.schoolLogo||``,principalSignature:n.principalSignature||``,showUrduHeader:n.showUrduHeader!==!1};return(0,u.jsx)(`div`,{className:`cards-node`,style:{minHeight:`100vh`,background:g.bg,color:g.silver,padding:24,fontFamily:`var(--font-body, 'DM Sans', Arial, sans-serif)`},children:(0,u.jsxs)(`div`,{className:`cards-node`,style:{maxWidth:1100,margin:`0 auto`,display:`grid`,gap:22},children:[(0,u.jsxs)(K,{style:{padding:`18px 24px`,display:`flex`,alignItems:`center`,gap:16},children:[(0,u.jsx)(`div`,{className:`cards-node`,style:{width:50,height:50,borderRadius:15,background:`rgba(200,153,26,0.16)`,border:`1px solid rgba(200,153,26,0.35)`,display:`grid`,placeItems:`center`,fontSize:20,color:g.gold,fontWeight:900},children:`ID`}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h1`,{style:{margin:0,fontSize:24,color:`#fff`,fontFamily:`'Playfair Display',serif`,fontWeight:800},children:`Cards Generator`}),(0,u.jsx)(`p`,{style:{margin:`4px 0 0`,color:g.muted,fontSize:13},children:`World-class Student ID cards & Result cards with live print preview`})]})]}),(0,u.jsx)(`div`,{className:`cards-node`,style:{display:`flex`,gap:8},children:[{id:`student-id`,label:`Student ID Cards`},{id:`employee-id`,label:`Employee ID Cards`},{id:`result-card`,label:`Result Cards`}].map(n=>(0,u.jsx)(`button`,{onClick:()=>t(n.id),style:{padding:`11px 24px`,borderRadius:12,border:e===n.id?`none`:`1px solid ${g.border}`,cursor:`pointer`,fontWeight:600,fontSize:14,transition:`all 0.18s`,background:e===n.id?`linear-gradient(135deg,${g.gold},${g.goldL})`:`rgba(15,23,42,0.46)`,color:e===n.id?`#071e34`:g.silver},children:n.label},n.id))}),e===`student-id`&&(0,u.jsx)(ne,{school:r}),e===`employee-id`&&(0,u.jsx)(ie,{school:r}),e===`result-card`&&(0,u.jsx)(re,{school:r})]})})}export{ae as default};