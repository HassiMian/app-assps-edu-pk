import{a as e}from"./rolldown-runtime-BYbx6iT9.js";import{n as t,r as n}from"./vendor-motion-DoYOP1Wm.js";import{Hn as r,In as i,ot as a}from"./vendor-react-TqftcNZp.js";import{f as o,n as s}from"./index-Crdi7rpf.js";import{a as c}from"./useAcademicStore-CUKoORgi.js";import{t as l}from"./usePaperStore-CcjifFUq.js";import{a as u,c as d,i as f,n as p,o as m,r as h,s as g,t as _}from"./moduleStyles-DWA0RtZX.js";import{t as ee}from"./useFamilyStore-BG4975Rw.js";var v=Object.freeze({schoolName:`Al Siddique Scholars Public School`,urduName:`الصدّيق اسکالرز پبلک اسکول`,address:`Sharif Chowk, Rayya Khas, Narowal`,urduAddress:`شریف چوک، رایا خاص، نارووال`,location:`Sharif Chowk, Rayya Khas, Narowal`,urduLocation:`شریف چوک، رایا خاص، نارووال`,helpline:`+92 306 9545996`,ownerPhone:`+92 300 1291959`,botPhone:`+1 581 662 9843`,website:`https://app.assps.edu.pk`,portal:`https://app.assps.edu.pk`,timings:`08:00 AM – 01:30 PM (Mon–Sat)`,urduTimings:`صبح 08:00 بجے تا دوپہر 01:30 بجے (پیر تا ہفتہ)`,academicSession:`2026-2027`,offerings:`Starter to 10th Grade & Hifaz Class`,urduOfferings:`اسٹارٹر سے دسویں جماعت اور حفظ کلاس`}),te=`Please ensure that the fee is paid by the due date to avoid any late charges. Retain the receipt after making the payment for future reference. Payments can be made online or at the school's designated counters. For any questions or assistance, feel free to contact the school office.`;function ne(e=1){let t=`#0a1628`,n=`#c8991a`,r=`#0a1628`,i=`#e8c87a`,a=`#0a1628`,o=`#e0e0e0`,s=`#000`,c=`#0a1628`,l=`Arial, sans-serif`,u=`border:2.5px solid rgba(150,60,60,0.25); color:rgba(150,60,60,0.28); font-weight:900;`;return e===2?(t=`#1e1b4b`,n=`#b45309`,r=`linear-gradient(135deg, #1e1b4b 0%, #312e81 100%)`,i=`#fef08a`,a=`#1e1b4b`,o=`#f1f5f9`,s=`#1e293b`,c=`#312e81`,l=`'Georgia', serif`,u=`border:2.5px dashed rgba(220,38,38,0.38); color:rgba(220,38,38,0.42); font-weight:900; font-family:sans-serif;`):e===3&&(t=`#333333`,n=`#666666`,r=`#f3f4f6`,i=`#111111`,a=`#111111`,o=`#f3f4f6`,s=`#111111`,c=`#666666`,l=`'Courier New', Courier, monospace`,u=`border:1.5px solid #999; color:#999; font-style:italic; font-weight:900; font-family:sans-serif;`),{primaryColor:t,secondaryColor:n,headerBg:r,headerText:i,schoolNameColor:a,tableHeaderBg:o,tableHeaderColor:s,outerBorderColor:c,cardBg:`#fff`,fontFam:l,stampStyle:u}}function y(e={},t){var n,r,i,a,o,s,c,l,u;let d=Number((n=(r=e.monthly_fee)==null?e.amount:r)==null?0:n),f=Number((i=e.paper_fund)==null?0:i),p=Number((a=(o=e.previous_arrears)==null?e.prev_month_fee:o)==null?0:a),m=Number((s=t==null?e.discount:t)==null?0:s),h=Number((c=e.gross_total)==null?Math.max(0,d+f+p-m):c),g=Number((l=e.paid_amount)==null?0:l);return{monthly:d,paperFund:f,arrears:p,discount:m,gross:h,paid:g,remaining:Number((u=e.remaining_balance)==null?Math.max(0,h-g):u)}}function re(e,t){if(e.feeHeads&&Array.isArray(e.feeHeads)){let n=``;return e.feeHeads.forEach((e,t)=>{let r=t%2==0;n+=`
        <tr style="border-bottom:1px solid #e8e8e8; background:${r?`#f7f7f7`:`#fff`};">
          <td style="padding:4px 6px; font-size:10.5px; color:#263238; font-weight:650;">${e.name}</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px;">Rs. ${Number(e.amount||0).toLocaleString()}</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px;">0</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px;">0</td>
          <td style="text-align:center; padding:4px 3px; font-weight:800; font-size:10.5px;">Rs. ${Number(e.amount||0).toLocaleString()}</td>
        </tr>
      `}),e.discount>0&&(n+=`
        <tr style="border-bottom:1px solid #e8e8e8; background:#fff;">
          <td style="padding:4px 6px; font-size:10.5px; color:#e74c3c; font-weight:700;">Discount</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px; color:#e74c3c;">—</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px; color:#e74c3c;">Rs. ${Number(e.discount).toLocaleString()}</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px; color:#e74c3c;">—</td>
          <td style="text-align:center; padding:4px 3px; font-weight:800; font-size:10.5px; color:#e74c3c;">- Rs. ${Number(e.discount).toLocaleString()}</td>
        </tr>
      `),e.lateFee>0&&(n+=`
        <tr style="border-bottom:1px solid #e8e8e8; background:#fff;">
          <td style="padding:4px 6px; font-size:10.5px; color:#ff8c00; font-weight:700;">Late Fee</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px; color:#ff8c00;">Rs. ${Number(e.lateFee).toLocaleString()}</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px; color:#ff8c00;">—</td>
          <td style="text-align:center; padding:4px 3px; font-size:10.5px; color:#ff8c00;">—</td>
          <td style="text-align:center; padding:4px 3px; font-weight:800; font-size:10.5px; color:#ff8c00;">+ Rs. ${Number(e.lateFee).toLocaleString()}</td>
        </tr>
      `),n+=`
      <tr style="border-top:2px solid ${t.primaryColor}; background:#e4e4e4; font-weight:800;">
        <td style="padding:4px 6px; font-size:11.5px; color:#111;">Net Total</td>
        <td style="text-align:center; padding:4px 3px; font-size:11.5px; color:#111;">—</td>
        <td style="text-align:center; padding:4px 3px; font-size:11.5px; color:#111;">—</td>
        <td style="text-align:center; padding:4px 3px; font-size:11.5px; color:#111;">—</td>
        <td style="text-align:center; padding:4px 3px; font-size:11.5px; color:#111;">Rs. ${Number(e.total||0).toLocaleString()}</td>
      </tr>
    `,n}else{let{monthly:n,paperFund:r,arrears:i,discount:a,gross:o,paid:s}=y(e),c=Number(e.admission_fee||0),l=Number(e.other_fee||0),u=i>0,d=n+r+i+c+l,f=Math.max(0,n-a),p=r>0?`
      <tr style="border-bottom:1px solid #dbeafe; background:#eff6ff;">
        <td style="padding:4px 6px; font-size:10.5px; color:#1e3a8a; font-weight:700;">Paper Fund</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px; color:#1e3a8a;">${r.toLocaleString()}</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">0</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">0</td>
        <td style="text-align:center; padding:4px 3px; font-weight:800; font-size:10.5px; color:#1e3a8a;">${r.toLocaleString()}</td>
      </tr>`:``;return`
      <tr style="border-bottom:1px solid #e8e8e8; background:#f7f7f7;">
        <td style="padding:4px 6px; font-size:10.5px; color:#263238;">Monthly Fee ${e.month||``} ${e.year||``}</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">${n.toLocaleString()}</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">${a>0?a.toLocaleString():`0`}</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">${s>0?Math.min(s,f).toLocaleString():`0`}</td>
        <td style="text-align:center; padding:4px 3px; font-weight:800; font-size:10.5px;">${f.toLocaleString()}</td>
      </tr>
      ${p}
      <tr style="border-bottom:1px solid #e8e8e8; background:#fff;">
        <td style="padding:4px 6px; font-size:10.5px; color:#263238;">Admission Fee</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">${c?c.toLocaleString():`—`}</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">0</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">0</td>
        <td style="text-align:center; padding:4px 3px; font-weight:800; font-size:10.5px;">${c?c.toLocaleString():`—`}</td>
      </tr>
      <tr style="border-bottom:1px solid #e8e8e8; background:#f7f7f7;">
        <td style="padding:4px 6px; font-size:10.5px; color:#263238;">Other Fee</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">${l?l.toLocaleString():`—`}</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">0</td>
        <td style="text-align:center; padding:4px 3px; font-size:10.5px;">0</td>
        <td style="text-align:center; padding:4px 3px; font-weight:800; font-size:10.5px;">${l?l.toLocaleString():`—`}</td>
      </tr>
      <tr style="border-bottom:1px solid #d4b84a; background:#fef8e0;">
        <td style="padding:4px 6px; color:#7a5c00; font-style:italic; font-size:10.5px; font-weight:600;">Previous Arrears / Balance</td>
        <td style="text-align:center; padding:4px 3px; color:#7a5c00; font-size:10.5px;">${u?i.toLocaleString():`—`}</td>
        <td style="text-align:center; padding:4px 3px; color:#7a5c00; font-size:10.5px;">0</td>
        <td style="text-align:center; padding:4px 3px; color:#7a5c00; font-size:10.5px;">0</td>
        <td style="text-align:center; padding:4px 3px; font-weight:800; color:#7a5c00; font-size:10.5px;">${u?i.toLocaleString():`—`}</td>
      </tr>
      <tr style="border-top:2px solid ${t.primaryColor}; background:#e4e4e4; font-weight:800;">
        <td style="padding:4px 6px; font-size:11.5px; color:#111;">Net Total</td>
        <td style="text-align:center; padding:4px 3px; font-size:11.5px; color:#111;">${d.toLocaleString()}</td>
        <td style="text-align:center; padding:4px 3px; font-size:11.5px; color:#111;">${a>0?a.toLocaleString():`0`}</td>
        <td style="text-align:center; padding:4px 3px; font-size:11.5px; color:#111;">${s>0?s.toLocaleString():`0`}</td>
        <td style="text-align:center; padding:4px 3px; font-size:11.5px; color:#111;">${o.toLocaleString()}</td>
      </tr>
    `}}function b(e,t,n={},r=1){let i=ne(r),a=new Date().toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`}),o=e.due_date||e.dueDate,s=o?new Date(o).toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`}):a,c=(n==null?void 0:n.name)||(n==null?void 0:n.schoolName)||v.schoolName,l=(n==null?void 0:n.address)||(n==null?void 0:n.schoolAddress)||v.address,u=(n==null?void 0:n.logo)||(n==null?void 0:n.logoUrl)||``,d=e.gr_number||e.gr||`—`,f=e.name||e.student||`—`,p=e.father_name||e.father||`—`,m=e.challan_no||e.voucherNo||e.voucherNumber||`—`,h=e.class||e.className||`—`,g=e.section||`Blue`,{gross:_}=y(e),ee=e.total===void 0?e.amountDue===void 0?_:e.amountDue:e.total,b=e.status===`paid`||e.status===`Paid`?ee:e.paid_amount||0,x=e.status===`paid`||e.status===`Paid`?0:e.remaining_balance===void 0?ee:e.remaining_balance,S=u?`<img src="${u}" style="height:36px;width:36px;object-fit:contain;display:block">`:`<div style="width:36px;height:36px;border-radius:50%;background:${i.primaryColor};display:flex;align-items:center;justify-content:center;font-weight:900;color:${i.secondaryColor};font-size:16px;font-family:sans-serif">A</div>`,C=re(e,i);return`
    <div style="width:100%; height:100%; box-sizing:border-box; border:1.8px solid ${i.outerBorderColor}; border-radius:6px; font-family:${i.fontFam}; display:flex; flex-direction:column; overflow:hidden; background:${i.cardBg}; padding:8px 10px; justify-content:flex-start; page-break-inside:avoid; position:relative;">

      <!-- Top Label Header -->
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid ${i.primaryColor}; padding-bottom:2px; margin-bottom:3px;">
        <div style="font-weight:700; font-size:10px; color:${i.secondaryColor}; letter-spacing:0.5px; text-transform:uppercase;">${t}</div>
        <div style="font-weight:700; font-size:10px; color:${i.primaryColor};">No: <span style="color:${i.secondaryColor}">${m}</span></div>
      </div>

      <!-- School Branding Header -->
      <div style="display:flex; align-items:center; gap:6px; margin-bottom:3px; justify-content:center;">
        <div style="flex:0 0 auto;">${S}</div>
        <div style="flex:1; text-align:center;">
          <div style="font-weight:800; font-size:15px; color:${i.schoolNameColor}; line-height:1.2; margin:0; padding:0;">${c}</div>
          <div style="font-size:9px; color:#555; line-height:1.2; margin-top:1px;">${l}</div>
        </div>
        <div style="flex:0 0 auto;">${S}</div>
      </div>

      <!-- Voucher Sub-Header -->
      <div style="background:${i.headerBg}; color:${i.headerText}; text-align:center; padding:2px; font-weight:700; font-size:12px; letter-spacing:1.5px; border-radius:4px; margin-bottom:4px;">
        FEE VOUCHER
      </div>

      <!-- Student Details Section -->
      <table style="width:100%; border-collapse:collapse; margin-bottom:4px; font-size:11px; line-height:1.3;">
        <tr style="border-bottom:1px solid #eee;">
          <td style="padding:2px; color:#555; font-weight:500; width:32%;">Student:</td>
          <td style="padding:2px; font-weight:700; color:#000; width:68%; text-transform:capitalize;">${f}</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="padding:2px; color:#555; font-weight:500;">Father:</td>
          <td style="padding:2px; font-weight:700; color:#000; text-transform:capitalize;">${p}</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="padding:2px; color:#555; font-weight:500;">Class / Sec:</td>
          <td style="padding:2px; font-weight:700; color:#000;">${h} (${g})</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="padding:2px; color:#555; font-weight:500;">GR Number:</td>
          <td style="padding:2px; font-weight:700; color:${i.secondaryColor};">${d}</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="padding:2px; color:#555; font-weight:500;">Due Date:</td>
          <td style="padding:2px; font-weight:700; color:#c0392b;">${s}</td>
        </tr>
        <tr>
          <td style="padding:2px; color:#555; font-weight:500;">Print Date:</td>
          <td style="padding:2px; font-weight:700; color:#555;">${a}</td>
        </tr>
      </table>

      <!-- Fee Table -->
      <table style="width:100%; border-collapse:collapse; font-size:10.5px; margin-bottom:4px;">
        <thead>
          <tr style="background:${i.tableHeaderBg}; color:${i.tableHeaderColor}; border-top:1.5px solid ${i.primaryColor}; border-bottom:1.5px solid ${i.primaryColor}; font-weight:700;">
            <th style="text-align:left; padding:4px 6px;">Particulars</th>
            <th style="text-align:center; padding:4px 2px; width:18%;">Gross</th>
            <th style="text-align:center; padding:4px 2px; width:12%;">Disc</th>
            <th style="text-align:center; padding:4px 2px; width:14%;">Paid</th>
            <th style="text-align:center; padding:4px 2px; width:16%;">Net</th>
          </tr>
        </thead>
        <tbody>
          ${C}
        </tbody>
      </table>

      <!-- Totals & Notes Sections -->
      <div style="display:flex; flex-direction:column; gap:3px; margin-bottom:4px;">
        <div style="display:flex; flex-direction:column; gap:2px; font-size:11.5px; font-weight:700; background:#f9f9f9; padding:4px 6px; border-radius:4px; border:1px solid #ddd;">
          <div style="display:flex; justify-content:space-between;">
            <span style="color:#555;">Paid Amount:</span>
            <span style="color:${e.status===`paid`||e.status===`Paid`?`#27ae60`:`#333`}">Rs. ${b.toLocaleString()}</span>
          </div>
          <div style="display:flex; justify-content:space-between; border-top:1px solid #eee; padding-top:2px;">
            <span>Remaining:</span>
            <span style="color:${x===0?`#27ae60`:`#c0392b`}">${x===0?`PAID`:`Rs. `+x.toLocaleString()}</span>
          </div>
        </div>

        <div style="font-size:9.5px; font-weight:700; line-height:1.25; color:#555; text-align:justify; border:1px solid #ddd; padding:4px; border-radius:4px; background:#fff; height:auto; overflow:visible;">
          ${te}
        </div>
      </div>

      <!-- Signatures & Stamps Footer -->
      <div style="display:flex; justify-content:space-between; align-items:center; padding-top:2px; border-top:1px solid #eee; margin-top:auto;">
        <div style="text-align:center; width:75px;">
          <div style="border-top:1px solid #333; margin-top:6px; margin-bottom:1px;"></div>
          <span style="font-size:10px; font-weight:700; color:#555;">Depositor</span>
        </div>
        <div style="text-align:center;">
          <div style="display:inline-block; border-radius:4px; padding:2px 8px; transform:rotate(-5deg); font-size:9.5px; font-weight:800; letter-spacing:1px; line-height:1; ${i.stampStyle}">STAMP</div>
        </div>
        <div style="text-align:center; width:75px;">
          <div style="border-top:1px solid #333; margin-top:6px; margin-bottom:1px;"></div>
          <span style="font-size:10px; font-weight:700; color:#555;">Cashier</span>
        </div>
      </div>

    </div>
  `}function x(e,t={}){let n=t.schoolName||t.name||v.schoolName,r=t.schoolUrdu||t.urduName||v.urduName,i=t.address||t.location||v.address,a=t.logo||t.photo||``,o=t.showUrduHeader!==!1,s=a?`<img src="${a}" style="height:85px;object-fit:contain;display:block;margin:0 auto 8px">`:`<div style="width:80px;height:80px;border-radius:50%;border:3px solid #071e34;display:flex;align-items:center;justify-content:center;margin:0 auto 8px;font-size:28px;color:#071e34;background:#fff">A</div>`;return`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Admission Form - ${e.name||`Candidate`}</title>
<link href="https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu&display=swap" rel="stylesheet">
<style>
@page { size: A4 portrait; margin: 5mm; }
body{margin:0;padding:20px 40px;font-family:Arial,sans-serif;color:#000;line-height:1.6;background:#fff;}
@media print {
  body { padding: 10px 20px; }
  .no-print { display: none !important; }
}
.card{max-width:800px;margin:0 auto;border:2px solid #071e34;padding:30px;position:relative;min-height:270mm;box-sizing:border-box;}
.header{text-align:center;margin-bottom:25px;border-bottom:3px double #071e34;padding-bottom:15px}
.photo-box{position:absolute;right:30px;top:130px;width:120px;height:150px;border:1px solid #000;display:flex;align-items:center;justify-content:center;font-size:12px;background:#f9f9f9;text-align:center;}
h1{margin:10px 0 5px;font-size:24px;text-transform:uppercase;color:#071e34}
.urdu{font-family:'Noto Nastaliq Urdu',serif;font-size:20px;direction:rtl;margin-bottom:8px}
.form-title{background:#071e34;color:#fff;padding:8px;text-align:center;font-weight:bold;font-size:18px;margin-bottom:25px;letter-spacing:2px}
.section{margin-bottom:22px}
.section-title{border-bottom:1px solid #071e34;font-weight:bold;margin-bottom:12px;color:#071e34;text-transform:uppercase;font-size:14px}
.row{display:flex;gap:20px;margin-bottom:12px}
.field{flex:1;border-bottom:1px solid #ddd;padding-bottom:4px}
.field label{font-size:11px;color:#666;display:block;font-weight:bold;text-transform:uppercase}
.field span{font-size:15px;font-weight:bold;color:#000}
.footer{margin-top:40px;display:flex;justify-content:space-between}
.sig{width:200px;text-align:center;border-top:1px solid #000;padding-top:8px;font-size:13px;font-weight:bold}
</style></head><body>
<div class="card">
<div class="header">
${s}
${o?`<div class="urdu">${r}</div>`:``}
<h1>${n}</h1>
<div style="font-size:12px;color:#444">${i}</div>
</div>

<div class="form-title">STUDENT ADMISSION FORM</div>

<div class="photo-box">
${e.photo?`<img src="${e.photo}" style="width:100%;height:100%;object-fit:cover">`:`Passport Size Photo`}
</div>

<div class="section">
<div class="section-title">Student Information</div>
<div class="row">
<div class="field"><label>Full Name</label><span>${e.name||`—`}</span></div>
<div class="field" style="max-width:200px"><label>GR Number</label><span>${e.gr_number||e.admissionNumber||`—`}</span></div>
</div>
<div class="row">
<div class="field"><label>Father / Guardian Name</label><span>${e.father_name||e.fatherName||`—`}</span></div>
<div class="field"><label>Date of Birth</label><span>${e.date_of_birth||e.dob||`—`}</span></div>
</div>
<div class="row">
<div class="field"><label>Class Admitted</label><span>${e.class||e.className||`—`}</span></div>
<div class="field"><label>Section</label><span>${e.section||`Blue`}</span></div>
<div class="field"><label>Gender</label><span>${e.gender||`Male`}</span></div>
</div>
</div>

<div class="section">
<div class="section-title">Contact & Address</div>
<div class="row">
<div class="field"><label>Parent Phone</label><span>${e.parent_phone||e.contact||`—`}</span></div>
<div class="field"><label>Address</label><span>${e.address||`—`}</span></div>
</div>
</div>

<div class="section" style="margin-top:30px">
<div class="section-title">Declaration</div>
<p style="font-size:12px;color:#333;text-align:justify">
I hereby declare that the information provided above is correct to the best of my knowledge.
I agree to abide by the rules and regulations of the institution as mentioned in the school policy.
I understand that the admission is subject to the verification of documents and clearance of dues.
</p>
</div>

<div class="footer">
<div class="sig">Parent / Guardian Signature</div>
<div class="sig">Principal / Office Incharge</div>
</div>

</div>
<script>window.onload=()=>window.print()<\/script>
</body></html>`}var S=e(n(),1),C=e(r(),1),w=t(),ie=[`All`,`paid`,`unpaid`,`partial`],ae=e=>{let t={display:`inline-flex`,alignItems:`center`,justifyContent:`center`,minWidth:58,padding:`4px 10px`,borderRadius:999,fontSize:11,fontWeight:800,lineHeight:1,textTransform:`uppercase`,letterSpacing:.35,border:`1px solid transparent`};return e===`paid`?{...t,background:`rgba(48,209,88,0.12)`,color:_.green,borderColor:`rgba(48,209,88,0.24)`}:e===`partial`?{...t,background:`rgba(200,153,26,0.12)`,color:_.gold,borderColor:`rgba(200,153,26,0.24)`}:{...t,background:`rgba(255,55,95,0.12)`,color:_.red,borderColor:`rgba(255,55,95,0.24)`}},oe={minHeight:38,padding:`8px 13px`,borderRadius:12,fontSize:12,fontWeight:800,lineHeight:1,letterSpacing:0,boxShadow:`none`,whiteSpace:`nowrap`},se={...oe,minWidth:104,border:`1px solid rgba(200,153,26,0.34)`,background:`linear-gradient(135deg,#D9A813,#F2C43B)`,color:`#071e34`};function T(e={},t){var n,r,i,a,o,s,c,l,u;let d=Number((n=(r=e.monthly_fee)==null?e.amount:r)==null?0:n),f=Number((i=e.paper_fund)==null?0:i),p=Number((a=(o=e.previous_arrears)==null?e.prev_month_fee:o)==null?0:a),m=Number((s=t==null?e.discount:t)==null?0:s),h=Number((c=e.gross_total)==null?Math.max(0,d+f+p-m):c),g=Number((l=e.paid_amount)==null?0:l);return{monthly:d,paperFund:f,arrears:p,discount:m,gross:h,paid:g,remaining:Number((u=e.remaining_balance)==null?Math.max(0,h-g):u)}}function E(e){let t=`#0a1628`,n=`#c8991a`,r=`#0a1628`,i=`#e8c87a`,a=`#0a1628`,o=`#e0e0e0`,s=`#000`,c=`#0a1628`,l=`Arial, sans-serif`,u=`border:2.5px solid rgba(150,60,60,0.25); color:rgba(150,60,60,0.28); font-weight:900;`;return e===2?(t=`#1e1b4b`,n=`#b45309`,r=`linear-gradient(135deg, #1e1b4b 0%, #312e81 100%)`,i=`#fef08a`,a=`#1e1b4b`,o=`#f1f5f9`,s=`#1e293b`,c=`#312e81`,l=`'Georgia', serif`,u=`border:2.5px dashed rgba(220,38,38,0.38); color:rgba(220,38,38,0.42); font-weight:900; font-family:sans-serif;`):e===3&&(t=`#333333`,n=`#666666`,r=`#f3f4f6`,i=`#111111`,a=`#111111`,o=`#f3f4f6`,s=`#111111`,c=`#666666`,l=`'Courier New', Courier, monospace`,u=`border:1.5px solid #999; color:#999; font-style:italic; font-weight:900; font-family:sans-serif;`),{primaryColor:t,secondaryColor:n,headerBg:r,headerText:i,schoolNameColor:a,tableHeaderBg:o,tableHeaderColor:s,outerBorderColor:c,cardBg:`#fff`,fontFam:l,stampStyle:u}}function D(e,t,n={},r=1,i=!1){return b(e,t,n,r)}function O(e,t=`Fee Vouchers`,n=null){try{let t=new Blob([e],{type:`text/html;charset=utf-8`}),r=URL.createObjectURL(t);if(n&&!n.closed){n.location.href=r,n.focus();return}let i=window.open(r,`_blank`);if(i){i.focus();return}}catch(e){console.warn(`Blob window.open failed:`,e)}try{let n=window.open(``,`_blank`);if(n&&n.document){n.document.open(),n.document.write(e),n.document.close();try{n.document.title=t}catch{}n.focus();return}}catch(e){console.warn(`Direct document.write fallback failed:`,e)}try{let t=document.getElementById(`apex-print-frame`);t||(t=document.createElement(`iframe`),t.id=`apex-print-frame`,t.style.position=`fixed`,t.style.top=`-9999px`,t.style.left=`-9999px`,t.style.width=`1000px`,t.style.height=`1000px`,t.style.border=`none`,t.style.zIndex=`-1000`,document.body.appendChild(t));let n=new Blob([e],{type:`text/html;charset=utf-8`});t.src=URL.createObjectURL(n),t.onload=()=>{setTimeout(()=>{try{t.contentWindow.focus(),t.contentWindow.print()}catch(e){console.error(`Iframe print error:`,e)}},400)}}catch(e){console.error(`All print methods failed:`,e)}}function k(e,t={},n=1,r=3,i=null){if(!e){alert(`No challan selected to print.`);return}let a=[`Student Copy`,`Institute Copy`,`Bank Copy`].slice(0,r);O(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Fee Voucher — ${e.challan_no||e.name||``}</title>
  <style>
    * { box-sizing:border-box; margin:0; padding:0; }
    @page { size:A4 landscape; margin:2mm 3mm; }
    body { background:#f3f4f6; font-family: Arial, sans-serif; padding:10px; margin:0; }
    @media print {
      body { background:#fff; padding:0; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
      .no-print { display:none !important; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="position:sticky; top:0; z-index:99999; background:#0B2C4D; color:#fff; padding:10px 20px; border-radius:8px; box-shadow:0 4px 20px rgba(0,0,0,0.4); display:flex; align-items:center; justify-content:space-between; margin-bottom:15px; font-family:sans-serif; border:1px solid rgba(200,153,26,0.3);">
    <div style="display:flex; align-items:center; gap:12px;">
      <strong style="color:#C8991A; font-size:15px;">AL SIDDIQUE SCHOLARS PUBLIC SCHOOL</strong>
      <span style="font-size:13px; color:#C0C8D8;">• Voucher: ${e.challan_no||e.name||`Single Voucher`}</span>
    </div>
    <div style="display:flex; gap:10px;">
      <button onclick="window.print()" style="background:linear-gradient(135deg,#D9A813,#F2C43B); color:#071e34; font-weight:800; border:none; padding:8px 20px; border-radius:8px; cursor:pointer; font-size:14px; box-shadow:0 2px 8px rgba(0,0,0,0.3);">Print Voucher</button>
      <button onclick="window.close()" style="background:rgba(255,255,255,0.15); color:#fff; font-weight:600; border:1px solid rgba(255,255,255,0.2); padding:8px 14px; border-radius:8px; cursor:pointer; font-size:13px;">Close</button>
    </div>
  </div>

  <div style="width:291mm; height:204mm; display:flex; flex-direction:row; gap:6px; box-sizing:border-box;; margin: 0 auto; background:#fff;">
    ${a.map((i,a)=>`
      <div style="width:calc(33.33% - 4px); height:204mm; display:flex;">
        ${D(e,i,t,n)}
      </div>
      ${r===3&&a<2?`<div style="border-left:1.5px dashed #ccc; width:1px; margin:0 2mm; height:204mm;"></div>`:``}
    `).join(``)}
  </div>

  <script>
    function triggerPrint() {
      try { window.focus(); window.print(); } catch(e) {}
    }
    if (document.readyState === 'complete') {
      setTimeout(triggerPrint, 350);
    } else {
      window.addEventListener('load', function() {
        setTimeout(triggerPrint, 350);
      });
      setTimeout(triggerPrint, 1200);
    }
  <\/script>
</body>
</html>`,`Fee Voucher — ${e.challan_no||e.name||``}`,i)}function ce(e,t={},n=null){if(!e||!e.length){alert(`No challans available to print.`);return}let r=e.map(e=>D(e,`Student Copy`,t,1)),i=[];for(let e=0;e<r.length;e+=3){let t=r.slice(e,e+3);i.push(`
      <div class="voucher-page" style="width:291mm; height:204mm; display:flex; flex-direction:row; gap:6px; box-sizing:border-box; page-break-after:always; break-after:page; page-break-inside:avoid; break-inside:avoid; margin:0 auto 10mm; background:#fff;">
        ${t.map((e,n)=>`
          <div style="width:calc(33.33% - 4px); height:204mm; display:flex;">
            ${e}
          </div>
          ${n<t.length-1?`<div style="border-left:1.5px dashed #ccc; width:1px; margin:0 2mm; height:204mm;"></div>`:``}
        `).join(``)}
      </div>
    `)}O(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Fee Vouchers — (${e.length} Compact Vouchers)</title>
  <style>
    * { box-sizing:border-box; margin:0; padding:0; }
    @page { size:A4 landscape; margin:2mm 3mm; }
    body { background:#f3f4f6; font-family: Arial, sans-serif; padding:10px; margin:0; }
    @media print {
      body { background:#fff; padding:0; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
      .no-print { display:none !important; }
      .voucher-page { margin-bottom:0 !important; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="position:sticky; top:0; z-index:99999; background:#0B2C4D; color:#fff; padding:10px 20px; border-radius:8px; box-shadow:0 4px 20px rgba(0,0,0,0.4); display:flex; align-items:center; justify-content:space-between; margin-bottom:15px; font-family:sans-serif; border:1px solid rgba(200,153,26,0.3);">
    <div style="display:flex; align-items:center; gap:12px;">
      <strong style="color:#C8991A; font-size:15px;">AL SIDDIQUE SCHOLARS PUBLIC SCHOOL</strong>
      <span style="font-size:13px; color:#C0C8D8;">• Batch of ${e.length} Compact Vouchers Ready</span>
    </div>
    <div style="display:flex; gap:10px;">
      <button onclick="window.print()" style="background:linear-gradient(135deg,#D9A813,#F2C43B); color:#071e34; font-weight:800; border:none; padding:8px 20px; border-radius:8px; cursor:pointer; font-size:14px; box-shadow:0 2px 8px rgba(0,0,0,0.3);">Print All (${e.length})</button>
      <button onclick="window.close()" style="background:rgba(255,255,255,0.15); color:#fff; font-weight:600; border:1px solid rgba(255,255,255,0.2); padding:8px 14px; border-radius:8px; cursor:pointer; font-size:13px;">Close</button>
    </div>
  </div>

  ${i.join(``)}

  <script>
    function triggerPrint() {
      try { window.focus(); window.print(); } catch(e) {}
    }
    if (document.readyState === 'complete') {
      setTimeout(triggerPrint, 400);
    } else {
      window.addEventListener('load', function() {
        setTimeout(triggerPrint, 400);
      });
      setTimeout(triggerPrint, 1400);
    }
  <\/script>
</body>
</html>`,`Fee Vouchers — (${e.length} Compact Vouchers)`,n)}function A(e,t={},n=1,r=null){if(!e||!e.length){alert(`No challans available to print.`);return}let i=[`Student Copy`,`Institute Copy`,`Bank Copy`],a=e.map(e=>`
    <div class="voucher-page" style="width:291mm; height:204mm; display:flex; flex-direction:row; gap:6px; box-sizing:border-box; page-break-after:always; break-after:page; page-break-inside:avoid; break-inside:avoid; margin:0 auto 10mm; background:#fff;">
      ${i.map((r,i)=>`
        <div style="width:calc(33.33% - 4px); height:204mm; display:flex;">
          ${D(e,r,t,n)}
        </div>
        ${i<2?`<div style="border-left:1.5px dashed #ccc; width:1px; margin:0 2mm; height:204mm;"></div>`:``}
      `).join(``)}
    </div>
  `).join(``);O(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Batch Fee Vouchers — (${e.length} Students)</title>
  <style>
    * { box-sizing:border-box; margin:0; padding:0; }
    @page { size:A4 landscape; margin:2mm 3mm; }
    body { background:#f3f4f6; font-family: Arial, sans-serif; padding:10px; margin:0; }
    @media print {
      body { background:#fff; padding:0; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
      .no-print { display:none !important; }
      .voucher-page { margin-bottom:0 !important; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="position:sticky; top:0; z-index:99999; background:#0B2C4D; color:#fff; padding:12px 24px; border-radius:8px; box-shadow:0 6px 24px rgba(0,0,0,0.5); display:flex; align-items:center; justify-content:space-between; margin-bottom:15px; font-family:sans-serif; border:1px solid rgba(200,153,26,0.3);">
    <div style="display:flex; align-items:center; gap:14px;">
      <strong style="color:#C8991A; font-size:16px; letter-spacing:0.5px;">AL SIDDIQUE SCHOLARS PUBLIC SCHOOL</strong>
      <span style="font-size:13px; color:#C0C8D8;">• Batch Print: <strong>${e.length} Students</strong> (${e.length*3} Vouchers)</span>
    </div>
    <div style="display:flex; gap:12px;">
      <button onclick="window.print()" style="background:linear-gradient(135deg,#D9A813,#F2C43B); color:#071e34; font-weight:800; border:none; padding:9px 24px; border-radius:8px; cursor:pointer; font-size:14px; box-shadow:0 3px 10px rgba(0,0,0,0.35);">Print All Vouchers (${e.length})</button>
      <button onclick="window.close()" style="background:rgba(255,255,255,0.15); color:#fff; font-weight:600; border:1px solid rgba(255,255,255,0.25); padding:9px 16px; border-radius:8px; cursor:pointer; font-size:13px;">Close</button>
    </div>
  </div>

  ${a}

  <script>
    function triggerPrint() {
      try { window.focus(); window.print(); } catch(e) {}
    }
    if (document.readyState === 'complete') {
      setTimeout(triggerPrint, 450);
    } else {
      window.addEventListener('load', function() {
        setTimeout(triggerPrint, 450);
      });
      setTimeout(triggerPrint, 1500);
    }
  <\/script>
</body>
</html>`,`Batch Fee Vouchers — (${e.length} Students)`,r)}var j=e=>Number(e||0).toLocaleString(),M=(e,t)=>T(e,t).gross;function le(){let e=i(),[t,n]=(0,S.useState)([]),[r,v]=(0,S.useState)(!0),te=[`October`,`September`,`August`,`July`,`June`,`May`,`All Months`],ne=[`2026`,`2027`,`All Years`],[y,re]=(0,S.useState)(`All`),[b,x]=(0,S.useState)(`All Classes`),[E,D]=(0,S.useState)(`October`),[O,le]=(0,S.useState)(`2026`),[ue,de]=(0,S.useState)(``),[N,fe]=(0,S.useState)(null),[P,F]=(0,S.useState)({discount:0,paid_amount:0,payment_mode:`cash`,payment_note:``}),[pe,I]=(0,S.useState)(``),[L,me]=(0,S.useState)(!1),[R,he]=(0,S.useState)(null),[z,B]=(0,S.useState)({challan_no:``,month:``,year:``,monthly_fee:0,paper_fund:0,previous_arrears:0,discount:0,due_date:``}),[ge,V]=(0,S.useState)(``),[H,_e]=(0,S.useState)(!1),[ve,U]=(0,S.useState)(!1),[ye,be]=(0,S.useState)({top:0,right:0}),[W,xe]=(0,S.useState)(!1),[Se,G]=(0,S.useState)(null),[Ce,we]=(0,S.useState)({top:0,right:0}),[Te,Ee]=(0,S.useState)([]),De=(0,S.useRef)({}),Oe=(0,S.useRef)(),ke=(0,S.useRef)(),{paperSettings:K}=l(),{families:Ae,getFamilyForStudent:je}=ee(),{classNames:Me}=c(),Ne=[`All Classes`,...Me!=null&&Me.length?Me:[`Starter`]],q=s(),J={name:(q==null?void 0:q.schoolName)||(K==null?void 0:K.schoolName)||`AL SIDDIQUE SCHOLARS PUBLIC SCHOOL`,schoolName:(q==null?void 0:q.schoolName)||(K==null?void 0:K.schoolName)||`AL SIDDIQUE SCHOLARS PUBLIC SCHOOL`,urdu:(K==null?void 0:K.schoolUrdu)||``,address:(q==null?void 0:q.address)||(K==null?void 0:K.address)||(K==null?void 0:K.schoolAddress)||`Sharif Chowk, Rayya Khas, Narowal`,phone:(K==null?void 0:K.phone)||`03001291959`,logo:(q==null?void 0:q.logoUrl)||(K==null?void 0:K.logo)||``,showUrduHeader:(K==null?void 0:K.showUrduHeader)||!1},Y=()=>{v(!0);let e={};y!==`All`&&(e.status=y),b!==`All Classes`&&(e.class=b),E!==`All Months`&&(e.month=E),O!==`All Years`&&(e.year=O),o.get(`/api/fees`,{params:e}).then(e=>n(e.data.data||[])).catch(()=>n([])).finally(()=>v(!1))};(0,S.useEffect)(()=>{Y()},[y,b,E,O]);let X=()=>{var e;let t=(e=ke.current)==null?void 0:e.getBoundingClientRect();t&&be({top:Math.min(t.bottom+8,window.innerHeight-24),right:Math.max(16,window.innerWidth-t.right)})},Pe=()=>{X(),U(e=>!e)};(0,S.useEffect)(()=>{if(ve)return X(),window.addEventListener(`resize`,X),window.addEventListener(`scroll`,X,!0),()=>{window.removeEventListener(`resize`,X),window.removeEventListener(`scroll`,X,!0)}},[ve]),(0,S.useEffect)(()=>{let e=e=>{var t,n,r,i,a,o;(t=(n=e.target).closest)!=null&&t.call(n,`.print-dd-menu`)||(r=(i=e.target).closest)!=null&&r.call(i,`.print-dd-btn`)||(a=Oe.current)!=null&&a.contains(e.target)||(o=ke.current)!=null&&o.contains(e.target)||U(!1)};return document.addEventListener(`mousedown`,e),()=>document.removeEventListener(`mousedown`,e)},[]),(0,S.useEffect)(()=>{let e=e=>{e.target.closest(`.action-dd-wrap`)||G(null)};return document.addEventListener(`mousedown`,e),()=>document.removeEventListener(`mousedown`,e)},[]);let Fe=(e,t)=>{if(e.stopPropagation(),Se===t.id){G(null);return}let n=De.current[t.id];if(!n)return;let r=n.getBoundingClientRect();we({top:window.innerHeight-r.bottom<232?r.top-220-4:r.bottom+4,right:window.innerWidth-r.right}),Ee([{label:`Edit Challan / Fee`,fn:()=>{Le(t),G(null)}},{label:`Mark as Unpaid`,fn:()=>{o.put(`/api/fees/${t.id}/pay`,{paid_amount:0,discount:0,payment_note:`Reverted`}).then(Y).catch(()=>{}),G(null)}},{label:`View Fee History`,fn:()=>{alert(`Fee history coming soon`),G(null)}},{label:`One Student (1 Copy)`,fn:()=>{k(t,J,1,1),G(null)}},{label:`One Student (3 Copies)`,fn:()=>{k(t,J,1,3),G(null)}},{label:`Print (Simple)`,fn:()=>{k(t,J,3,3),G(null)}},{label:`Print (Premium)`,fn:()=>{k(t,J,2,3),G(null)}}]),G(t.id)},Ie=e=>{if(!e)return``;let t=new Date(e);return Number.isNaN(t.getTime())?String(e).slice(0,10):t.toISOString().slice(0,10)},Le=e=>{he(e),B({challan_no:e.challan_no||``,month:e.month||``,year:e.year||new Date().getFullYear(),monthly_fee:T(e).monthly,paper_fund:T(e).paperFund,previous_arrears:T(e).arrears,discount:Number(e.discount||0),due_date:Ie(e.due_date)}),V(``)},Re=()=>{H||(he(null),V(``))},ze=async()=>{if(!R)return;let e=Math.max(0,Number(z.monthly_fee||0)),t=Math.max(0,Number(z.paper_fund||0)),n=Math.max(0,Number(z.previous_arrears||0)),r=Math.max(0,Number(z.discount||0));if(!z.challan_no.trim()){V(`Challan number is required.`);return}if(!z.month.trim()){V(`Month is required.`);return}if(!Number(z.year)){V(`Year is required.`);return}if(r>e+t+n){V(`Discount cannot exceed monthly fee, Paper Fund, and arrears.`);return}_e(!0);try{await o.put(`/api/fees/${R.id}`,{challan_no:z.challan_no.trim(),month:z.month.trim(),year:Number(z.year),monthly_fee:e,amount:e,previous_arrears:n,discount:r,due_date:z.due_date||null}),he(null),Y()}catch(e){var i;V(((i=e.response)==null||(i=i.data)==null?void 0:i.message)||`Challan could not be updated. Please try again.`)}finally{_e(!1)}},Be=e=>{let t=Number(e.discount||0),n=Number(e.paid_amount||0),r=Math.max(0,M(e,t)-n);fe(e),F({discount:t,paid_amount:r,payment_mode:e.payment_mode||`cash`,payment_note:e.payment_note||``}),I(``)},Ve=()=>{L||(fe(null),I(``))},He=async()=>{if(!N)return;let e=Math.max(0,Number(P.discount||0)),t=M(N,e),n=Math.max(0,Number(P.paid_amount||0)),r=Math.min(t,Number(N.paid_amount||0)+n);if(e>T(N,0).monthly+T(N,0).paperFund+T(N,0).arrears){I(`Discount cannot exceed the total challan amount.`);return}if(n>Math.max(0,t-Number(N.paid_amount||0))){I(`Received amount cannot exceed the remaining balance.`);return}me(!0);try{await o.put(`/api/fees/${N.id}/pay`,{paid_amount:r,discount:e,payment_mode:P.payment_mode,payment_note:P.payment_note}),fe(null),Y()}catch(e){var i;I(((i=e.response)==null||(i=i.data)==null?void 0:i.message)||`Payment could not be saved. Please try again.`)}finally{me(!1)}},Z=t.filter(e=>{if(!ue)return!0;let t=ue.toLowerCase(),n=je(e.student_id);return[e.name,e.gr_number,e.challan_no,n==null?void 0:n.code,n==null?void 0:n.fatherName].some(e=>e==null?void 0:e.toLowerCase().includes(t))}),Q=N?M(N,P.discount):0,$=Number((N==null?void 0:N.paid_amount)||0),Ue=Math.max(0,Q-$-Number(P.paid_amount||0));return(0,w.jsxs)(`div`,{style:{minHeight:`100vh`,padding:24,background:`#071e34`,color:_.silver},children:[(0,w.jsxs)(`div`,{style:{width:`100%`,maxWidth:1520,margin:`0 auto`,display:`grid`,gap:24},children:[(0,w.jsxs)(`div`,{className:`super-module-card`,style:{...f,display:`flex`,flexWrap:`wrap`,justifyContent:`space-between`,gap:16,alignItems:`center`,position:`relative`,zIndex:50},children:[(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`h1`,{style:g,children:`View Challans`}),(0,w.jsx)(`p`,{style:{color:_.muted,marginTop:8},children:`Browse fee vouchers, receive full or partial payments, and apply discounts.`})]}),(0,w.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,w.jsx)(`button`,{type:`button`,onClick:()=>xe(e=>!e),style:{...h,fontSize:13,borderColor:W?`#C8991A`:void 0,color:W?`#C8991A`:void 0},children:W?`List View`:`Class Wise View`}),(0,w.jsxs)(`button`,{type:`button`,onClick:()=>{if(!Z.length){alert(`No challans found in current view.`);return}A(Z,J,1)},style:{...p,background:`linear-gradient(135deg,#D9A813,#F2C43B)`,color:`#071e34`,fontWeight:800,fontSize:13,boxShadow:`0 3px 12px rgba(217,168,19,0.4)`,display:`inline-flex`,alignItems:`center`,gap:6},children:[(0,w.jsx)(a,{size:15}),` Batch Print (`,Z.length,`)`]}),(0,w.jsxs)(`div`,{style:{position:`relative`},children:[(0,w.jsx)(`button`,{ref:ke,type:`button`,className:`print-dd-btn`,onClick:Pe,style:{...h,fontSize:13},children:`More Print Options ▾`}),ve&&(0,C.createPortal)((0,w.jsxs)(`div`,{ref:Oe,className:`print-dd-menu`,style:{position:`fixed`,right:ye.right,top:ye.top,background:`#0B2C4D`,border:`1px solid rgba(200,153,26,0.25)`,borderRadius:12,zIndex:1e4,width:`min(320px, calc(100vw - 32px))`,maxHeight:`min(520px, calc(100vh - ${ye.top+16}px))`,boxShadow:`0 18px 48px rgba(0,0,0,0.55)`,overflowY:`auto`,overflowX:`hidden`},children:[(0,w.jsx)(`div`,{style:{padding:`8px 18px 4px`,color:`#8892A4`,fontSize:11,fontWeight:700,textTransform:`uppercase`,letterSpacing:.5},children:`Template 1 — Classic Bank`}),[{label:`Single Student (Classic)`,fn:()=>{if(!Z.length){alert(`No challans in current view.`);return}k(Z[0],J,1,3)}},{label:`Batch Print (Classic)`,fn:()=>{if(!Z.length){alert(`No challans in current view.`);return}A(Z,J,1)}}].map(e=>(0,w.jsx)(`button`,{type:`button`,onClick:t=>{t.stopPropagation(),e.fn(),U(!1)},style:{display:`block`,width:`100%`,textAlign:`left`,padding:`10px 18px`,cursor:`pointer`,background:`transparent`,border:`none`,color:`#C0C8D8`,fontSize:13,borderBottom:`1px solid rgba(255,255,255,0.04)`,fontFamily:`inherit`},onMouseEnter:e=>e.currentTarget.style.background=`rgba(200,153,26,0.14)`,onMouseLeave:e=>e.currentTarget.style.background=`transparent`,children:e.label},e.label)),(0,w.jsx)(`div`,{style:{padding:`8px 18px 4px`,color:`#8892A4`,fontSize:11,fontWeight:700,textTransform:`uppercase`,letterSpacing:.5,borderTop:`1px solid rgba(255,255,255,0.06)`,marginTop:4},children:`Template 2 — Modern Premium`}),[{label:`Single Student (Premium)`,fn:()=>{if(!Z.length){alert(`No challans in current view.`);return}k(Z[0],J,2,3)}},{label:`Batch Print (Premium)`,fn:()=>{if(!Z.length){alert(`No challans in current view.`);return}A(Z,J,2)}}].map(e=>(0,w.jsx)(`button`,{type:`button`,onClick:t=>{t.stopPropagation(),e.fn(),U(!1)},style:{display:`block`,width:`100%`,textAlign:`left`,padding:`10px 18px`,cursor:`pointer`,background:`transparent`,border:`none`,color:`#C0C8D8`,fontSize:13,borderBottom:`1px solid rgba(255,255,255,0.04)`,fontFamily:`inherit`},onMouseEnter:e=>e.currentTarget.style.background=`rgba(200,153,26,0.14)`,onMouseLeave:e=>e.currentTarget.style.background=`transparent`,children:e.label},e.label)),(0,w.jsx)(`div`,{style:{padding:`8px 18px 4px`,color:`#8892A4`,fontSize:11,fontWeight:700,textTransform:`uppercase`,letterSpacing:.5,borderTop:`1px solid rgba(255,255,255,0.06)`,marginTop:4},children:`Template 3 — Simple Compact`}),[{label:`Single Student (Simple)`,fn:()=>{if(!Z.length){alert(`No challans in current view.`);return}k(Z[0],J,3,3)}},{label:`Batch Print (Simple)`,fn:()=>{if(!Z.length){alert(`No challans in current view.`);return}A(Z,J,3)}},{label:`Compact 3-in-1 Batch`,fn:()=>{if(!Z.length){alert(`No challans in current view.`);return}ce(Z,J)}}].map(e=>(0,w.jsx)(`button`,{type:`button`,onClick:t=>{t.stopPropagation(),e.fn(),U(!1)},style:{display:`block`,width:`100%`,textAlign:`left`,padding:`10px 18px`,cursor:`pointer`,background:`transparent`,border:`none`,color:`#C0C8D8`,fontSize:13,borderBottom:`1px solid rgba(255,255,255,0.04)`,fontFamily:`inherit`},onMouseEnter:e=>e.currentTarget.style.background=`rgba(200,153,26,0.14)`,onMouseLeave:e=>e.currentTarget.style.background=`transparent`,children:e.label},e.label))]}),document.body)]})]})]}),(0,w.jsxs)(`div`,{className:`super-module-card`,style:{...f,display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(170px, 1fr))`,gap:14,alignItems:`end`,position:`relative`,zIndex:40},children:[(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Search`}),(0,w.jsx)(`input`,{style:u,value:ue,onChange:e=>de(e.target.value),placeholder:`Search voucher, student or GR`})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Billing Month`}),(0,w.jsx)(`select`,{style:d,value:E,onChange:e=>D(e.target.value),children:te.map(e=>(0,w.jsx)(`option`,{value:e,children:e},e))})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Year`}),(0,w.jsx)(`select`,{style:d,value:O,onChange:e=>le(e.target.value),children:ne.map(e=>(0,w.jsx)(`option`,{value:e,children:e},e))})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Class`}),(0,w.jsx)(`select`,{style:d,value:b,onChange:e=>x(e.target.value),children:Ne.map(e=>(0,w.jsx)(`option`,{children:e},e))})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Status`}),(0,w.jsx)(`select`,{style:d,value:y,onChange:e=>re(e.target.value),children:ie.map(e=>(0,w.jsx)(`option`,{value:e,children:e===`All`?`All`:e.charAt(0).toUpperCase()+e.slice(1)},e))})]})]}),W&&(()=>{let e={};t.forEach(t=>{let n=t.class||`Unknown`;e[n]||(e[n]={total:0,paid:0,unpaid:0,totalAmt:0,paidAmt:0}),e[n].total++,e[n].totalAmt+=M(t),t.status===`paid`?(e[n].paid++,e[n].paidAmt+=Number(t.paid_amount||M(t))):e[n].unpaid++});let n=Object.entries(e).sort(([e],[t])=>e.localeCompare(t));return(0,w.jsxs)(`div`,{className:`super-module-card`,style:{...f,overflowX:`auto`},children:[(0,w.jsx)(`div`,{style:{color:`#C8991A`,fontWeight:800,fontSize:15,marginBottom:16},children:` Challans by Class`}),(0,w.jsxs)(`table`,{className:`challans-table`,style:{width:`100%`,borderCollapse:`collapse`},children:[(0,w.jsx)(`thead`,{children:(0,w.jsx)(`tr`,{style:{borderBottom:`1px solid rgba(200,153,26,0.2)`},children:[`Class`,`Total Challans`,`Paid`,`Unpaid`,`Total Amount`,`Paid Amount`,`Pending`].map(e=>(0,w.jsx)(`th`,{style:{padding:`12px 14px`,textAlign:`left`,color:`#8892A4`,fontSize:11,fontWeight:700,textTransform:`uppercase`},children:e},e))})}),(0,w.jsx)(`tbody`,{children:n.map(([e,t],n)=>(0,w.jsxs)(`tr`,{style:{borderBottom:`1px solid rgba(200,153,26,0.06)`,background:n%2==0?`transparent`:`rgba(11,44,77,0.2)`},children:[(0,w.jsx)(`td`,{style:{padding:`12px 14px`,color:`#C8991A`,fontWeight:700},children:e}),(0,w.jsx)(`td`,{style:{padding:`12px 14px`,color:`#C0C8D8`,fontWeight:700},children:t.total}),(0,w.jsx)(`td`,{style:{padding:`12px 14px`},children:(0,w.jsx)(`span`,{style:{padding:`3px 10px`,borderRadius:20,background:`rgba(48,209,88,0.1)`,color:`#30D158`,fontWeight:600,fontSize:12},children:t.paid})}),(0,w.jsx)(`td`,{style:{padding:`12px 14px`},children:(0,w.jsx)(`span`,{style:{padding:`3px 10px`,borderRadius:20,background:`rgba(255,55,95,0.1)`,color:`#FF375F`,fontWeight:600,fontSize:12},children:t.unpaid})}),(0,w.jsxs)(`td`,{style:{padding:`12px 14px`,color:`#C0C8D8`},children:[`Rs. `,t.totalAmt.toLocaleString()]}),(0,w.jsxs)(`td`,{style:{padding:`12px 14px`,color:`#30D158`,fontWeight:700},children:[`Rs. `,t.paidAmt.toLocaleString()]}),(0,w.jsxs)(`td`,{style:{padding:`12px 14px`,color:`#FF375F`,fontWeight:700},children:[`Rs. `,(t.totalAmt-t.paidAmt).toLocaleString()]})]},e))})]})]})})(),(0,w.jsx)(`div`,{className:`super-module-card`,style:{...f,overflowX:`auto`,position:`relative`,zIndex:30},children:r?(0,w.jsx)(`div`,{style:{padding:40,textAlign:`center`,color:_.muted},children:`Loading challans…`}):(0,w.jsxs)(`table`,{className:`challans-table`,style:{width:`100%`,borderCollapse:`collapse`},children:[(0,w.jsx)(`thead`,{children:(0,w.jsx)(`tr`,{style:{borderBottom:`1px solid ${_.border}`},children:[`GR. No`,`Student / Father`,`Family Code`,`Class/Sec`,`Challan / Month`,`Monthly Fee`,`Total`,`Pay Fee`,`Status`,`Action`].map(e=>(0,w.jsx)(`th`,{style:{padding:`10px 12px`,fontSize:11,color:_.muted,textAlign:`left`,textTransform:`uppercase`,letterSpacing:.06,whiteSpace:`nowrap`},children:e},e))})}),(0,w.jsxs)(`tbody`,{children:[Z.map((t,n)=>(0,w.jsxs)(`tr`,{style:{background:n%2==0?`transparent`:`rgba(11,44,77,0.2)`,verticalAlign:`middle`},children:[(0,w.jsx)(`td`,{style:{padding:`10px 12px`,color:_.gold,fontWeight:700,fontSize:12},children:t.gr_number||`—`}),(0,w.jsxs)(`td`,{style:{padding:`10px 12px`},children:[(0,w.jsx)(`div`,{style:{color:_.silver,fontWeight:700,fontSize:13,cursor:`pointer`,textDecoration:`underline`,textDecorationColor:`rgba(10,132,255,0.4)`},onClick:()=>e(`/students?view=${t.student_id}`),onMouseEnter:e=>e.currentTarget.style.color=`#0A84FF`,onMouseLeave:e=>e.currentTarget.style.color=_.silver,children:t.name||`—`}),(0,w.jsx)(`div`,{style:{color:_.muted,fontSize:11,marginTop:2},children:t.father_name||`—`})]}),(0,w.jsx)(`td`,{style:{padding:`10px 12px`},children:(()=>{var n;let r=t.family_code,i=je(t.student_id),a=r||(i==null?void 0:i.code),o=i==null||(n=i.students)==null?void 0:n.length;return a?(0,w.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:2,cursor:`pointer`},onClick:()=>e(`/families?code=${a}`),title:`Click to view family ${a}`,children:[(0,w.jsx)(`div`,{style:{color:_.gold,fontWeight:700,fontSize:12,textDecoration:`underline`,textDecorationColor:`rgba(200,153,26,0.4)`},onMouseEnter:e=>e.currentTarget.style.color=`#e8b420`,onMouseLeave:e=>e.currentTarget.style.color=_.gold,children:a}),o>0&&(0,w.jsxs)(`div`,{style:{color:_.muted,fontSize:10},children:[o,` children`]})]}):(0,w.jsx)(`span`,{style:{color:_.muted},children:`—`})})()}),(0,w.jsxs)(`td`,{style:{padding:`10px 12px`},children:[(0,w.jsx)(`div`,{style:{color:_.silver,fontSize:12},children:t.class||`—`}),(0,w.jsx)(`div`,{style:{color:_.muted,fontSize:11},children:t.section||`—`})]}),(0,w.jsxs)(`td`,{style:{padding:`10px 12px`},children:[(0,w.jsx)(`div`,{style:{color:_.gold,fontWeight:800,fontSize:12},children:t.challan_no||`—`}),(0,w.jsxs)(`div`,{style:{color:_.muted,fontSize:11},children:[t.month,` `,t.year]})]}),(0,w.jsxs)(`td`,{style:{padding:`10px 12px`,color:_.silver,fontSize:12},children:[(0,w.jsxs)(`div`,{children:[`Rs. `,j(T(t).monthly)]}),T(t).arrears>0&&(0,w.jsxs)(`div`,{style:{color:_.muted,fontSize:10,marginTop:2},children:[`Arrears: `,j(T(t).arrears)]})]}),(0,w.jsxs)(`td`,{style:{padding:`10px 12px`},children:[(0,w.jsxs)(`div`,{style:{color:_.silver,fontWeight:700,fontSize:12},children:[`Rs. `,j(M(t))]}),Number(t.discount||0)>0&&(0,w.jsxs)(`div`,{style:{color:_.green,fontSize:10,marginTop:2},children:[`Disc: `,j(t.discount)]})]}),(0,w.jsx)(`td`,{style:{padding:`10px 12px`},children:t.status===`paid`?(0,w.jsxs)(`div`,{style:{color:_.green,fontWeight:700,fontSize:12},children:[` `,j(t.paid_amount||M(t))]}):(0,w.jsx)(`button`,{type:`button`,style:{...se,...oe,minWidth:80,cursor:`pointer`,touchAction:`manipulation`,WebkitTapHighlightColor:`transparent`},onClick:e=>{e.preventDefault(),e.stopPropagation(),Be(t)},children:t.status===`partial`?`Partially Pay`:`Pay Now`})}),(0,w.jsx)(`td`,{style:{padding:`10px 12px`},children:(0,w.jsx)(`span`,{style:{padding:`5px 10px`,borderRadius:12,fontWeight:700,fontSize:11,...ae(t.status)},children:t.status})}),(0,w.jsx)(`td`,{style:{padding:`10px 12px`},children:(0,w.jsx)(`button`,{className:`action-dd-wrap`,ref:e=>{De.current[t.id]=e},onClick:e=>Fe(e,t),style:{...oe,background:`#C8991A`,color:`#071e34`,border:`none`,cursor:`pointer`,minWidth:72},children:`Action `})})]},t.id)),Z.length===0&&(0,w.jsx)(`tr`,{children:(0,w.jsx)(`td`,{colSpan:10,style:{padding:28,textAlign:`center`,color:_.muted},children:`No challans found.`})})]})]})})]}),Se&&(0,C.createPortal)((0,w.jsx)(`div`,{onClick:()=>G(null),style:{position:`fixed`,inset:0,zIndex:9e3},children:(0,w.jsx)(`div`,{className:`action-dd-wrap`,onClick:e=>e.stopPropagation(),style:{position:`fixed`,top:Ce.top,right:Ce.right,background:`#0B2C4D`,border:`1px solid rgba(200,153,26,0.3)`,borderRadius:10,zIndex:9001,minWidth:210,boxShadow:`0 16px 48px rgba(0,0,0,0.6)`,overflow:`hidden`},children:Te.map((e,t)=>(0,w.jsx)(`div`,{onClick:e.fn,style:{padding:`10px 18px`,cursor:`pointer`,fontSize:13,color:`#C0C8D8`,borderBottom:`1px solid rgba(255,255,255,0.05)`,userSelect:`none`},onMouseEnter:e=>e.currentTarget.style.background=`rgba(200,153,26,0.14)`,onMouseLeave:e=>e.currentTarget.style.background=`transparent`,children:e.label},t))})}),document.body),R&&typeof document<`u`&&(0,C.createPortal)((0,w.jsx)(`div`,{style:{position:`fixed`,inset:0,zIndex:1e4,background:`rgba(2,12,24,0.78)`,backdropFilter:`blur(10px)`,display:`flex`,alignItems:`center`,justifyContent:`center`,padding:16},children:(0,w.jsxs)(`div`,{className:`super-module-card`,style:{...f,width:`min(760px, 100%)`,maxHeight:`92vh`,overflowY:`auto`,boxShadow:`0 30px 90px rgba(0,0,0,0.65)`},children:[(0,w.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:16,alignItems:`flex-start`,marginBottom:18},children:[(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`div`,{style:{color:_.gold,fontWeight:900,fontSize:22},children:`Edit Challan & Monthly Fee`}),(0,w.jsxs)(`div`,{style:{color:_.muted,marginTop:6},children:[R.name||`Student`,` - `,R.gr_number||`No GR`]})]}),(0,w.jsx)(`button`,{onClick:Re,style:{...h,padding:`8px 12px`},children:`Close`})]}),(0,w.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(2, minmax(0, 1fr))`,gap:14},children:[(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Challan Number`}),(0,w.jsx)(`input`,{style:u,value:z.challan_no,onChange:e=>B(t=>({...t,challan_no:e.target.value})),placeholder:`CH-0001`})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Due Date`}),(0,w.jsx)(`input`,{style:u,type:`date`,value:z.due_date,onChange:e=>B(t=>({...t,due_date:e.target.value}))})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Month`}),(0,w.jsx)(`input`,{style:u,value:z.month,onChange:e=>B(t=>({...t,month:e.target.value})),placeholder:`June`})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Year`}),(0,w.jsx)(`input`,{style:u,type:`number`,value:z.year,onChange:e=>B(t=>({...t,year:e.target.value})),placeholder:`2026`})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Monthly Fee`}),(0,w.jsx)(`input`,{style:u,type:`number`,min:`0`,value:z.monthly_fee,onChange:e=>B(t=>({...t,monthly_fee:e.target.value}))})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Paper Fund`}),(0,w.jsx)(`input`,{style:{...u,background:`rgba(30,58,138,0.16)`,color:`#93c5fd`},type:`number`,min:`0`,value:z.paper_fund,readOnly:!0})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Previous Arrears`}),(0,w.jsx)(`input`,{style:u,type:`number`,min:`0`,value:z.previous_arrears,onChange:e=>B(t=>({...t,previous_arrears:e.target.value}))})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Discount`}),(0,w.jsx)(`input`,{style:u,type:`number`,min:`0`,value:z.discount,onChange:e=>B(t=>({...t,discount:e.target.value}))})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`New Net Total`}),(0,w.jsxs)(`div`,{style:{...u,display:`flex`,alignItems:`center`,color:_.gold,fontWeight:900},children:[`Rs. `,j(Math.max(0,Number(z.monthly_fee||0)+Number(z.paper_fund||0)+Number(z.previous_arrears||0)-Number(z.discount||0)))]})]})]}),ge&&(0,w.jsx)(`div`,{style:{marginTop:14,color:_.red,background:`rgba(255,55,95,0.1)`,border:`1px solid rgba(255,55,95,0.25)`,borderRadius:12,padding:`10px 12px`,fontWeight:700},children:ge}),(0,w.jsxs)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,gap:10,marginTop:20,flexWrap:`wrap`},children:[(0,w.jsx)(`button`,{onClick:Re,style:h,disabled:H,children:`Cancel`}),(0,w.jsx)(`button`,{onClick:ze,style:p,disabled:H,children:H?`Saving...`:`Save Challan Changes`})]})]})}),document.body),N&&typeof document<`u`&&(0,C.createPortal)((0,w.jsx)(`div`,{style:{position:`fixed`,inset:0,zIndex:1e4,background:`rgba(2,12,24,0.78)`,backdropFilter:`blur(10px)`,display:`flex`,alignItems:`center`,justifyContent:`center`,padding:16},children:(0,w.jsxs)(`div`,{className:`super-module-card`,style:{...f,width:`min(760px, 100%)`,maxHeight:`92vh`,overflowY:`auto`,boxShadow:`0 30px 90px rgba(0,0,0,0.65)`},children:[(0,w.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:16,alignItems:`flex-start`,marginBottom:18},children:[(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`div`,{style:{color:_.gold,fontWeight:900,fontSize:22},children:`Receive Fee Payment`}),(0,w.jsxs)(`div`,{style:{color:_.muted,marginTop:6},children:[`Voucher `,N.challan_no,` - `,N.month,` `,N.year]})]}),(0,w.jsx)(`button`,{onClick:Ve,style:{...h,padding:`8px 12px`},children:`Close`})]}),(0,w.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(2, minmax(0, 1fr))`,gap:12,marginBottom:16},children:[[`Student`,N.name||`—`],[`Father`,N.father_name||`—`],[`GR No`,N.gr_number||`—`],[`Class`,`${N.class||`—`} / ${N.section||`—`}`]].map(([e,t])=>(0,w.jsxs)(`div`,{style:{background:`rgba(11,44,77,0.38)`,border:`1px solid ${_.border}`,borderRadius:12,padding:12},children:[(0,w.jsx)(`div`,{style:{color:_.muted,fontSize:11,textTransform:`uppercase`,fontWeight:800,marginBottom:5},children:e}),(0,w.jsx)(`div`,{style:{color:_.silver,fontWeight:800},children:t})]},e))}),(0,w.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(130px, 1fr))`,gap:10,marginBottom:18},children:[(0,w.jsxs)(`div`,{style:{background:`rgba(15,23,42,0.62)`,border:`1px solid ${_.border}`,borderRadius:12,padding:12},children:[(0,w.jsx)(`div`,{style:{color:_.muted,fontSize:11,fontWeight:800},children:`Gross Fee`}),(0,w.jsxs)(`div`,{style:{color:_.silver,fontWeight:900,marginTop:6},children:[`Rs. `,j(N.amount)]})]}),(0,w.jsxs)(`div`,{style:{background:`rgba(48,209,88,0.09)`,border:`1px solid rgba(48,209,88,0.22)`,borderRadius:12,padding:12},children:[(0,w.jsx)(`div`,{style:{color:_.green,fontSize:11,fontWeight:800},children:`Discount`}),(0,w.jsxs)(`div`,{style:{color:_.green,fontWeight:900,marginTop:6},children:[`Rs. `,j(P.discount)]})]}),(0,w.jsxs)(`div`,{style:{background:`rgba(200,153,26,0.09)`,border:`1px solid rgba(200,153,26,0.22)`,borderRadius:12,padding:12},children:[(0,w.jsx)(`div`,{style:{color:_.gold,fontSize:11,fontWeight:800},children:`Net Payable`}),(0,w.jsxs)(`div`,{style:{color:_.gold,fontWeight:900,marginTop:6},children:[`Rs. `,j(Q)]})]}),(0,w.jsxs)(`div`,{style:{background:`rgba(255,55,95,0.09)`,border:`1px solid rgba(255,55,95,0.2)`,borderRadius:12,padding:12},children:[(0,w.jsx)(`div`,{style:{color:_.red,fontSize:11,fontWeight:800},children:`Remaining`}),(0,w.jsxs)(`div`,{style:{color:Ue===0?_.green:_.red,fontWeight:900,marginTop:6},children:[`Rs. `,j(Ue)]})]})]}),(0,w.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:14},children:[(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Discount`}),(0,w.jsx)(`input`,{style:u,type:`number`,min:`0`,value:P.discount,onChange:e=>F(t=>({...t,discount:e.target.value})),placeholder:`0`})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Payment Mode`}),(0,w.jsxs)(`select`,{style:d,value:P.payment_mode,onChange:e=>F(t=>({...t,payment_mode:e.target.value})),children:[(0,w.jsx)(`option`,{value:`cash`,children:`Cash`}),(0,w.jsx)(`option`,{value:`online`,children:`Online`}),(0,w.jsx)(`option`,{value:`jazzcash`,children:`JazzCash`}),(0,w.jsx)(`option`,{value:`easypaisa`,children:`EasyPaisa`})]})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Amount Receiving Now`}),(0,w.jsx)(`input`,{style:u,type:`number`,min:`0`,max:Q,value:P.paid_amount,onChange:e=>F(t=>({...t,paid_amount:e.target.value})),placeholder:`Enter paid amount`}),(0,w.jsxs)(`div`,{style:{display:`flex`,gap:8,marginTop:8,flexWrap:`wrap`},children:[(0,w.jsx)(`button`,{type:`button`,style:{...h,padding:`7px 10px`,fontSize:12},onClick:()=>F(e=>({...e,paid_amount:Math.max(0,Q-$)})),children:`Full Pay`}),(0,w.jsx)(`button`,{type:`button`,style:{...h,padding:`7px 10px`,fontSize:12},onClick:()=>F(e=>({...e,paid_amount:Math.max(0,Q-$)})),children:`Remaining Only`})]})]}),(0,w.jsxs)(`div`,{children:[(0,w.jsx)(`label`,{style:m,children:`Already Paid`}),(0,w.jsxs)(`div`,{style:{...u,display:`flex`,alignItems:`center`,color:_.muted},children:[`Rs. `,j($)]})]}),(0,w.jsxs)(`div`,{style:{gridColumn:`1 / -1`},children:[(0,w.jsx)(`label`,{style:m,children:`Payment Note`}),(0,w.jsx)(`input`,{style:u,value:P.payment_note,onChange:e=>F(t=>({...t,payment_note:e.target.value})),placeholder:`Optional note, receipt reference, or discount reason`})]})]}),pe&&(0,w.jsx)(`div`,{style:{marginTop:14,color:_.red,background:`rgba(255,55,95,0.1)`,border:`1px solid rgba(255,55,95,0.25)`,borderRadius:12,padding:`10px 12px`,fontWeight:700},children:pe}),(0,w.jsxs)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,gap:10,marginTop:20,flexWrap:`wrap`},children:[(0,w.jsx)(`button`,{onClick:Ve,style:h,disabled:L,children:`Cancel`}),(0,w.jsx)(`button`,{onClick:He,style:p,disabled:L,children:L?`Saving...`:Ue===0?`Save Full Payment`:`Save Partial Payment`})]})]})}),document.body)]})}export{le as default,E as getTemplateTheme,A as printBatchChallans,k as printChallan,ce as printCompactBatch,O as renderAndPrintHtml,D as renderVoucherCopyHtml,x as t};