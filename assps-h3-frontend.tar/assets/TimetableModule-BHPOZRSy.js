import{a as e}from"./rolldown-runtime-BYbx6iT9.js";import{n as t,r as n}from"./vendor-motion-DoYOP1Wm.js";import{a as r}from"./useAcademicStore-CUKoORgi.js";import{t as i}from"./usePaperStore-CcjifFUq.js";var a=e(n(),1),o=t(),s=[`Monday`,`Tuesday`,`Wednesday`,`Thursday`,`Friday`,`Saturday`],c=[`Mr. Aamir`,`Ms. Saba`,`Mr. Bilal`,`Ms. Hira`,`Mr. Naveed`,`Ms. Farah`,`Mr. Qasim`,`Ms. Sana`],l=`al_siddique_academic`;function u(){try{return typeof window<`u`?window.localStorage:null}catch{return null}}var d=()=>{try{var e;let t=JSON.parse(((e=u())==null?void 0:e.getItem(l))||`{}`);return Number(t.periodsPerDay||8)}catch{return 8}},f=e=>String(e||``).replaceAll(`&`,`&`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#039;`),p=({school:e,schoolClass:t,section:n,periods:r,days:i,assignments:a})=>{let o=`${t} - Section ${n} Timetable`,s=new Date().toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`}),c=(e==null?void 0:e.schoolName)||`Al Siddique Scholars Public School`,l=e!=null&&e.showUrduHeader?e==null?void 0:e.schoolUrdu:``,u=e==null?void 0:e.logo,d=i.map(e=>`
 <tr>
 <th class="day-cell">${f(e)}</th>
 ${r.map(t=>{var n;let r=((n=a[e])==null?void 0:n[t])||{};return`
 <td>
 <strong>${f(r.subject||`English`)}</strong>
 <span>${f(r.teacher||`Mr. Aamir`)}</span>
 </td>
 `}).join(``)}
 </tr>
 `).join(``),p=`<!doctype html>
<html>
<head>
 <meta charset="utf-8" />
 <title>${f(o)}</title>
 <style>
 @page { size: A4 landscape; margin: 9mm; }
 * { box-sizing: border-box; }
 body { margin: 0; background: #eef2f7; color: #101827; font-family: Arial, sans-serif; }
 .toolbar { position: sticky; top: 0; z-index: 5; display: flex; align-items: center; gap: 12px; padding: 10px 14px; background: #071e34; color: #d9dee8; box-shadow: 0 6px 18px rgba(15,23,42,.22); }
 .toolbar strong { color: #e8b420; }
 .toolbar button { margin-left: auto; border: 0; border-radius: 7px; padding: 9px 18px; background: #c8991a; color: #071e34; font-weight: 800; cursor: pointer; }
 .sheet { width: 279mm; min-height: 190mm; margin: 14px auto; padding: 10mm; background: white; box-shadow: 0 16px 45px rgba(15,23,42,.18); }
 header { display: flex; align-items: center; gap: 12px; border-bottom: 2px solid #c8991a; padding-bottom: 9px; margin-bottom: 10px; }
 .logo { width: 54px; height: 54px; object-fit: contain; border: 1px solid #d9dee8; border-radius: 10px; padding: 3px; }
 .fallback-logo { width: 54px; height: 54px; display: grid; place-items: center; border-radius: 10px; background: #0b2c4d; color: #c8991a; font-size: 24px; font-weight: 900; }
 h1 { margin: 0; color: #0b2c4d; font-size: 21px; line-height: 1.1; }
 .urdu { margin-top: 3px; color: #334155; font-size: 14px; direction: rtl; font-family: "Noto Nastaliq Urdu", "Jameel Noori Nastaleeq", serif; }
 .meta { margin-left: auto; text-align: right; color: #475569; font-size: 11px; line-height: 1.7; }
 .title-row { display: flex; justify-content: space-between; align-items: center; gap: 14px; margin: 10px 0 9px; }
 .title-row h2 { margin: 0; color: #c8991a; font-size: 17px; }
 .badge { border: 1px solid #d9dee8; border-radius: 999px; padding: 6px 10px; color: #0b2c4d; font-size: 11px; font-weight: 800; }
 table { width: 100%; border-collapse: collapse; table-layout: fixed; border: 1px solid #cbd5e1; }
 th, td { border: 1px solid #cbd5e1; padding: 6px 5px; vertical-align: middle; text-align: center; }
 thead th { background: #0b2c4d; color: white; font-size: 10.5px; letter-spacing: .02em; }
 .day-cell { width: 25mm; background: #f8fafc; color: #0b2c4d; font-size: 11px; text-align: left; }
 td strong { display: block; color: #101827; font-size: 10.5px; line-height: 1.2; }
 td span { display: block; margin-top: 3px; color: #64748b; font-size: 9px; line-height: 1.2; }
 footer { display: flex; justify-content: space-between; gap: 12px; margin-top: 10px; color: #64748b; font-size: 10px; }
 @media print {
 body { background: white; }
 .toolbar { display: none; }
 .sheet { width: auto; min-height: auto; margin: 0; padding: 0; box-shadow: none; }
 }
 </style>
</head>
<body>
 <div class="toolbar"><strong>Timetable Print Preview</strong><span>${f(o)}</span><button onclick="window.print()">Print / Save PDF</button></div>
 <main class="sheet">
 <header>
 ${u?`<img class="logo" src="${u}" alt="">`:`<div class="fallback-logo">A</div>`}
 <div>
 <h1>${f(c)}</h1>
 ${l?`<div class="urdu">${f(l)}</div>`:``}
 <div style="color:#64748b;font-size:11px;margin-top:4px">${f((e==null?void 0:e.address)||``)}</div>
 </div>
 <div class="meta">
 <div><strong>Session:</strong> ${f((e==null?void 0:e.examYear)||`2026-2027`)}</div>
 <div><strong>Date:</strong> ${f(s)}</div>
 <div><strong>Phone:</strong> ${f((e==null?void 0:e.phone)||``)}</div>
 </div>
 </header>
 <section class="title-row">
 <h2>${f(o)}</h2>
 <div class="badge">${r.length} periods per day</div>
 </section>
 <table>
 <thead>
 <tr>
 <th class="day-cell">Day</th>
 ${r.map(e=>`<th>${f(e)}</th>`).join(``)}
 </tr>
 </thead>
 <tbody>${d}</tbody>
 </table>
 <footer>
 <span>Generated by OS Siddique Smart School OS</span>
 <span>Principal / Coordinator Signature: ____________________</span>
 </footer>
 </main>
</body>
</html>`,m=window.open(``,`_blank`,`width=1200,height=850`);if(!m){alert(`Popup blocked. Please allow popups in your browser and try printing again.`);return}m.document.open(),m.document.write(p),m.document.close(),m.focus()},m={background:`rgba(11,44,77,0.6)`,border:`1px solid rgba(200,153,26,0.2)`,borderRadius:22,backdropFilter:`blur(18px)`,color:`#C0C8D8`},h={display:`block`,fontSize:12,color:`#8892A4`,marginBottom:8,letterSpacing:`0.06em`,textTransform:`uppercase`},g={width:`100%`,padding:`12px 14px`,borderRadius:14,border:`1px solid rgba(148,163,184,0.18)`,background:`rgba(7,30,52,0.75)`,color:`#C0C8D8`,fontSize:14,outline:`none`};function _(){var e;let{classNames:t,activeClasses:n,subjectsForClass:l,allSections:u}=r(),{paperSettings:f}=i(),[_,v]=(0,a.useState)(t[0]||`Starter`),y=n.find(e=>e.name===_),b=!(y==null||(e=y.sections)==null)&&e.length?y.sections:u.length?u:[`A`],x=y?l(y.level):[`English`],[S,C]=(0,a.useState)(b[0]||`A`),[w,T]=(0,a.useState)(d),[E,D]=(0,a.useState)(()=>{let e=d(),t={};return s.forEach(n=>{t[n]={};for(let r=1;r<=e;r++){let e=`Period ${r}`;t[n][e]={subject:x[0],teacher:c[0]}}}),t}),O=(0,a.useMemo)(()=>{let e=[];for(let t=1;t<=w;t++)e.push(`Period ${t}`);return e},[w]),k=Math.max(980,132+O.length*154);(0,a.useEffect)(()=>{t.length&&!t.includes(_)&&v(t[0])},[t,_]),(0,a.useEffect)(()=>{b.length&&!b.includes(S)&&C(b[0])},[b,S]);let A=(e,t,n,r)=>{D(i=>({...i,[e]:{...i[e],[t]:{...i[e][t],[n]:r}}}))},j=(0,a.useMemo)(()=>s.reduce((e,t)=>e+O.reduce((e,n)=>{var r;return e+(!((r=E[t])==null||(r=r[n])==null)&&r.subject?1:0)},0),0),[E,O]),M=()=>{p({school:f,schoolClass:_,section:S,periods:O,days:s,assignments:E})};return(0,o.jsx)(`div`,{style:{minHeight:`100vh`,background:`#071e34`,color:`#C0C8D8`,padding:24,fontFamily:`Inter, sans-serif`},children:(0,o.jsxs)(`div`,{style:{width:`100%`,maxWidth:1600,margin:`0 auto`,display:`grid`,gap:22,minWidth:0},children:[(0,o.jsx)(`div`,{className:`super-module-card`,style:{...m,padding:28,boxShadow:`0 18px 40px rgba(0,0,0,0.24)`,borderRadius:24},children:(0,o.jsxs)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:20,alignItems:`center`,justifyContent:`space-between`},children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{style:{color:`#C8991A`,fontSize:28,fontWeight:600,marginBottom:10},children:`Timetable Manager`}),(0,o.jsx)(`div`,{style:{color:`#8892A4`,fontSize:14},children:`Choose class, section, and number of periods, then assign subjects and teachers across the school week.`})]}),(0,o.jsx)(`button`,{onClick:M,style:{background:`linear-gradient(135deg, #C8991A, #e8b420)`,color:`#071e34`,border:`none`,borderRadius:14,padding:`14px 22px`,cursor:`pointer`,fontWeight:700,fontSize:14},children:`Print Timetable`})]})}),(0,o.jsxs)(`div`,{style:{display:`grid`,gap:22},children:[(0,o.jsxs)(`div`,{className:`super-module-card timetable-controls`,style:{...m,padding:24,display:`grid`,gridTemplateColumns:`minmax(180px,1fr) minmax(160px,1fr) minmax(160px,0.7fr)`,gap:20},children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`span`,{style:h,children:`Class`}),(0,o.jsx)(`select`,{value:_,onChange:e=>v(e.target.value),style:g,children:t.map(e=>(0,o.jsx)(`option`,{value:e,children:e},e))})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`span`,{style:h,children:`Section`}),(0,o.jsx)(`select`,{value:S,onChange:e=>C(e.target.value),style:g,children:b.map(e=>(0,o.jsx)(`option`,{value:e,children:e},e))})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`span`,{style:h,children:`Number of Periods`}),(0,o.jsx)(`select`,{value:w,onChange:e=>T(Number(e.target.value)),style:g,children:[4,5,6,7,8,9,10].map(e=>(0,o.jsxs)(`option`,{value:e,children:[e,` Periods`]},e))})]})]}),(0,o.jsxs)(`div`,{className:`super-module-card`,style:{...m,padding:24,minWidth:0},children:[(0,o.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:20,flexWrap:`wrap`,marginBottom:20},children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{style:{color:`#C8991A`,fontSize:18,fontWeight:700,marginBottom:6},children:`Current Selection`}),(0,o.jsxs)(`div`,{style:{color:`#C0C8D8`},children:[_,` · Section `,S]})]}),(0,o.jsxs)(`div`,{style:{display:`flex`,gap:12,alignItems:`center`},children:[(0,o.jsx)(`div`,{style:{color:`#8892A4`,fontSize:13},children:`Assigned lessons`}),(0,o.jsx)(`div`,{style:{background:`rgba(200,153,26,0.16)`,color:`#C8991A`,borderRadius:14,padding:`8px 14px`,fontWeight:700},children:j})]})]}),(0,o.jsx)(`div`,{className:`os-scroll-x timetable-scroll`,style:{overflowX:`auto`,overflowY:`hidden`,width:`100%`,maxWidth:`100%`,paddingBottom:12},children:(0,o.jsx)(`div`,{style:{minWidth:k},children:(0,o.jsxs)(`table`,{style:{width:`100%`,tableLayout:`fixed`,borderCollapse:`collapse`},children:[(0,o.jsxs)(`colgroup`,{children:[(0,o.jsx)(`col`,{style:{width:132}}),O.map(e=>(0,o.jsx)(`col`,{style:{width:`${(k-132)/O.length}px`}},e))]}),(0,o.jsx)(`thead`,{children:(0,o.jsxs)(`tr`,{children:[(0,o.jsx)(`th`,{style:{padding:`12px 12px`,textAlign:`left`,color:`#C8991A`,borderBottom:`1px solid rgba(200,153,26,0.2)`,position:`sticky`,left:0,zIndex:3,background:`#10223b`},children:`Day`}),O.map(e=>(0,o.jsx)(`th`,{style:{padding:`12px 10px`,textAlign:`center`,color:`#C8991A`,borderBottom:`1px solid rgba(200,153,26,0.2)`},children:e},e))]})}),(0,o.jsx)(`tbody`,{children:s.map(e=>(0,o.jsxs)(`tr`,{style:{borderTop:`1px solid rgba(200,153,26,0.12)`},children:[(0,o.jsx)(`td`,{style:{padding:`12px 12px`,fontWeight:700,color:`#fff`,background:`#08243e`,position:`sticky`,left:0,zIndex:2},children:e}),O.map(t=>{var n,r;return(0,o.jsx)(`td`,{style:{padding:8,verticalAlign:`top`},children:(0,o.jsxs)(`div`,{style:{display:`grid`,gap:8,padding:10,borderRadius:14,background:`rgba(11,44,77,0.92)`,border:`1px solid rgba(200,153,26,0.12)`},children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`span`,{style:h,children:`Subject`}),(0,o.jsx)(`select`,{value:((n=E[e][t])==null?void 0:n.subject)||x[0],onChange:n=>A(e,t,`subject`,n.target.value),style:g,children:x.map(e=>(0,o.jsx)(`option`,{value:e,children:e},e))})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`span`,{style:h,children:`Teacher`}),(0,o.jsx)(`select`,{value:((r=E[e][t])==null?void 0:r.teacher)||c[0],onChange:n=>A(e,t,`teacher`,n.target.value),style:g,children:c.map(e=>(0,o.jsx)(`option`,{value:e,children:e},e))})]})]})},t)})]},e))})]})})})]})]})]})})}export{_ as default};