import{a as e}from"./rolldown-runtime-BYbx6iT9.js";import{n as t,r as n}from"./vendor-motion-DoYOP1Wm.js";import{Fn as r,Ht as i,In as a,Sn as o,c as s,it as c,l}from"./vendor-react-TqftcNZp.js";import{f as u}from"./index-Crdi7rpf.js";import{a as d}from"./useAcademicStore-CUKoORgi.js";import{t as f}from"./usePaperStore-CcjifFUq.js";import{t as p}from"./Portal-BMAefKvC.js";import{renderVoucherCopyHtml as m}from"./ViewChallans-BT0JGo40.js";var h=e(n(),1),g=t(),_=[`January`,`February`,`March`,`April`,`May`,`June`,`July`,`August`,`September`,`October`,`November`,`December`],v=[{id:1,name:`Monthly Fee`,defaultAmount:1500},{id:2,name:`Exam Fee`,defaultAmount:500},{id:3,name:`Registration Fee`,defaultAmount:1e3},{id:4,name:`Library Fee`,defaultAmount:200},{id:5,name:`Computer Fee`,defaultAmount:300},{id:6,name:`Sports Fee`,defaultAmount:150},{id:7,name:`Transport Fee`,defaultAmount:800}],y=e=>{let t=x.find(t=>t.id===e.student_id);return{id:e.id,voucherNo:e.challan_no||e.voucherNo||``,studentId:e.student_id,student:e.name||e.student||(t==null?void 0:t.name)||``,father:e.father_name||e.father||(t==null?void 0:t.father)||``,gr:e.gr_number||e.gr||(t==null?void 0:t.gr)||``,class:e.class||(t==null?void 0:t.class)||``,section:e.section||(t==null?void 0:t.section)||`Blue`,familyCode:e.familyCode||(t==null?void 0:t.familyCode)||`—`,contact:e.parent_phone||e.contact||(t==null?void 0:t.contact)||``,month:e.month||`05`,year:e.year||`2026`,feeHeads:[{name:`Monthly Fee`,amount:Number(e.amount||0)}],discount:0,lateFee:0,total:Number(e.amount||0),paid:Number(e.paid_amount||0),status:e.status?`${e.status.charAt(0).toUpperCase()}${e.status.slice(1)}`:`Unpaid`,dueDate:e.due_date||`2026-05-10`,paidDate:e.paid_date||null}},b=[{id:`classic`,label:`Classic Replica`},{id:`modern`,label:`Ultra Modern`},{id:`elegant`,label:`Sleek Elegant`}],x=[{id:1,gr:`GR-001`,name:`Ahmed Raza`,father:`Muhammad Raza`,class:`Pre Nine`,section:`Blue`,contact:`0300-1234567`,discount:0,familyCode:`501`},{id:2,gr:`GR-002`,name:`Fatima Noor`,father:`Noor Ahmad`,class:`Pre Nine`,section:`Fatima`,contact:`0301-2345678`,discount:200,familyCode:`502`},{id:3,gr:`GR-003`,name:`Bilal Hassan`,father:`Hassan Ali`,class:`Pre Nine`,section:`Usman`,contact:`0302-3456789`,discount:0,familyCode:`503`},{id:4,gr:`GR-004`,name:`Ayesha Malik`,father:`Malik Usman`,class:`Eight`,section:`Blue`,contact:`0303-4567890`,discount:300,familyCode:`504`},{id:5,gr:`GR-005`,name:`Usman Tariq`,father:`Tariq Mehmood`,class:`Seven`,section:`Blue`,contact:`0304-5678901`,discount:0,familyCode:`505`},{id:6,gr:`GR-006`,name:`Zainab Khalid`,father:`Khalid Hussain`,class:`Six`,section:`Blue`,contact:`0305-6789012`,discount:0,familyCode:`502`},{id:7,gr:`GR-007`,name:`Hamza Sheikh`,father:`Sheikh Imran`,class:`Five`,section:`Blue`,contact:`0306-7890123`,discount:500,familyCode:`506`},{id:8,gr:`GR-008`,name:`Sana Iqbal`,father:`Iqbal Ahmed`,class:`Four`,section:`Blue`,contact:`0307-8901234`,discount:0,familyCode:`507`},{id:9,gr:`GR-009`,name:`Ali Nawaz`,father:`Nawaz Khan`,class:`Three`,section:`Blue`,contact:`0308-9012345`,discount:0,familyCode:`508`},{id:10,gr:`GR-010`,name:`Mariam Aslam`,father:`Aslam Khan`,class:`Two`,section:`Blue`,contact:`0309-0123456`,discount:200,familyCode:`509`}];(()=>{let e=[],t=1001;return x.forEach(n=>{[3,4,5].forEach(r=>{let i=_[r-1],a=1500+(r===4?500:0)-n.discount,o=Math.random()>.35?a:0;e.push({id:t,voucherNo:`AL-${t}`,studentId:n.id,student:n.name,father:n.father,gr:n.gr,class:n.class,contact:n.contact,month:i,year:2026,feeHeads:[{name:`Monthly Fee`,amount:1500},...r===4?[{name:`Exam Fee`,amount:500}]:[]],discount:n.discount,lateFee:0,total:a,paid:o,status:o>=a?`Paid`:o>0?`Partial`:`Unpaid`,dueDate:`2026-0${r}-10`,paidDate:o>0?`2026-0${r}-05`:null}),t+=1})}),e})();var S={card:`rgba(11,44,77,0.92)`,gold:`#C8991A`,goldL:`#e8b420`,silver:`#C0C8D8`,muted:`#8892A4`,green:`#30D158`,red:`#FF375F`,orange:`#FF9F0A`,blue:`#0A84FF`,border:`rgba(148,163,184,0.18)`},C=({children:e,style:t={}})=>(0,g.jsx)(`div`,{className:`super-module-card`,style:{background:S.card,backdropFilter:`blur(20px)`,border:`1px solid ${S.border}`,borderRadius:22,padding:24,boxShadow:`0 12px 32px rgba(7,30,52,0.28)`,...t},children:e}),w=({active:e,onClick:t,children:n})=>(0,g.jsx)(`button`,{onClick:t,style:{background:e?`linear-gradient(135deg, ${S.gold}, ${S.goldL})`:`rgba(15,23,42,0.46)`,color:e?`#071e34`:S.silver,fontWeight:700,fontSize:14,padding:`10px 22px`,borderRadius:14,border:e?`none`:`1px solid ${S.border}`,cursor:`pointer`,transition:`all 0.18s ease`},children:n}),T=({children:e})=>(0,g.jsx)(`label`,{style:{color:S.muted,fontSize:12,fontWeight:600,display:`block`,marginBottom:8,letterSpacing:`0.06em`},children:e}),E=({style:e={},...t})=>(0,g.jsx)(`input`,{...t,style:{width:`100%`,background:`rgba(11,44,77,0.6)`,border:`1px solid ${S.border}`,borderRadius:12,color:S.silver,padding:`11px 14px`,fontSize:14,outline:`none`,boxSizing:`border-box`,...e}}),D=({style:e={},children:t,...n})=>(0,g.jsx)(`select`,{...n,style:{width:`100%`,background:`rgba(11,44,77,0.6)`,border:`1px solid ${S.border}`,borderRadius:12,color:S.silver,padding:`11px 14px`,fontSize:14,outline:`none`,cursor:`pointer`,boxSizing:`border-box`,WebkitAppearance:`none`,MozAppearance:`none`,appearance:`none`,...e},children:t}),O=({status:e})=>{let t={Paid:{color:`#fff`,bg:S.green},Unpaid:{color:`#fff`,bg:S.red},Partial:{color:`#fff`,bg:S.orange}}[e]||{color:S.muted,bg:`rgba(255,255,255,0.08)`};return(0,g.jsx)(`span`,{style:{display:`inline-block`,textAlign:`center`,background:t.bg,color:t.color,width:`100%`,padding:`4px 0`,borderRadius:4,fontWeight:600,fontSize:12},children:e})};function k({onPrint:e}){let[t,n]=(0,h.useState)(!1),r=[{label:`Edit Challan`,color:S.silver},{label:`Delete Challan`,color:S.red},{label:`View Fee History`,color:S.blue},{label:`One Student (1 Copy)`,action:()=>e(`1c`)},{label:`One Student (1 Copy - Thermal)`,action:()=>e(`thermal`)},{label:`One Student (2 Copies)`,action:()=>e(`2c`)},{label:`One Student (3 Copies)`,action:()=>e(`3c`)},{label:`Family Single Voucher`,action:()=>alert(`Printing Family Single Voucher...`)},{label:`Family Double Voucher`,action:()=>alert(`Printing Family Double Voucher...`)},{label:`Family Triple Voucher`,action:()=>alert(`Printing Family Triple Voucher...`)},{label:`Family Fee Report`,action:()=>alert(`Generating Family Fee Report...`)}];return(0,g.jsxs)(`div`,{className:`super-module-card`,style:{position:`relative`},children:[(0,g.jsxs)(`button`,{onClick:()=>n(!t),onBlur:()=>setTimeout(()=>n(!1),200),style:{background:S.gold,color:`#fff`,border:`none`,borderRadius:4,padding:`4px 12px`,fontSize:13,fontWeight:600,cursor:`pointer`,display:`flex`,alignItems:`center`,gap:6},children:[`Action `,(0,g.jsx)(`span`,{style:{fontSize:10}})]}),t&&(0,g.jsx)(`div`,{className:`super-module-card`,style:{position:`absolute`,right:0,top:`100%`,marginTop:4,width:220,background:`#fff`,borderRadius:6,boxShadow:`0 4px 12px rgba(0,0,0,0.3)`,zIndex:100,overflow:`hidden`,border:`1px solid #ddd`},children:r.map((e,t)=>(0,g.jsx)(`div`,{onClick:()=>{var t;(t=e.action)==null||t.call(e),n(!1)},style:{padding:`8px 16px`,fontSize:12,color:e.color||`#334155`,cursor:`pointer`,borderBottom:t<r.length-1?`1px solid #f1f5f9`:`none`,background:`#fff`},onMouseEnter:e=>e.currentTarget.style.background=`#f8fafc`,onMouseLeave:e=>e.currentTarget.style.background=`#fff`,children:e.label},t))})]})}var A=({icon:e,label:t,value:n,color:r})=>(0,g.jsxs)(C,{style:{display:`flex`,alignItems:`center`,gap:16,padding:`22px 24px`,background:`linear-gradient(145deg, ${r}18, rgba(11,44,77,0.96) 48%, rgba(7,30,52,0.98))`,border:`1px solid ${r}35`,borderRadius:22,boxShadow:`0 18px 42px rgba(0,0,0,0.22), 0 0 28px ${r}12`},children:[(0,g.jsx)(`div`,{className:`super-module-card`,style:{width:52,height:52,borderRadius:18,background:`linear-gradient(135deg, ${r}2e, rgba(255,255,255,0.045))`,border:`1px solid ${r}55`,display:`grid`,placeItems:`center`,color:r,boxShadow:`0 12px 24px ${r}18`},children:e}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:r,fontSize:24,fontWeight:850,letterSpacing:-.3},children:n}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:S.muted,fontSize:12,marginTop:4,fontWeight:650},children:t})]})]});function j({challan:e,selectedTemplate:t,onClose:n,school:r}){if(!e)return null;let i={classic:1,modern:2,elegant:3,thermal:3}[t||`classic`]||1,a={name:(r==null?void 0:r.schoolName)||(r==null?void 0:r.name)||`Al Siddique Scholars Public School`,logo:(r==null?void 0:r.logo)||``,address:(r==null?void 0:r.address)||``};return(0,g.jsx)(p,{children:(0,g.jsxs)(`div`,{className:`super-module-card`,style:{position:`fixed`,inset:0,zIndex:1e4,background:`rgba(7,30,52,0.95)`,backdropFilter:`blur(12px)`,display:`flex`,flexDirection:`column`,alignItems:`center`,justifyContent:`center`,padding:24},children:[(0,g.jsx)(`style`,{children:`
          @page {
            size: A4 landscape;
            margin: 2mm 3mm;
          }
          @media screen {
            .print-scroll-container {
              overflow-y: auto;
              flex: 1;
              width: 100%;
              display: flex;
              justify-content: center;
              padding: 10px 0;
            }
            .print-voucher-root {
              transform: scale(0.6);
              transform-origin: top center;
              margin-bottom: -160px; /* offset scale margin */
            }
          }
          @media print {
            body * { visibility: hidden !important; }
            .print-voucher-root, .print-voucher-root * { visibility: visible !important; }
            .print-voucher-root {
              position: absolute !important;
              left: 0 !important;
              top: 0 !important;
              width: 297mm !important;
              height: 210mm !important;
              box-shadow: none !important;
              padding: 2mm 3mm !important;
              margin: 0 !important;
              background: #fff !important;
            }
            .no-print { display: none !important; }
            .print-scroll-container { overflow: visible !important; height: auto !important; width: 100% !important; padding: 0 !important; }
            .no-print-border { border-left: 1.5px dashed #ccc !important; border-top: none !important; height: 204mm !important; width: 1px !important; margin: 0 2mm !important; }
          }
        `}),(0,g.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,width:`100%`,maxWidth:`297mm`,background:`#0b2c4d`,padding:`12px 24px`,borderRadius:`12px 12px 0 0`,color:`#fff`,boxSizing:`border-box`},className:`no-print`,children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`div`,{style:{color:`#e8c87a`,fontWeight:900,fontSize:18},children:`Fee Voucher Preview (Landscape)`}),(0,g.jsxs)(`div`,{style:{color:`#fff`,fontSize:13,fontWeight:800,marginTop:4},children:[`Voucher No: `,e.voucherNo||e.challan_no]})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,gap:10,alignItems:`center`},children:[(0,g.jsx)(`button`,{onClick:()=>window.print(),style:{background:`linear-gradient(135deg, #c8991a, #e8c87a)`,color:`#071e34`,border:`none`,padding:`10px 18px`,borderRadius:12,cursor:`pointer`,fontWeight:700},children:`Print`}),(0,g.jsx)(`button`,{onClick:n,style:{background:`rgba(255,55,95,0.18)`,border:`1px solid rgba(255,55,95,0.4)`,color:`#FF375F`,padding:`10px 16px`,borderRadius:12,cursor:`pointer`,fontWeight:700},children:`Close`})]})]}),(0,g.jsx)(`div`,{className:`print-scroll-container`,children:(0,g.jsx)(`div`,{className:`print-voucher-root`,style:{background:`#fff`,boxShadow:`0 4px 20px rgba(0,0,0,0.15)`,boxSizing:`border-box`,padding:`2mm 3mm`,width:`297mm`,height:`210mm`,display:`flex`,flexDirection:`row`,gap:`6px`,position:`relative`},children:(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`row`,gap:`6px`,width:`291mm`,height:`204mm`,boxSizing:`border-box`},children:[(0,g.jsx)(`div`,{style:{width:`calc(33.33% - 4px)`,height:`204mm`,display:`flex`},dangerouslySetInnerHTML:{__html:m(e,`Student Copy`,a,i)}}),(0,g.jsx)(`div`,{style:{borderLeft:`1.5px dashed #ccc`,width:`1px`,margin:`0 2mm`,height:`204mm`},className:`no-print-border`}),(0,g.jsx)(`div`,{style:{width:`calc(33.33% - 4px)`,height:`204mm`,display:`flex`},dangerouslySetInnerHTML:{__html:m(e,`Institute Copy`,a,i)}}),(0,g.jsx)(`div`,{style:{borderLeft:`1.5px dashed #ccc`,width:`1px`,margin:`0 2mm`,height:`204mm`},className:`no-print-border`}),(0,g.jsx)(`div`,{style:{width:`calc(33.33% - 4px)`,height:`204mm`,display:`flex`},dangerouslySetInnerHTML:{__html:m(e,`Bank Copy`,a,i)}})]})})})]})})}function M({list:e,onClose:t,school:n}){if(!e)return null;let{type:r,data:i}=e,a=(n==null?void 0:n.logo)||``,o=(n==null?void 0:n.schoolName)||`Al Siddique Scholars Public School`,s=(n==null?void 0:n.address)||`Sharif Chowk, Rayya Khas, Narowal`,c=(n==null?void 0:n.phone)||`0300-1291959`,{paperSettings:l}=f(),u=(l==null?void 0:l.principalSignature)||(n==null?void 0:n.principalSignature)||null,d=new Date().toLocaleDateString(`en-GB`,{day:`2-digit`,month:`long`,year:`numeric`});return(0,g.jsx)(p,{children:(0,g.jsxs)(`div`,{className:`super-module-card`,style:{position:`fixed`,inset:0,zIndex:10001,background:`rgba(7,30,52,0.98)`,display:`flex`,alignItems:`center`,justifyContent:`center`,padding:24},children:[(0,g.jsx)(`style`,{children:`
          @media print {
            @page {
              size: A4 portrait;
              margin: 12mm 10mm 15mm 10mm;
            }
            html, body {
              background: #fff !important;
              color: #000 !important;
              height: auto !important;
              min-height: 100% !important;
              overflow: visible !important;
              margin: 0 !important;
              padding: 0 !important;
            }
            body * {
              visibility: hidden;
            }
            .print-list-root, .print-list-root * {
              visibility: visible !important;
            }
            .print-list-root {
              position: static !important;
              left: auto !important;
              top: auto !important;
              width: 100% !important;
              max-width: 100% !important;
              height: auto !important;
              min-height: 0 !important;
              max-height: none !important;
              overflow: visible !important;
              background: #fff !important;
              border-radius: 0 !important;
              box-shadow: none !important;
              margin: 0 !important;
              padding: 0 !important;
              display: block !important;
            }
            .no-print {
              display: none !important;
            }
            table {
              width: 100% !important;
              border-collapse: collapse !important;
              page-break-inside: auto !important;
            }
            thead {
              display: table-header-group !important;
            }
            tbody {
              display: table-row-group !important;
            }
            tr {
              page-break-inside: avoid !important;
              break-inside: avoid !important;
            }
            th, td {
              border: 1px solid #888 !important;
              padding: 6px 8px !important;
              text-align: left !important;
              font-size: 10.5px !important;
              color: #000 !important;
            }
            th {
              background: #f0f4f8 !important;
              font-weight: 700 !important;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
          }
        `}),(0,g.jsxs)(`div`,{className:`print-list-root`,style:{width:`100%`,maxWidth:1e3,background:`#fff`,borderRadius:20,overflow:`hidden`,height:`90vh`,display:`flex`,flexDirection:`column`},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{padding:`16px 24px`,background:`#0b2c4d`,color:`#fff`,display:`flex`,justifyContent:`space-between`,alignItems:`center`},className:`no-print`,children:[(0,g.jsxs)(`h3`,{style:{margin:0},children:[` `,r]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,gap:10},children:[(0,g.jsx)(`button`,{onClick:()=>{let e=(i||[]).map((e,t)=>`
      <tr>
        <td style="padding: 6px 8px; border: 1px solid #aaa; text-align: center; width: 35px;">${t+1}</td>
        <td style="padding: 6px 8px; border: 1px solid #aaa; font-weight: 700; color: #0b2c4d; width: 75px;">${e.gr||`—`}</td>
        <td style="padding: 6px 8px; border: 1px solid #aaa; font-weight: 700; color: #111;">${e.student||e.name||`—`}</td>
        <td style="padding: 6px 8px; border: 1px solid #aaa;">${e.father||`—`}</td>
        <td style="padding: 6px 8px; border: 1px solid #aaa; width: 105px;">${e.class||``} / ${e.section||``}</td>
        <td style="padding: 6px 8px; border: 1px solid #aaa; text-align: center; width: 85px;">${e.familyCode||`—`}</td>
        <td style="padding: 6px 8px; border: 1px solid #aaa; text-align: right; font-weight: 600; width: 85px;">${e.total||e.fee||`0`}</td>
        <td style="padding: 6px 8px; border: 1px solid #aaa; text-align: center; font-weight: 700; width: 70px; color: ${e.status===`Paid`?`#166534`:`#991b1b`};">${e.status||`—`}</td>
      </tr>
    `).join(``),t=u?`<img src="${u}" style="height:36px; max-width:130px; object-fit:contain;" alt="Signature" />`:`<span style="display:inline-block; height:36px; width:130px;"></span>`,n=`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${r} — ${o}</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 10mm 15mm 10mm;
    }
    * {
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: #fff;
      color: #111;
      font-size: 11px;
    }
    .header-box {
      display: flex;
      align-items: center;
      gap: 16px;
      margin-bottom: 12px;
      border-bottom: 2px solid #0b2c4d;
      padding-bottom: 10px;
    }
    .school-title {
      margin: 0;
      font-size: 20px;
      font-weight: 800;
      color: #0b2c4d;
      font-family: 'Cinzel', serif, Georgia, Arial;
      letter-spacing: 0.5px;
    }
    .school-meta {
      font-size: 11px;
      color: #555;
      margin-top: 2px;
    }
    .report-title {
      margin: 6px 0 0;
      font-size: 14px;
      font-weight: 700;
      color: #b8860b;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      page-break-inside: auto;
      margin-top: 8px;
    }
    thead {
      display: table-header-group;
    }
    tbody {
      display: table-row-group;
    }
    tr {
      page-break-inside: avoid;
      break-inside: avoid;
    }
    th, td {
      border: 1px solid #aaa;
      padding: 5.5px 7px;
      text-align: left;
      font-size: 10.5px;
      color: #111;
    }
    th {
      background: #f0f4f8 !important;
      font-weight: 700;
      color: #0b2c4d;
      text-transform: uppercase;
      font-size: 9.5px;
      letter-spacing: 0.5px;
    }
    .footer-box {
      margin-top: 20px;
      padding-top: 10px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      font-size: 11px;
      color: #444;
      page-break-inside: avoid;
      break-inside: avoid;
    }
    .sig-block {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      min-width: 140px;
    }
    .sig-line {
      border-top: 1px solid #333;
      padding-top: 4px;
      width: 100%;
      text-align: center;
      font-size: 10px;
      font-weight: 600;
      color: #222;
    }
  </style>
</head>
<body>
  <div class="header-box">
    ${a?`<img src="${a}" style="width:65px; height:65px; object-fit:contain;" alt="Logo" />`:`<div style="width:65px; height:65px; border-radius:50%; border:1px solid #D9DEE8; display:grid; place-items:center; color:#0b2c4d; font-size:26px; font-weight:900;">${o.charAt(0)}</div>`}
    <div>
      <h1 class="school-title">${o}</h1>
      <div class="school-meta">${s} · ${c}</div>
      <h2 class="report-title">${r} — Session 2026-2027</h2>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width:35px; text-align:center;">Sr#</th>
        <th style="width:75px;">GR No</th>
        <th>Student Name</th>
        <th>Father Name</th>
        <th style="width:105px;">Class / Section</th>
        <th style="width:85px; text-align:center;">Family Code</th>
        <th style="width:85px; text-align:right;">Monthly Fee</th>
        <th style="width:70px; text-align:center;">Status</th>
      </tr>
    </thead>
    <tbody>
      ${e}
    </tbody>
  </table>

  <div class="footer-box">
    <span><strong>Total Records:</strong> ${i.length} &nbsp;|&nbsp; <strong>Date:</strong> ${d}</span>
    <div class="sig-block">
      ${t}
      <div class="sig-line">Principal Signature</div>
    </div>
  </div>

  <script>
    window.onload = function() {
      setTimeout(function() {
        window.focus();
        window.print();
      }, 300);
    };
  <\/script>
</body>
</html>`,l=window.open(``,`_blank`,`width=1100,height=850`);l?(l.document.open(),l.document.write(n),l.document.close()):window.print()},style:{background:S.gold,border:`none`,padding:`8px 20px`,borderRadius:8,cursor:`pointer`,fontWeight:600},children:`Print Now`}),(0,g.jsx)(`button`,{onClick:t,style:{background:`rgba(255,255,255,0.1)`,border:`none`,color:`#fff`,padding:`8px 16px`,borderRadius:8,cursor:`pointer`},children:`Close`})]})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{flex:1,overflowY:`auto`,padding:40,color:`#333`},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,alignItems:`center`,gap:20,marginBottom:30,borderBottom:`2px solid #0b2c4d`,paddingBottom:20},children:[a?(0,g.jsx)(`img`,{src:a,style:{width:80,height:80,objectFit:`contain`},alt:`Logo`}):(0,g.jsx)(`div`,{style:{width:80,height:80,borderRadius:`50%`,border:`1px solid #D9DEE8`,display:`grid`,placeItems:`center`,color:`#0b2c4d`,fontSize:30,fontWeight:900},children:o.charAt(0)}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`h1`,{style:{margin:0,fontSize:24,color:`#0b2c4d`},children:o}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{fontSize:14,color:`#666`,marginTop:4},children:[s,` - `,c]}),(0,g.jsxs)(`h2`,{style:{margin:`10px 0 0`,fontSize:18,color:S.gold},children:[r,` — `,new Date().toLocaleDateString()]})]})]}),(0,g.jsxs)(`table`,{style:{width:`100%`,borderCollapse:`collapse`},children:[(0,g.jsx)(`thead`,{children:(0,g.jsxs)(`tr`,{style:{background:`#f4f4f4`},children:[(0,g.jsx)(`th`,{style:{padding:10,border:`1px solid #ddd`},children:`Sr#`}),(0,g.jsx)(`th`,{style:{padding:10,border:`1px solid #ddd`},children:`GR No`}),(0,g.jsx)(`th`,{style:{padding:10,border:`1px solid #ddd`},children:`Student Name`}),(0,g.jsx)(`th`,{style:{padding:10,border:`1px solid #ddd`},children:`Father Name`}),(0,g.jsx)(`th`,{style:{padding:10,border:`1px solid #ddd`},children:`Class / Section`}),(0,g.jsx)(`th`,{style:{padding:10,border:`1px solid #ddd`},children:`Family Code`}),(0,g.jsx)(`th`,{style:{padding:10,border:`1px solid #ddd`},children:`Monthly Fee`}),(0,g.jsx)(`th`,{style:{padding:10,border:`1px solid #ddd`},children:`Status`})]})}),(0,g.jsx)(`tbody`,{children:i.map((e,t)=>(0,g.jsxs)(`tr`,{children:[(0,g.jsx)(`td`,{style:{padding:8,border:`1px solid #ddd`,textAlign:`center`},children:t+1}),(0,g.jsx)(`td`,{style:{padding:8,border:`1px solid #ddd`},children:e.gr}),(0,g.jsx)(`td`,{style:{padding:8,border:`1px solid #ddd`,fontWeight:600},children:e.student}),(0,g.jsx)(`td`,{style:{padding:8,border:`1px solid #ddd`},children:e.father}),(0,g.jsxs)(`td`,{style:{padding:8,border:`1px solid #ddd`},children:[e.class,` / `,e.section]}),(0,g.jsx)(`td`,{style:{padding:8,border:`1px solid #ddd`,textAlign:`center`},children:e.familyCode}),(0,g.jsx)(`td`,{style:{padding:8,border:`1px solid #ddd`,textAlign:`right`},children:e.total}),(0,g.jsx)(`td`,{style:{padding:8,border:`1px solid #ddd`,fontWeight:700,color:e.status===`Paid`?`green`:`red`},children:e.status})]},e.id))})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{marginTop:40,display:`flex`,justifyContent:`space-between`,alignItems:`flex-end`,fontSize:12,color:`#888`},children:[(0,g.jsxs)(`span`,{children:[`Printed on: `,new Date().toLocaleString()]}),(0,g.jsxs)(`span`,{style:{display:`flex`,flexDirection:`column`,alignItems:`center`,gap:4,minWidth:150},children:[u?(0,g.jsx)(`img`,{src:u,alt:`Principal Signature`,style:{height:36,maxWidth:130,objectFit:`contain`}}):(0,g.jsx)(`span`,{style:{display:`block`,height:36,width:130}}),(0,g.jsx)(`span`,{style:{borderTop:`1px solid #333`,paddingTop:5,width:`100%`,textAlign:`center`},children:`Principal Signature`})]})]})]})]})]})})}function N(){let e=r(),t=a(),{paperSettings:n}=f(),{classNames:o}=d();o==null||o.length;let s=()=>{try{return typeof window<`u`?window.localStorage:null}catch{return null}},c=(0,h.useMemo)(()=>e.pathname.includes(`/fees/reporting`)?`reports`:e.pathname.includes(`/fees/challans`)?`view`:e.pathname.includes(`/fees/settings`)?`settings`:e.pathname.includes(`/fees/proofs`)?`proofs`:`create`,[e.pathname]),[l,p]=(0,h.useState)([]),[m,_]=(0,h.useState)(null),[v,x]=(0,h.useState)(null),[E,O]=(0,h.useState)(()=>{var e;return((e=s())==null?void 0:e.getItem(`feeTemplate`))||`classic`});return(0,h.useEffect)(()=>{let e=s();try{e==null||e.setItem(`feeTemplate`,E)}catch{}},[E]),(0,h.useEffect)(()=>{async function e(){try{var e;p((((e=(await u.get(`/api/fees`)).data)==null?void 0:e.data)||[]).map(y))}catch(e){console.error(`Failed to load fees`,e)}}e()},[]),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{minHeight:`100vh`,background:`#071e34`,color:S.silver,fontFamily:`Inter, sans-serif`},children:[m&&(0,g.jsx)(j,{challan:m,selectedTemplate:E,onClose:()=>_(null),school:n}),v&&(0,g.jsx)(M,{list:v,onClose:()=>x(null),school:n}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{padding:`24px 24px`},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{padding:`24px 26px`,borderRadius:26,background:`linear-gradient(135deg, rgba(11,44,77,0.92), rgba(7,30,52,0.98))`,border:`1px solid ${S.border}`,display:`flex`,flexWrap:`wrap`,gap:18,justifyContent:`space-between`,alignItems:`center`},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,gap:18,alignItems:`center`},children:[(0,g.jsx)(`div`,{className:`super-module-card`,style:{width:56,height:56,borderRadius:18,display:`grid`,placeItems:`center`,background:`rgba(200,153,26,0.16)`,border:`1px solid rgba(200,153,26,0.35)`,color:S.gold},children:(0,g.jsx)(i,{size:26})}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`h1`,{style:{margin:0,fontSize:28,color:`#fff`,fontFamily:`'Playfair Display',serif`,fontWeight:800},children:`Fee Collection`}),(0,g.jsx)(`p`,{style:{margin:`6px 0 0`,color:S.muted,fontSize:13},children:`Create challans, view collections, and manage defaulters.`})]})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,flexWrap:`wrap`,gap:10,alignItems:`center`},children:[(0,g.jsx)(w,{active:c===`create`,onClick:()=>t(`/fees/create`),children:` Create Challan`}),(0,g.jsx)(w,{active:c===`view`,onClick:()=>t(`/fees/challans`),children:` View Challans`}),(0,g.jsx)(w,{active:c===`reports`,onClick:()=>t(`/fees/reporting`),children:` Reports`}),(0,g.jsx)(w,{active:c===`proofs`,onClick:()=>t(`/fees/proofs`),children:` Proof Review`}),(0,g.jsx)(w,{active:c===`settings`,onClick:()=>t(`/fees/settings`),children:` Fee Settings`})]})]}),(0,g.jsxs)(C,{style:{marginTop:20,display:`flex`,flexWrap:`wrap`,justifyContent:`space-between`,gap:18,alignItems:`center`},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:S.silver,fontSize:13,marginBottom:6},children:`Fee Voucher Settings`}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:`#fff`,fontWeight:700},children:`Choose the print template to apply to all vouchers.`})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{minWidth:240,width:`100%`,maxWidth:320},children:[(0,g.jsx)(T,{children:`Voucher Template`}),(0,g.jsx)(D,{value:E,onChange:e=>O(e.target.value),children:b.map(e=>(0,g.jsx)(`option`,{value:e.id,children:e.label},e.id))})]})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{paddingTop:28},children:[c===`create`&&(0,g.jsx)(I,{onCreate:async()=>{try{var e;p((((e=(await u.get(`/api/fees`)).data)==null?void 0:e.data)||[]).map(y))}catch(e){console.error(`Failed to reload challans`,e)}t(`/fees/challans`)}}),c===`view`&&(0,g.jsx)(L,{challans:l,onPrint:_,onPrintList:(e,t)=>x({type:e,data:t})}),c===`reports`&&(0,g.jsx)(R,{challans:l}),c===`proofs`&&(0,g.jsx)(P,{}),c===`settings`&&(0,g.jsx)(F,{selectedTemplate:E,onTemplateChange:O})]})]})]})}function P(){let[e,t]=(0,h.useState)([]),[n,r]=(0,h.useState)(!0),[i,a]=(0,h.useState)(null),[o,c]=(0,h.useState)(null),[l,d]=(0,h.useState)(null),f=async()=>{r(!0);try{var e;t(((e=(await u.get(`/api/fees/pending-proofs`)).data)==null?void 0:e.data)||[])}catch{t([])}r(!1)};(0,h.useEffect)(()=>{f()},[]);let p=(e,t)=>{d({type:e,msg:t}),setTimeout(()=>d(null),4e3)},m=async(e,t)=>{c(e+t);try{await u.put(`/api/fees/${e}/approve-proof`,{action:t}),p(`success`,t===`approve`?`Fee marked as paid!`:`Proof rejected.`),a(null),f()}catch(e){var n;p(`error`,(e==null||(n=e.response)==null||(n=n.data)==null?void 0:n.message)||`Action failed`)}c(null)};return(0,g.jsxs)(C,{style:{position:`relative`},children:[l&&(0,g.jsx)(`div`,{style:{position:`fixed`,top:24,right:24,zIndex:9999,padding:`12px 20px`,borderRadius:12,background:l.type===`success`?`rgba(16,185,129,0.12)`:`rgba(239,68,68,0.12)`,border:`1px solid ${l.type===`success`?`rgba(16,185,129,0.4)`:`rgba(239,68,68,0.4)`}`,color:l.type===`success`?`#34d399`:`#f87171`,fontWeight:600,fontSize:13},children:l.msg}),(0,g.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:20},children:[(0,g.jsx)(`div`,{style:{color:`#fff`,fontSize:18,fontWeight:700},children:` Fee Proof Review`}),(0,g.jsx)(`button`,{onClick:f,style:{background:`rgba(200,153,26,0.15)`,border:`1px solid rgba(200,153,26,0.3)`,color:S.gold,borderRadius:8,padding:`6px 16px`,cursor:`pointer`,fontSize:13,fontWeight:600},children:` Refresh`})]}),n&&(0,g.jsx)(`p`,{style:{color:S.muted,fontSize:14},children:`Loading...`}),!n&&e.length===0&&(0,g.jsxs)(`div`,{style:{textAlign:`center`,padding:`40px 0`,color:S.muted},children:[(0,g.jsx)(`div`,{style:{fontSize:40,marginBottom:12}}),(0,g.jsx)(`p`,{children:`No pending proof submissions.`})]}),(0,g.jsx)(`div`,{style:{display:`grid`,gap:14},children:e.map(e=>(0,g.jsxs)(`div`,{style:{background:`rgba(255,255,255,0.04)`,border:`1px solid rgba(200,153,26,0.2)`,borderRadius:16,padding:`16px 20px`,display:`flex`,flexWrap:`wrap`,gap:16,alignItems:`center`,justifyContent:`space-between`},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsxs)(`div`,{style:{color:`#fff`,fontWeight:700,fontSize:15},children:[e.name,` `,(0,g.jsxs)(`span`,{style:{color:S.muted,fontWeight:400,fontSize:13},children:[`(`,e.gr_number,`)`]})]}),(0,g.jsxs)(`div`,{style:{color:S.silver,fontSize:13,marginTop:4},children:[`Class `,e.class,` • `,e.month,` `,e.year,` • Rs `,Number(e.proof_amount||e.amount).toLocaleString()]}),(0,g.jsxs)(`div`,{style:{color:S.muted,fontSize:12,marginTop:2},children:[`Via: `,e.proof_method||`—`,` • Submitted: `,e.proof_submitted_at?new Date(e.proof_submitted_at).toLocaleDateString(`en-GB`):`—`]})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,gap:8},children:[(0,g.jsx)(`button`,{onClick:()=>a(e),style:{background:`rgba(59,130,246,0.15)`,border:`1px solid rgba(59,130,246,0.35)`,color:`#60a5fa`,borderRadius:8,padding:`7px 14px`,cursor:`pointer`,fontSize:13,fontWeight:600},children:` View`}),(0,g.jsx)(`button`,{onClick:()=>m(e.id,`approve`),disabled:o===e.id+`approve`,style:{background:`rgba(16,185,129,0.15)`,border:`1px solid rgba(16,185,129,0.35)`,color:`#34d399`,borderRadius:8,padding:`7px 14px`,cursor:`pointer`,fontSize:13,fontWeight:600,opacity:o?.6:1},children:` Approve`}),(0,g.jsx)(`button`,{onClick:()=>m(e.id,`reject`),disabled:o===e.id+`reject`,style:{background:`rgba(239,68,68,0.1)`,border:`1px solid rgba(239,68,68,0.3)`,color:`#f87171`,borderRadius:8,padding:`7px 14px`,cursor:`pointer`,fontSize:13,fontWeight:600,opacity:o?.6:1},children:` Reject`})]})]},e.id))}),i&&(0,g.jsx)(`div`,{style:{position:`fixed`,inset:0,background:`rgba(0,0,0,0.75)`,zIndex:9e3,display:`flex`,alignItems:`center`,justifyContent:`center`,padding:24},children:(0,g.jsxs)(`div`,{style:{background:`#0f172a`,border:`1px solid rgba(200,153,26,0.3)`,borderRadius:20,maxWidth:480,width:`100%`,padding:24},children:[(0,g.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,marginBottom:16},children:[(0,g.jsxs)(`div`,{style:{color:`#fff`,fontWeight:700,fontSize:16},children:[i.name,` — Payment Screenshot`]}),(0,g.jsx)(`button`,{onClick:()=>a(null),style:{background:`none`,border:`none`,color:S.muted,cursor:`pointer`,display:`flex`,alignItems:`center`,padding:4},children:(0,g.jsx)(s,{size:18})})]}),(0,g.jsx)(`img`,{src:i.proof_image,alt:`Proof`,style:{width:`100%`,borderRadius:12,marginBottom:16,maxHeight:320,objectFit:`contain`,background:`#1e293b`}}),(0,g.jsxs)(`div`,{style:{display:`flex`,gap:10},children:[(0,g.jsx)(`button`,{onClick:()=>{m(i.id,`approve`),a(null)},style:{flex:1,padding:`10px 0`,borderRadius:10,background:`rgba(16,185,129,0.2)`,border:`1px solid rgba(16,185,129,0.4)`,color:`#34d399`,fontWeight:600,cursor:`pointer`},children:` Approve & Mark Paid`}),(0,g.jsx)(`button`,{onClick:()=>{m(i.id,`reject`),a(null)},style:{flex:1,padding:`10px 0`,borderRadius:10,background:`rgba(239,68,68,0.1)`,border:`1px solid rgba(239,68,68,0.3)`,color:`#f87171`,fontWeight:600,cursor:`pointer`},children:` Reject`})]})]})})]})}function F({selectedTemplate:e,onTemplateChange:t}){return(0,g.jsx)(C,{children:(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gap:16},children:[(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:`#fff`,fontSize:18,fontWeight:700},children:`Fee Voucher Template Settings`}),(0,g.jsx)(`p`,{style:{color:S.silver,margin:0,fontSize:14},children:`These settings apply globally across all fee vouchers. The selected template will be remembered for your next session.`}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gap:12,maxWidth:400},children:[(0,g.jsx)(T,{children:`Choose Voucher Template`}),(0,g.jsx)(D,{value:e,onChange:e=>t(e.target.value),children:b.map(e=>(0,g.jsx)(`option`,{value:e.id,children:e.label},e.id))})]})]})})}function I({onCreate:e}){let[t,n]=(0,h.useState)(`Pre Nine`),[r,i]=(0,h.useState)(``),[a,o]=(0,h.useState)(`May`),[s,c]=(0,h.useState)(`2026`),[l,d]=(0,h.useState)(`2026-05-10`),[f,p]=(0,h.useState)({1:!0,2:!1,3:!1,4:!1,5:!1,6:!1,7:!1}),[m,y]=(0,h.useState)(v.reduce((e,t)=>({...e,[t.id]:t.defaultAmount}),{})),[b,w]=(0,h.useState)(0),[O,k]=(0,h.useState)(0),[A,j]=(0,h.useState)(!1),M=x.filter(e=>e.class===t),N=x.find(e=>e.id===Number(r)),P=(0,h.useMemo)(()=>{let e=v.filter(e=>f[e.id]).reduce((e,t)=>e+Number(m[t.id]||0),0);return Math.max(0,e-Number(b||0)+Number(O||0))},[f,m,b,O]);return(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gridTemplateColumns:`1.5fr 1fr`,gap:24},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gap:24},children:[(0,g.jsxs)(C,{children:[(0,g.jsx)(`h2`,{style:{color:S.gold,fontSize:20,marginBottom:18,fontFamily:`'Playfair Display',serif`},children:`Step 1 — Select Student`}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:16,marginBottom:16},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Class`}),(0,g.jsx)(D,{value:t,onChange:e=>{n(e.target.value),i(``)},children:classOptions.map(e=>(0,g.jsx)(`option`,{value:e,children:e},e))})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Student`}),(0,g.jsxs)(D,{value:r,onChange:e=>i(e.target.value),children:[(0,g.jsx)(`option`,{value:``,children:`Pick a student`}),M.map(e=>(0,g.jsxs)(`option`,{value:e.id,children:[e.name,` (`,e.gr,`)`]},e.id))]})]})]}),N?(0,g.jsxs)(`div`,{className:`super-module-card`,style:{background:`rgba(200,153,26,0.08)`,border:`1px solid ${S.border}`,borderRadius:20,padding:18,display:`grid`,gap:14},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:16},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`GR No`}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:`#fff`,fontWeight:700},children:N.gr})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Father`}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:`#fff`,fontWeight:700},children:N.father})]})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:16},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Contact`}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:`#fff`,fontWeight:700},children:N.contact})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Discount`}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{color:S.green,fontWeight:700},children:[`Rs. `,N.discount]})]})]})]}):(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:S.muted,fontSize:13},children:`Select a class and student to preview challan details.`})]}),(0,g.jsxs)(C,{children:[(0,g.jsx)(`h2`,{style:{color:S.gold,fontSize:20,marginBottom:18,fontFamily:`'Playfair Display',serif`},children:`Step 2 — Billing Period`}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr 1fr`,gap:16},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Month`}),(0,g.jsx)(D,{value:a,onChange:e=>o(e.target.value),children:_.map(e=>(0,g.jsx)(`option`,{value:e,children:e},e))})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Year`}),(0,g.jsx)(D,{value:s,onChange:e=>c(e.target.value),children:[`2025`,`2026`,`2027`].map(e=>(0,g.jsx)(`option`,{value:e,children:e},e))})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Due Date`}),(0,g.jsx)(E,{type:`date`,value:l,onChange:e=>d(e.target.value)})]})]})]}),(0,g.jsxs)(C,{children:[(0,g.jsx)(`h2`,{style:{color:S.gold,fontSize:20,marginBottom:18,fontFamily:`'Playfair Display',serif`},children:`Step 3 — Fee Heads`}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{display:`grid`,gap:12},children:v.map(e=>(0,g.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`auto 1fr 100px`,gap:12,alignItems:`center`,padding:`12px 14px`,borderRadius:14,border:`1px solid ${f[e.id]?`rgba(200,153,26,0.35)`:S.border}`,background:f[e.id]?`rgba(200,153,26,0.08)`:`rgba(11,44,77,0.28)`},children:[(0,g.jsx)(`input`,{type:`checkbox`,checked:!!f[e.id],onChange:t=>p(n=>({...n,[e.id]:t.target.checked})),style:{width:18,height:18,accentColor:S.gold,cursor:`pointer`}}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:f[e.id]?`#fff`:S.muted,fontWeight:600},children:e.name}),(0,g.jsx)(E,{type:`number`,value:m[e.id],disabled:!f[e.id],onChange:t=>y(n=>({...n,[e.id]:Number(t.target.value)||0})),style:{opacity:f[e.id]?1:.45,textAlign:`right`}})]},e.id))}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:16,marginTop:16},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Discount`}),(0,g.jsx)(E,{type:`number`,value:b,onChange:e=>w(Number(e.target.value)||0),placeholder:`0`})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Late Fee`}),(0,g.jsx)(E,{type:`number`,value:O,onChange:e=>k(Number(e.target.value)||0),placeholder:`0`})]})]})]})]}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{display:`grid`,gap:24},children:(0,g.jsxs)(C,{style:{position:`sticky`,top:24},children:[(0,g.jsx)(`h2`,{style:{color:S.gold,fontSize:20,marginBottom:18,fontFamily:`'Playfair Display',serif`},children:`Challan Summary`}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gap:12,marginBottom:20},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`space-between`,color:S.muted},children:[(0,g.jsx)(`span`,{children:`Student`}),(0,g.jsx)(`span`,{children:(N==null?void 0:N.name)||`—`})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`space-between`,color:S.muted},children:[(0,g.jsx)(`span`,{children:`Month`}),(0,g.jsx)(`span`,{children:`${a} ${s}`})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`space-between`,color:S.muted},children:[(0,g.jsx)(`span`,{children:`Due Date`}),(0,g.jsx)(`span`,{children:l})]})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{background:`rgba(7,30,52,0.4)`,borderRadius:18,padding:18,display:`grid`,gap:12},children:[v.filter(e=>f[e.id]).map(e=>(0,g.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,color:S.silver},children:[(0,g.jsx)(`span`,{children:e.name}),(0,g.jsxs)(`span`,{children:[`Rs. `,(m[e.id]||0).toLocaleString()]})]},e.id)),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`space-between`,color:S.green,fontWeight:700},children:[(0,g.jsx)(`span`,{children:`Discount`}),(0,g.jsxs)(`span`,{children:[`- Rs. `,Number(b||0).toLocaleString()]})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`space-between`,color:S.red,fontWeight:700},children:[(0,g.jsx)(`span`,{children:`Late Fee`}),(0,g.jsxs)(`span`,{children:[`+ Rs. `,Number(O||0).toLocaleString()]})]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`space-between`,paddingTop:12,borderTop:`1px solid ${S.border}`,color:S.gold,fontWeight:800,fontSize:16},children:[(0,g.jsx)(`span`,{children:`Total`}),(0,g.jsxs)(`span`,{children:[`Rs. `,P.toLocaleString()]})]})]}),(0,g.jsx)(`button`,{onClick:async()=>{if(N)try{await u.post(`/api/fees`,{student_id:N.id,month:a,year:Number(s),amount:P,due_date:l,created_by:1}),j(!0),setTimeout(()=>j(!1),2e3),e()}catch(e){var t;console.error(`Failed to create challan`,e),alert(`Failed to create challan: `+(((t=e.response)==null||(t=t.data)==null?void 0:t.message)||e.message))}},disabled:!N,style:{width:`100%`,padding:`14px 0`,borderRadius:20,border:`none`,cursor:N?`pointer`:`not-allowed`,background:N?`linear-gradient(135deg, ${S.gold}, ${S.goldL})`:`rgba(148,163,184,0.18)`,color:N?`#071e34`:S.muted,fontWeight:700,fontSize:15},children:A?` Challan Created`:`Create Challan`})]})})]})}function L({challans:e,onPrint:t,onPrintList:n}){let[r,i]=(0,h.useState)(`All`),[a,o]=(0,h.useState)(`All`),[s,c]=(0,h.useState)(`All`),[l,u]=(0,h.useState)(``),d=(0,h.useMemo)(()=>e.filter(e=>!(r!==`All`&&e.class!==r||a!==`All`&&e.month!==a||s!==`All`&&e.status!==s||l&&!e.student.toLowerCase().includes(l.toLowerCase())&&!e.gr.toLowerCase().includes(l.toLowerCase()))),[e,r,a,s,l]);return d.reduce((e,t)=>e+t.total,0),d.reduce((e,t)=>e+t.paid,0),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gap:24},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`flex-end`,gap:12,flexWrap:`wrap`},children:[(0,g.jsx)(`button`,{onClick:()=>{n(`School-Wide Student Fee List`,[...e].sort((e,t)=>e.class.localeCompare(t.class)))},style:{background:S.blue,color:`#fff`,border:`none`,borderRadius:20,padding:`8px 20px`,fontSize:13,fontWeight:600,cursor:`pointer`},children:` Print All Classes`}),(0,g.jsx)(`button`,{onClick:()=>{n(`Fee Defaulters List`,e.filter(e=>e.status!==`Paid`))},style:{background:S.red,color:`#fff`,border:`none`,borderRadius:20,padding:`8px 20px`,fontSize:13,fontWeight:600,cursor:`pointer`},children:` Print Defaulters`}),(0,g.jsx)(`button`,{onClick:()=>n(`${r===`All`?`Current`:r} List`,d),style:{background:S.gold,color:`#fff`,border:`none`,borderRadius:20,padding:`8px 20px`,fontSize:13,fontWeight:600,cursor:`pointer`},children:` Print Filtered List`}),(0,g.jsx)(`button`,{style:{background:S.orange,color:`#fff`,border:`none`,borderRadius:20,padding:`8px 20px`,fontSize:13,fontWeight:600,cursor:`pointer`},children:`Class Wise View Challan`})]}),(0,g.jsxs)(C,{children:[(0,g.jsxs)(`h3`,{style:{color:`#fff`,fontSize:16,marginBottom:18},children:[`View Fee Challans (`,d.length,` records)`]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr 1fr 1fr 1fr 1fr`,gap:12},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Session`}),(0,g.jsx)(D,{children:(0,g.jsx)(`option`,{children:`2026-2027`})})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Class Head`}),(0,g.jsx)(D,{children:(0,g.jsx)(`option`,{children:`All`})})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Class`}),(0,g.jsxs)(D,{value:r,onChange:e=>i(e.target.value),children:[(0,g.jsx)(`option`,{children:`All`}),classOptions.map(e=>(0,g.jsx)(`option`,{value:e,children:e},e))]})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Section`}),(0,g.jsxs)(D,{children:[(0,g.jsx)(`option`,{children:`All`}),(0,g.jsx)(`option`,{children:`Blue`}),(0,g.jsx)(`option`,{children:`Red`}),(0,g.jsx)(`option`,{children:`Green`})]})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Challan Month`}),(0,g.jsxs)(D,{value:a,onChange:e=>o(e.target.value),children:[(0,g.jsx)(`option`,{children:`All`}),_.map(e=>(0,g.jsx)(`option`,{value:e,children:e},e))]})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(T,{children:`Fee Status`}),(0,g.jsxs)(D,{value:s,onChange:e=>c(e.target.value),children:[(0,g.jsx)(`option`,{children:`All`}),(0,g.jsx)(`option`,{children:`Paid`}),(0,g.jsx)(`option`,{children:`Partial`}),(0,g.jsx)(`option`,{children:`Unpaid`})]})]})]}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`flex-end`,marginTop:12},children:(0,g.jsx)(`button`,{style:{background:S.blue,color:`#fff`,border:`none`,borderRadius:4,padding:`8px 24px`,fontSize:14,fontWeight:600,cursor:`pointer`},children:`Filter`})})]}),(0,g.jsxs)(C,{style:{padding:0,overflow:`visible`},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{padding:`16px 20px`,display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,g.jsxs)(`div`,{children:[`Show `,(0,g.jsxs)(D,{style:{width:80,display:`inline-block`},children:[(0,g.jsx)(`option`,{children:`10`}),(0,g.jsx)(`option`,{children:`25`}),(0,g.jsx)(`option`,{children:`50`})]}),` entries`]}),(0,g.jsxs)(`div`,{children:[`Search: `,(0,g.jsx)(E,{style:{width:200,display:`inline-block`},value:l,onChange:e=>u(e.target.value)})]})]}),(0,g.jsxs)(`table`,{style:{width:`100%`,borderCollapse:`collapse`},children:[(0,g.jsx)(`thead`,{children:(0,g.jsx)(`tr`,{style:{background:`#1e293b`,borderBottom:`1px solid ${S.border}`},children:[`GR. No`,`Student / Father Name`,`Family Code`,`Class/Section`,`ChallanID`,`Monthly Fee`,`Total`,`Pay Fee`,`Action`,`Status`].map(e=>(0,g.jsx)(`th`,{style:{padding:`12px 16px`,textAlign:`left`,color:`#fff`,fontSize:12,fontWeight:600},children:e},e))})}),(0,g.jsx)(`tbody`,{children:d.length===0?(0,g.jsx)(`tr`,{children:(0,g.jsx)(`td`,{colSpan:10,style:{padding:42,textAlign:`center`,color:S.muted},children:`No challans found.`})}):d.map((e,n)=>(0,g.jsxs)(`tr`,{style:{background:n%2==0?`transparent`:`rgba(255,255,255,0.02)`,borderBottom:`1px solid rgba(255,255,255,0.05)`},children:[(0,g.jsx)(`td`,{style:{padding:`14px 16px`,color:S.silver},children:e.gr}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`},children:(0,g.jsxs)(`div`,{className:`super-module-card`,style:{color:S.blue,fontWeight:600},children:[e.student,` / `,e.father]})}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`,color:S.silver,textAlign:`center`},children:e.familyCode}),(0,g.jsxs)(`td`,{style:{padding:`14px 16px`,color:S.silver},children:[e.class,` / `,e.section]}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`,color:S.silver},children:e.voucherNo.replace(`AL-`,``)}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`,color:S.silver},children:e.total}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`,color:S.silver},children:e.total}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`},children:(0,g.jsx)(`button`,{style:{background:S.green,color:`#fff`,border:`none`,borderRadius:4,padding:`4px 10px`,fontSize:12,fontWeight:600,cursor:`pointer`},children:`Pay Now`})}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`},children:(0,g.jsx)(k,{onPrint:()=>t(e)})}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`,minWidth:80},children:(0,g.jsx)(O,{status:e.status})})]},e.id))})]})]})]})}function R({challans:e}){let t=e.filter(e=>e.status===`Paid`),n=e.filter(e=>e.status!==`Paid`),r=x.filter(e=>n.some(t=>t.studentId===e.id)),i=t.reduce((e,t)=>e+t.total,0),a=n.reduce((e,t)=>e+(t.total-t.paid),0),s=_.slice(2,5).map(t=>{let n=e.filter(e=>e.month===t);return{month:t,collected:n.filter(e=>e.status===`Paid`).reduce((e,t)=>e+t.total,0),pending:n.filter(e=>e.status!==`Paid`).reduce((e,t)=>e+(t.total-t.paid),0)}}),u=Math.max(...s.map(e=>e.collected+e.pending),1);return(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gap:24},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`grid`,gridTemplateColumns:`repeat(3,1fr)`,gap:16},children:[(0,g.jsx)(A,{icon:(0,g.jsx)(l,{size:23}),label:`Collected`,value:`Rs.${(i/1e3).toFixed(1)}K`,color:S.green}),(0,g.jsx)(A,{icon:(0,g.jsx)(c,{size:23}),label:`Pending`,value:`Rs.${(a/1e3).toFixed(1)}K`,color:S.red}),(0,g.jsx)(A,{icon:(0,g.jsx)(o,{size:23}),label:`Defaulters`,value:r.length,color:S.orange})]}),(0,g.jsxs)(C,{children:[(0,g.jsx)(`h3`,{style:{color:S.gold,fontFamily:`'Playfair Display',serif`,fontSize:18,fontWeight:700,marginBottom:22},children:`Monthly Collection Overview`}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{display:`flex`,alignItems:`flex-end`,gap:26,minHeight:170},children:s.map(e=>{let t=e.collected+e.pending,n=t?Math.max(34,t/u*140):34,r=t?Math.max(12,e.collected/t*n):0;return(0,g.jsxs)(`div`,{style:{flex:1,display:`flex`,flexDirection:`column`,alignItems:`center`,gap:10},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{color:S.gold,fontSize:12,fontWeight:700},children:[`Rs.`,(e.collected/1e3).toFixed(1),`K`]}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{width:`100%`,height:n,borderRadius:20,overflow:`hidden`,background:`rgba(255,55,95,0.2)`,display:`flex`,flexDirection:`column-reverse`},children:(0,g.jsx)(`div`,{className:`super-module-card`,style:{height:r,background:`linear-gradient(180deg, ${S.green}, #25a244)`}})}),(0,g.jsx)(`div`,{className:`super-module-card`,style:{color:S.muted,fontSize:12},children:e.month})]},e.month)})}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,gap:18,marginTop:18},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,alignItems:`center`,gap:8},children:[(0,g.jsx)(`span`,{style:{width:12,height:12,borderRadius:3,background:S.green}}),`Collected`]}),(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,alignItems:`center`,gap:8},children:[(0,g.jsx)(`span`,{style:{width:12,height:12,borderRadius:3,background:`rgba(255,55,95,0.45)`}}),`Pending`]})]})]}),(0,g.jsxs)(C,{style:{padding:0,overflow:`hidden`},children:[(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,padding:`18px 24px`,borderBottom:`1px solid ${S.border}`},children:[(0,g.jsx)(`h3`,{style:{color:S.red,fontFamily:`'Playfair Display',serif`,fontSize:18,fontWeight:700,margin:0},children:`Fee Defaulters`}),(0,g.jsx)(`button`,{style:{background:`rgba(255,55,95,0.15)`,border:`1px solid rgba(255,55,95,0.35)`,borderRadius:12,padding:`10px 16px`,color:S.red,fontWeight:600,cursor:`pointer`},children:`SMS Defaulters`})]}),(0,g.jsxs)(`table`,{style:{width:`100%`,borderCollapse:`collapse`},children:[(0,g.jsx)(`thead`,{children:(0,g.jsx)(`tr`,{style:{background:`rgba(7,30,52,0.95)`,borderBottom:`1px solid ${S.border}`},children:[`Student`,`GR No`,`Class`,`Contact`,`Pending`,`Action`].map(e=>(0,g.jsx)(`th`,{style:{padding:`14px 16px`,textAlign:`left`,color:S.gold,fontSize:11,letterSpacing:`0.08em`,textTransform:`uppercase`},children:e},e))})}),(0,g.jsx)(`tbody`,{children:r.length===0?(0,g.jsx)(`tr`,{children:(0,g.jsx)(`td`,{colSpan:6,style:{padding:36,textAlign:`center`,color:S.muted},children:`No defaulters right now.`})}):r.map((t,n)=>{let r=e.filter(e=>e.studentId===t.id&&e.status!==`Paid`).reduce((e,t)=>e+(t.total-t.paid),0);return(0,g.jsxs)(`tr`,{style:{background:n%2==0?`transparent`:`rgba(11,44,77,0.2)`},children:[(0,g.jsx)(`td`,{style:{padding:`14px 16px`},children:(0,g.jsxs)(`div`,{className:`super-module-card`,style:{display:`flex`,alignItems:`center`,gap:10},children:[(0,g.jsx)(`div`,{className:`super-module-card`,style:{width:32,height:32,borderRadius:10,background:`rgba(255,55,95,0.16)`,display:`grid`,placeItems:`center`,color:S.red,fontWeight:800},children:t.name.charAt(0)}),(0,g.jsx)(`span`,{style:{color:`#fff`,fontWeight:700},children:t.name})]})}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`},children:(0,g.jsx)(`span`,{style:{background:`rgba(200,153,26,0.12)`,color:S.gold,padding:`5px 10px`,borderRadius:10,fontWeight:700},children:t.gr})}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`,color:S.silver},children:t.class}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`,color:S.muted},children:t.contact}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`},children:(0,g.jsxs)(`span`,{style:{background:`rgba(255,55,95,0.12)`,color:S.red,padding:`6px 12px`,borderRadius:10,fontWeight:700},children:[`Rs. `,r.toLocaleString()]})}),(0,g.jsx)(`td`,{style:{padding:`14px 16px`},children:(0,g.jsx)(`button`,{style:{background:`rgba(255,159,10,0.15)`,border:`1px solid rgba(255,159,10,0.4)`,borderRadius:10,padding:`8px 14px`,color:S.orange,fontWeight:600,cursor:`pointer`},children:`SMS`})})]},t.id)})})]})]})]})}export{N as default};